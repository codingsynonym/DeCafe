
# Text Translator DAL Migration Training History

## Structure

`TextTranslatorDALMigrationTrainingHistory`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `migrationId` | `?string` | Optional | - | getMigrationId(): ?string | setMigrationId(?string migrationId): void |
| `sourceID` | `?int` | Optional | - | getSourceID(): ?int | setSourceID(?int sourceID): void |
| `modelId` | `?int` | Optional | - | getModelId(): ?int | setModelId(?int modelId): void |
| `status` | `?int` | Optional | - | getStatus(): ?int | setStatus(?int status): void |
| `sourceWorkspace` | `?string` | Optional | - | getSourceWorkspace(): ?string | setSourceWorkspace(?string sourceWorkspace): void |
| `targetWorkspace` | `?string` | Optional | - | getTargetWorkspace(): ?string | setTargetWorkspace(?string targetWorkspace): void |
| `hubBLEUScore` | `?float` | Optional | - | getHubBLEUScore(): ?float | setHubBLEUScore(?float hubBLEUScore): void |
| `regions` | `?string` | Optional | - | getRegions(): ?string | setRegions(?string regions): void |
| `model` | [`?TextTranslatorDALModel`](../../doc/models/text-translator-dal-model.md) | Optional | - | getModel(): ?TextTranslatorDALModel | setModel(?TextTranslatorDALModel model): void |

## Example (as JSON)

```json
{
  "migrationId": null,
  "sourceID": null,
  "modelId": null,
  "status": null,
  "sourceWorkspace": null,
  "targetWorkspace": null,
  "hubBLEUScore": null,
  "regions": null,
  "model": null
}
```

