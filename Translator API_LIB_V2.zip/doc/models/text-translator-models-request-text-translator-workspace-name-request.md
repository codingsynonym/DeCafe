
# Text Translator Models Request Text Translator Workspace Name Request

The input class for change of workspace name requests.

## Structure

`TextTranslatorModelsRequestTextTranslatorWorkspaceNameRequest`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `name` | `string` | Required | Gets or sets name | getName(): string | setName(string name): void |

## Example (as JSON)

```json
{
  "name": "name0"
}
```

