
# Status Enum

The test status

## Enumeration

`StatusEnum`

## Fields

| Name |
|  --- |
| `NONE` |
| `STARTING` |
| `DEPLOYING` |
| `TESTING` |
| `COMPLETE` |

