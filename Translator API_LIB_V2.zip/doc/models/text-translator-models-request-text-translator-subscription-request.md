
# Text Translator Models Request Text Translator Subscription Request

The input class for subscription requests.

## Structure

`TextTranslatorModelsRequestTextTranslatorSubscriptionRequest`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `subscriptionKey` | `string` | Required | Gets or sets Name | getSubscriptionKey(): string | setSubscriptionKey(string subscriptionKey): void |
| `billingRegionCode` | `string` | Required | Gets or sets the region | getBillingRegionCode(): string | setBillingRegionCode(string billingRegionCode): void |

## Example (as JSON)

```json
{
  "subscriptionKey": "subscriptionKey8",
  "billingRegionCode": "billingRegionCode6"
}
```

