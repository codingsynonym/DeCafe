
# Text Translator Models Text Translator Document Info

Class containing detailed information about document.

## Structure

`TextTranslatorModelsTextTranslatorDocumentInfo`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `name` | `string` | Required | Gets or sets Name | getName(): string | setName(string name): void |
| `isParallel` | `bool` | Required | Gets or sets IsParallel - paired/unpaired with source document | getIsParallel(): bool | setIsParallel(bool isParallel): void |
| `createdBy` | [`TextTranslatorModelsResponseUserInfo`](../../doc/models/text-translator-models-response-user-info.md) | Required | Basic user information - object used for<br>CreatedBy/ModifiedBy response fields | getCreatedBy(): TextTranslatorModelsResponseUserInfo | setCreatedBy(TextTranslatorModelsResponseUserInfo createdBy): void |
| `modifiedBy` | [`TextTranslatorModelsResponseUserInfo`](../../doc/models/text-translator-models-response-user-info.md) | Required | Basic user information - object used for<br>CreatedBy/ModifiedBy response fields | getModifiedBy(): TextTranslatorModelsResponseUserInfo | setModifiedBy(TextTranslatorModelsResponseUserInfo modifiedBy): void |
| `files` | [`?(TextTranslatorModelsTextTranslatorFileInfo[])`](../../doc/models/text-translator-models-text-translator-file-info.md) | Optional | Gets or sets the files associated with the document. Each document may have many files, one for each language.<br>If document has one file, that may mean that only one language data was uploaded for it, and others still need to be provided. | getFiles(): ?array | setFiles(?array files): void |
| `languages` | [`?(TextTranslatorModelsTextTranslatorLanguage[])`](../../doc/models/text-translator-models-text-translator-language.md) | Optional | Gets or sets the file languages associated with the document. | getLanguages(): ?array | setLanguages(?array languages): void |
| `createdDate` | `?\DateTime` | Optional | Gets or sets CreatedDate | getCreatedDate(): ?\DateTime | setCreatedDate(?\DateTime createdDate): void |
| `isAvailable` | `?bool` | Optional | A document is available when it is NOT<br><br>1. A monolingual document<br>2. A dictionary<br>3. Has a language pair that is not supported | getIsAvailable(): ?bool | setIsAvailable(?bool isAvailable): void |
| `id` | `int` | Required | Gets or sets Id | getId(): int | setId(int id): void |
| `documentType` | [`string (DocumentTypeEnum)`](../../doc/models/document-type-enum.md) | Required | Gets or sets the DocumentType. | getDocumentType(): string | setDocumentType(string documentType): void |
| `extractedSentenceCount` | `int` | Required | Gets or sets extracted sentence count. | getExtractedSentenceCount(): int | setExtractedSentenceCount(int extractedSentenceCount): void |
| `characterCount` | `int` | Required | Gets or sets character count. | getCharacterCount(): int | setCharacterCount(int characterCount): void |
| `usedByPrioritizedModel` | `?bool` | Optional | Gets or sets if this model is used by the specified prioritized model | getUsedByPrioritizedModel(): ?bool | setUsedByPrioritizedModel(?bool usedByPrioritizedModel): void |

## Example (as JSON)

```json
{
  "name": "name0",
  "isParallel": false,
  "createdBy": {
    "id": "000021b8-0000-0000-0000-000000000000",
    "userName": "userName4"
  },
  "modifiedBy": {
    "id": "0000222e-0000-0000-0000-000000000000",
    "userName": "userName2"
  },
  "files": null,
  "languages": null,
  "createdDate": null,
  "isAvailable": null,
  "id": 112,
  "documentType": "testing",
  "extractedSentenceCount": 174,
  "characterCount": 130,
  "usedByPrioritizedModel": null
}
```

