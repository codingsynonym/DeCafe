
# Text Translator Utilities Training Price Information

## Structure

`TextTranslatorUtilitiesTrainingPriceInformation`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `isPaidSubscription` | `?bool` | Optional | - | getIsPaidSubscription(): ?bool | setIsPaidSubscription(?bool isPaidSubscription): void |
| `maximumCharacterCount` | `?int` | Optional | - | getMaximumCharacterCount(): ?int | setMaximumCharacterCount(?int maximumCharacterCount): void |
| `pricePerMillionCharacters` | `?float` | Optional | - | getPricePerMillionCharacters(): ?float | setPricePerMillionCharacters(?float pricePerMillionCharacters): void |

## Example (as JSON)

```json
{
  "isPaidSubscription": null,
  "maximumCharacterCount": null,
  "pricePerMillionCharacters": null
}
```

