
# Text Translator Models Response Share User Info

Information about each user a workspace
has been shared with. Because the user's UserName
may not be yet known (if they haven't signed into
Custom Translator yet), returns EmailAddress instead.

## Structure

`TextTranslatorModelsResponseShareUserInfo`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `id` | `string` | Required | Gets or sets the id for the user | getId(): string | setId(string id): void |
| `emailAddress` | `string` | Required | Gets or sets the email address for the user this workspace has been<br>shared with. | getEmailAddress(): string | setEmailAddress(string emailAddress): void |

## Example (as JSON)

```json
{
  "id": "00001770-0000-0000-0000-000000000000",
  "emailAddress": "emailAddress0"
}
```

