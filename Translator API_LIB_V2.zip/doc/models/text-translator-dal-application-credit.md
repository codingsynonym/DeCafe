
# Text Translator DAL Application Credit

## Structure

`TextTranslatorDALApplicationCredit`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `id` | `?int` | Optional | - | getId(): ?int | setId(?int id): void |
| `type` | `?string` | Optional | - | getType(): ?string | setType(?string type): void |
| `credits` | `?int` | Optional | - | getCredits(): ?int | setCredits(?int credits): void |
| `applicationId` | `?int` | Optional | - | getApplicationId(): ?int | setApplicationId(?int applicationId): void |
| `application` | [`?TextTranslatorDALApplication`](../../doc/models/text-translator-dal-application.md) | Optional | - | getApplication(): ?TextTranslatorDALApplication | setApplication(?TextTranslatorDALApplication application): void |

## Example (as JSON)

```json
{
  "id": null,
  "type": null,
  "credits": null,
  "applicationId": null,
  "application": null
}
```

