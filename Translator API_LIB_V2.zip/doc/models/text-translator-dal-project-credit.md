
# Text Translator DAL Project Credit

## Structure

`TextTranslatorDALProjectCredit`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `id` | `?int` | Optional | - | getId(): ?int | setId(?int id): void |
| `projectId` | `?string` | Optional | - | getProjectId(): ?string | setProjectId(?string projectId): void |
| `freeTrainings` | `?int` | Optional | - | getFreeTrainings(): ?int | setFreeTrainings(?int freeTrainings): void |
| `project` | [`?TextTranslatorDALProject`](../../doc/models/text-translator-dal-project.md) | Optional | - | getProject(): ?TextTranslatorDALProject | setProject(?TextTranslatorDALProject project): void |

## Example (as JSON)

```json
{
  "id": null,
  "projectId": null,
  "freeTrainings": null,
  "project": null
}
```

