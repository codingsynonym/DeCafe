
# Text Translator Models Request Text Translator Project Update Request

The input class for model update requests.

## Structure

`TextTranslatorModelsRequestTextTranslatorProjectUpdateRequest`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `name` | `?string` | Optional | Gets or sets Name | getName(): ?string | setName(?string name): void |
| `categoryDescriptor` | `?string` | Optional | Gets or sets CategoryDescriptor | getCategoryDescriptor(): ?string | setCategoryDescriptor(?string categoryDescriptor): void |
| `description` | `?string` | Optional | Gets or sets Description | getDescription(): ?string | setDescription(?string description): void |
| `label` | `?string` | Optional | Gets or sets the project label. | getLabel(): ?string | setLabel(?string label): void |

## Example (as JSON)

```json
{
  "name": null,
  "categoryDescriptor": null,
  "description": null,
  "label": null
}
```

