
# Text Translator DAL Model

## Structure

`TextTranslatorDALModel`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `id` | `?int` | Optional | - | getId(): ?int | setId(?int id): void |
| `projectId` | `?string` | Optional | - | getProjectId(): ?string | setProjectId(?string projectId): void |
| `name` | `?string` | Optional | - | getName(): ?string | setName(?string name): void |
| `modelStatus` | `?string` | Optional | - | getModelStatus(): ?string | setModelStatus(?string modelStatus): void |
| `statusInfo` | `?string` | Optional | - | getStatusInfo(): ?string | setStatusInfo(?string statusInfo): void |
| `isWhitelisted` | `?bool` | Optional | - | getIsWhitelisted(): ?bool | setIsWhitelisted(?bool isWhitelisted): void |
| `isHidden` | `?bool` | Optional | - | getIsHidden(): ?bool | setIsHidden(?bool isHidden): void |
| `resetAutoTestingDataset` | `?bool` | Optional | - | getResetAutoTestingDataset(): ?bool | setResetAutoTestingDataset(?bool resetAutoTestingDataset): void |
| `resetAutoTuningDataset` | `?bool` | Optional | - | getResetAutoTuningDataset(): ?bool | setResetAutoTuningDataset(?bool resetAutoTuningDataset): void |
| `tuningSentenceCount` | `?int` | Optional | - | getTuningSentenceCount(): ?int | setTuningSentenceCount(?int tuningSentenceCount): void |
| `testingSentenceCount` | `?int` | Optional | - | getTestingSentenceCount(): ?int | setTestingSentenceCount(?int testingSentenceCount): void |
| `createdBy` | `?string` | Optional | - | getCreatedBy(): ?string | setCreatedBy(?string createdBy): void |
| `modifiedBy` | `?string` | Optional | - | getModifiedBy(): ?string | setModifiedBy(?string modifiedBy): void |
| `createdDate` | `?\DateTime` | Optional | - | getCreatedDate(): ?\DateTime | setCreatedDate(?\DateTime createdDate): void |
| `modifiedDate` | `?\DateTime` | Optional | - | getModifiedDate(): ?\DateTime | setModifiedDate(?\DateTime modifiedDate): void |
| `startDate` | `?\DateTime` | Optional | - | getStartDate(): ?\DateTime | setStartDate(?\DateTime startDate): void |
| `completionDate` | `?\DateTime` | Optional | - | getCompletionDate(): ?\DateTime | setCompletionDate(?\DateTime completionDate): void |
| `isAutoDeploy` | `?bool` | Optional | - | getIsAutoDeploy(): ?bool | setIsAutoDeploy(?bool isAutoDeploy): void |
| `isCancelled` | `?bool` | Optional | - | getIsCancelled(): ?bool | setIsCancelled(?bool isCancelled): void |
| `trainingType` | `?int` | Optional | - | getTrainingType(): ?int | setTrainingType(?int trainingType): void |
| `autoDeployThreshold` | `?float` | Optional | - | getAutoDeployThreshold(): ?float | setAutoDeployThreshold(?float autoDeployThreshold): void |
| `baselineBleuScorePunctuated` | `?float` | Optional | - | getBaselineBleuScorePunctuated(): ?float | setBaselineBleuScorePunctuated(?float baselineBleuScorePunctuated): void |
| `bleuScorePunctuated` | `?float` | Optional | - | getBleuScorePunctuated(): ?float | setBleuScorePunctuated(?float bleuScorePunctuated): void |
| `baselineBleuScoreUnpunctuated` | `?float` | Optional | - | getBaselineBleuScoreUnpunctuated(): ?float | setBaselineBleuScoreUnpunctuated(?float baselineBleuScoreUnpunctuated): void |
| `bleuScoreUnpunctuated` | `?float` | Optional | - | getBleuScoreUnpunctuated(): ?float | setBleuScoreUnpunctuated(?float bleuScoreUnpunctuated): void |
| `baselineBleuScoreCipunctuated` | `?float` | Optional | - | getBaselineBleuScoreCipunctuated(): ?float | setBaselineBleuScoreCipunctuated(?float baselineBleuScoreCipunctuated): void |
| `bleuScoreCipunctuated` | `?float` | Optional | - | getBleuScoreCipunctuated(): ?float | setBleuScoreCipunctuated(?float bleuScoreCipunctuated): void |
| `baselineBleuScoreCiunpunctuated` | `?float` | Optional | - | getBaselineBleuScoreCiunpunctuated(): ?float | setBaselineBleuScoreCiunpunctuated(?float baselineBleuScoreCiunpunctuated): void |
| `bleuScoreCiunpunctuated` | `?float` | Optional | - | getBleuScoreCiunpunctuated(): ?float | setBleuScoreCiunpunctuated(?float bleuScoreCiunpunctuated): void |
| `errorCode` | `?string` | Optional | - | getErrorCode(): ?string | setErrorCode(?string errorCode): void |
| `createdByNavigation` | [`?TextTranslatorDALApplicationUser`](../../doc/models/text-translator-dal-application-user.md) | Optional | - | getCreatedByNavigation(): ?TextTranslatorDALApplicationUser | setCreatedByNavigation(?TextTranslatorDALApplicationUser createdByNavigation): void |
| `modifiedByNavigation` | [`?TextTranslatorDALApplicationUser`](../../doc/models/text-translator-dal-application-user.md) | Optional | - | getModifiedByNavigation(): ?TextTranslatorDALApplicationUser | setModifiedByNavigation(?TextTranslatorDALApplicationUser modifiedByNavigation): void |
| `project` | [`?TextTranslatorDALProject`](../../doc/models/text-translator-dal-project.md) | Optional | - | getProject(): ?TextTranslatorDALProject | setProject(?TextTranslatorDALProject project): void |
| `modelDocuments` | [`?(TextTranslatorDALModelDocuments[])`](../../doc/models/text-translator-dal-model-documents.md) | Optional | - | getModelDocuments(): ?array | setModelDocuments(?array modelDocuments): void |
| `processedDocuments` | [`?(TextTranslatorDALProcessedDocument[])`](../../doc/models/text-translator-dal-processed-document.md) | Optional | - | getProcessedDocuments(): ?array | setProcessedDocuments(?array processedDocuments): void |
| `tests` | [`?(TextTranslatorDALTest[])`](../../doc/models/text-translator-dal-test.md) | Optional | - | getTests(): ?array | setTests(?array tests): void |
| `migrationTrainingHistories` | [`?(TextTranslatorDALMigrationTrainingHistory[])`](../../doc/models/text-translator-dal-migration-training-history.md) | Optional | - | getMigrationTrainingHistories(): ?array | setMigrationTrainingHistories(?array migrationTrainingHistories): void |
| `modelRegionStatuses` | [`?(TextTranslatorDALModelRegionStatus[])`](../../doc/models/text-translator-dal-model-region-status.md) | Optional | - | getModelRegionStatuses(): ?array | setModelRegionStatuses(?array modelRegionStatuses): void |
| `unsupportedDeployedHubModels` | [`?(TextTranslatorDALUnsupportedDeployedHubModel[])`](../../doc/models/text-translator-dal-unsupported-deployed-hub-model.md) | Optional | - | getUnsupportedDeployedHubModels(): ?array | setUnsupportedDeployedHubModels(?array unsupportedDeployedHubModels): void |

## Example (as JSON)

```json
{
  "id": null,
  "projectId": null,
  "name": null,
  "modelStatus": null,
  "statusInfo": null,
  "isWhitelisted": null,
  "isHidden": null,
  "resetAutoTestingDataset": null,
  "resetAutoTuningDataset": null,
  "tuningSentenceCount": null,
  "testingSentenceCount": null,
  "createdBy": null,
  "modifiedBy": null,
  "createdDate": null,
  "modifiedDate": null,
  "startDate": null,
  "completionDate": null,
  "isAutoDeploy": null,
  "isCancelled": null,
  "trainingType": null,
  "autoDeployThreshold": null,
  "baselineBleuScorePunctuated": null,
  "bleuScorePunctuated": null,
  "baselineBleuScoreUnpunctuated": null,
  "bleuScoreUnpunctuated": null,
  "baselineBleuScoreCipunctuated": null,
  "bleuScoreCipunctuated": null,
  "baselineBleuScoreCiunpunctuated": null,
  "bleuScoreCiunpunctuated": null,
  "errorCode": null,
  "createdByNavigation": null,
  "modifiedByNavigation": null,
  "project": null,
  "modelDocuments": null,
  "processedDocuments": null,
  "tests": null,
  "migrationTrainingHistories": null,
  "modelRegionStatuses": null,
  "unsupportedDeployedHubModels": null
}
```

