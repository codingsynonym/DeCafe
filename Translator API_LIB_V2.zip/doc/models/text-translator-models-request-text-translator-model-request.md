
# Text Translator Models Request Text Translator Model Request

The input class for model requests.

## Structure

`TextTranslatorModelsRequestTextTranslatorModelRequest`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `name` | `string` | Required | Gets or sets Name | getName(): string | setName(string name): void |
| `projectId` | `string` | Required | Gets or sets the Id of the project to which the model belongs. | getProjectId(): string | setProjectId(string projectId): void |
| `documentIds` | `?(int[])` | Optional | List of DocumentIds | getDocumentIds(): ?array | setDocumentIds(?array documentIds): void |
| `isTuningAuto` | `?bool` | Optional | Gets or sets IsTuningAuto | getIsTuningAuto(): ?bool | setIsTuningAuto(?bool isTuningAuto): void |
| `isTestingAuto` | `?bool` | Optional | Gets or sets IsTestingAuto | getIsTestingAuto(): ?bool | setIsTestingAuto(?bool isTestingAuto): void |
| `isAutoDeploy` | `?bool` | Optional | Gets or sets IsAutoDeploy | getIsAutoDeploy(): ?bool | setIsAutoDeploy(?bool isAutoDeploy): void |
| `isAutoTrain` | `?bool` | Optional | Gets or sets IsAutoTrain. If AutoTrain is not set,<br>defaults to true. If AutoTrain is set to false,<br>it will create the model in a draft state. | getIsAutoTrain(): ?bool | setIsAutoTrain(?bool isAutoTrain): void |
| `autoDeployThreshold` | `?float` | Optional | Gets or sets the auto deployment bleu score diff threshold. Auto-deploy will occur when the<br>bleu score threshold meets or exceeds the specified minimum. | getAutoDeployThreshold(): ?float | setAutoDeployThreshold(?float autoDeployThreshold): void |

## Example (as JSON)

```json
{
  "name": "name0",
  "projectId": "0000172a-0000-0000-0000-000000000000",
  "documentIds": null,
  "isTuningAuto": null,
  "isTestingAuto": null,
  "isAutoDeploy": null,
  "isAutoTrain": null,
  "autoDeployThreshold": null
}
```

