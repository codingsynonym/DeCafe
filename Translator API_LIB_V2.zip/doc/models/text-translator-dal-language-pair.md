
# Text Translator DAL Language Pair

## Structure

`TextTranslatorDALLanguagePair`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `id` | `?int` | Optional | - | getId(): ?int | setId(?int id): void |
| `sourceLanguageId` | `?int` | Optional | - | getSourceLanguageId(): ?int | setSourceLanguageId(?int sourceLanguageId): void |
| `targetLanguageId` | `?int` | Optional | - | getTargetLanguageId(): ?int | setTargetLanguageId(?int targetLanguageId): void |
| `isAvailable` | `?bool` | Optional | - | getIsAvailable(): ?bool | setIsAvailable(?bool isAvailable): void |
| `sourceLanguage` | [`?TextTranslatorDALLanguage`](../../doc/models/text-translator-dal-language.md) | Optional | - | getSourceLanguage(): ?TextTranslatorDALLanguage | setSourceLanguage(?TextTranslatorDALLanguage sourceLanguage): void |
| `targetLanguage` | [`?TextTranslatorDALLanguage`](../../doc/models/text-translator-dal-language.md) | Optional | - | getTargetLanguage(): ?TextTranslatorDALLanguage | setTargetLanguage(?TextTranslatorDALLanguage targetLanguage): void |
| `project` | [`?(TextTranslatorDALProject[])`](../../doc/models/text-translator-dal-project.md) | Optional | - | getProject(): ?array | setProject(?array project): void |

## Example (as JSON)

```json
{
  "id": null,
  "sourceLanguageId": null,
  "targetLanguageId": null,
  "isAvailable": null,
  "sourceLanguage": null,
  "targetLanguage": null,
  "project": null
}
```

