
# Text Translator DAL Application

## Structure

`TextTranslatorDALApplication`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `id` | `?int` | Optional | - | getId(): ?int | setId(?int id): void |
| `applicationName` | `?string` | Optional | - | getApplicationName(): ?string | setApplicationName(?string applicationName): void |
| `applicationIdentifier` | `?string` | Optional | - | getApplicationIdentifier(): ?string | setApplicationIdentifier(?string applicationIdentifier): void |
| `createdDate` | `?\DateTime` | Optional | - | getCreatedDate(): ?\DateTime | setCreatedDate(?\DateTime createdDate): void |
| `createdBy` | `?string` | Optional | - | getCreatedBy(): ?string | setCreatedBy(?string createdBy): void |
| `modifiedDate` | `?\DateTime` | Optional | - | getModifiedDate(): ?\DateTime | setModifiedDate(?\DateTime modifiedDate): void |
| `modifiedBy` | `?string` | Optional | - | getModifiedBy(): ?string | setModifiedBy(?string modifiedBy): void |
| `createdByNavigation` | [`?TextTranslatorDALApplicationUser`](../../doc/models/text-translator-dal-application-user.md) | Optional | - | getCreatedByNavigation(): ?TextTranslatorDALApplicationUser | setCreatedByNavigation(?TextTranslatorDALApplicationUser createdByNavigation): void |
| `applicationSubscriptions` | [`?(TextTranslatorDALApplicationSubscriptions[])`](../../doc/models/text-translator-dal-application-subscriptions.md) | Optional | - | getApplicationSubscriptions(): ?array | setApplicationSubscriptions(?array applicationSubscriptions): void |
| `document` | [`?(TextTranslatorDALDocument[])`](../../doc/models/text-translator-dal-document.md) | Optional | - | getDocument(): ?array | setDocument(?array document): void |
| `file` | [`?(TextTranslatorDALFile[])`](../../doc/models/text-translator-dal-file.md) | Optional | - | getFile(): ?array | setFile(?array file): void |
| `project` | [`?(TextTranslatorDALProject[])`](../../doc/models/text-translator-dal-project.md) | Optional | - | getProject(): ?array | setProject(?array project): void |
| `uploadHistory` | [`?(TextTranslatorDALUploadHistory[])`](../../doc/models/text-translator-dal-upload-history.md) | Optional | - | getUploadHistory(): ?array | setUploadHistory(?array uploadHistory): void |
| `applicationSharings` | [`?(TextTranslatorDALApplicationSharing[])`](../../doc/models/text-translator-dal-application-sharing.md) | Optional | - | getApplicationSharings(): ?array | setApplicationSharings(?array applicationSharings): void |
| `applicationCredit` | [`?(TextTranslatorDALApplicationCredit[])`](../../doc/models/text-translator-dal-application-credit.md) | Optional | - | getApplicationCredit(): ?array | setApplicationCredit(?array applicationCredit): void |

## Example (as JSON)

```json
{
  "id": null,
  "applicationName": null,
  "applicationIdentifier": null,
  "createdDate": null,
  "createdBy": null,
  "modifiedDate": null,
  "modifiedBy": null,
  "createdByNavigation": null,
  "applicationSubscriptions": null,
  "document": null,
  "file": null,
  "project": null,
  "uploadHistory": null,
  "applicationSharings": null,
  "applicationCredit": null
}
```

