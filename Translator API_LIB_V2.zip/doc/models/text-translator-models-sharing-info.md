
# Text Translator Models Sharing Info

Information about a user that has permissions to a workspace.

## Structure

`TextTranslatorModelsSharingInfo`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `id` | `int` | Required | Gets or sets the share id | getId(): int | setId(int id): void |
| `user` | [`TextTranslatorModelsResponseShareUserInfo`](../../doc/models/text-translator-models-response-share-user-info.md) | Required | Information about each user a workspace<br>has been shared with. Because the user's UserName<br>may not be yet known (if they haven't signed into<br>Custom Translator yet), returns EmailAddress instead. | getUser(): TextTranslatorModelsResponseShareUserInfo | setUser(TextTranslatorModelsResponseShareUserInfo user): void |
| `role` | [`TextTranslatorModelsRoleInfo`](../../doc/models/text-translator-models-role-info.md) | Required | Information about a users role in a workspace. | getRole(): TextTranslatorModelsRoleInfo | setRole(TextTranslatorModelsRoleInfo role): void |

## Example (as JSON)

```json
{
  "id": 112,
  "user": {
    "id": "0000143c-0000-0000-0000-000000000000",
    "emailAddress": "emailAddress0"
  },
  "role": {
    "id": 30,
    "roleName": "roleName0"
  }
}
```

