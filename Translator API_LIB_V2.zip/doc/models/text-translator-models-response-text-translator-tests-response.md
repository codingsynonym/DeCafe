
# Text Translator Models Response Text Translator Tests Response

Result container for tests.

## Structure

`TextTranslatorModelsResponseTextTranslatorTestsResponse`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `tests` | [`TextTranslatorModelsTextTranslatorTestInfo[]`](../../doc/models/text-translator-models-text-translator-test-info.md) | Required | Gets or sets Tests | getTests(): array | setTests(array tests): void |
| `pageIndex` | `int` | Required | Gets or sets the page index. | getPageIndex(): int | setPageIndex(int pageIndex): void |
| `totalPageCount` | `int` | Required | Gets or sets the total number of pages. | getTotalPageCount(): int | setTotalPageCount(int totalPageCount): void |

## Example (as JSON)

```json
{
  "tests": [
    {
      "id": 146,
      "name": "name4",
      "modelId": 74,
      "status": "complete",
      "baselineBleuScorePunctuated": null,
      "bleuScorePunctuated": null,
      "baselineBleuScoreUnpunctuated": null,
      "bleuScoreUnpunctuated": null,
      "baselineBleuScoreCIPunctuated": null,
      "bleuScoreCIPunctuated": null,
      "baselineBleuScoreCIUnpunctuated": null,
      "bleuScoreCIUnpunctuated": null,
      "sentenceCount": null,
      "createdBy": {
        "id": "00001fb6-0000-0000-0000-000000000000",
        "userName": "userName0"
      },
      "modifiedBy": {
        "id": "0000202c-0000-0000-0000-000000000000",
        "userName": "userName8"
      }
    },
    {
      "id": 147,
      "name": "name5",
      "modelId": 73,
      "status": "testing",
      "baselineBleuScorePunctuated": null,
      "bleuScorePunctuated": null,
      "baselineBleuScoreUnpunctuated": null,
      "bleuScoreUnpunctuated": null,
      "baselineBleuScoreCIPunctuated": null,
      "bleuScoreCIPunctuated": null,
      "baselineBleuScoreCIUnpunctuated": null,
      "bleuScoreCIUnpunctuated": null,
      "sentenceCount": null,
      "createdBy": {
        "id": "00001fb5-0000-0000-0000-000000000000",
        "userName": "userName9"
      },
      "modifiedBy": {
        "id": "0000202b-0000-0000-0000-000000000000",
        "userName": "userName7"
      }
    },
    {
      "id": 148,
      "name": "name6",
      "modelId": 72,
      "status": "deploying",
      "baselineBleuScorePunctuated": null,
      "bleuScorePunctuated": null,
      "baselineBleuScoreUnpunctuated": null,
      "bleuScoreUnpunctuated": null,
      "baselineBleuScoreCIPunctuated": null,
      "bleuScoreCIPunctuated": null,
      "baselineBleuScoreCIUnpunctuated": null,
      "bleuScoreCIUnpunctuated": null,
      "sentenceCount": null,
      "createdBy": {
        "id": "00001fb4-0000-0000-0000-000000000000",
        "userName": "userName8"
      },
      "modifiedBy": {
        "id": "0000202a-0000-0000-0000-000000000000",
        "userName": "userName6"
      }
    }
  ],
  "pageIndex": 166,
  "totalPageCount": 32
}
```

