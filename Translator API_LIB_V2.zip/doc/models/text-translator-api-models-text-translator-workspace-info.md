
# Text Translator Api Models Text Translator Workspace Info

Metadata about an individual workspace

## Structure

`TextTranslatorApiModelsTextTranslatorWorkspaceInfo`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `id` | `?string` | Optional | Gets or sets the workspace id. | getId(): ?string | setId(?string id): void |
| `role` | [`?TextTranslatorModelsRoleInfo`](../../doc/models/text-translator-models-role-info.md) | Optional | Information about a users role in a workspace. | getRole(): ?TextTranslatorModelsRoleInfo | setRole(?TextTranslatorModelsRoleInfo role): void |
| `name` | `?string` | Optional | Gets or sets the name of the workspace. | getName(): ?string | setName(?string name): void |
| `isCreator` | `?bool` | Optional | Gets or sets if this user is the creator of the workspace. | getIsCreator(): ?bool | setIsCreator(?bool isCreator): void |
| `isDefaultWorkspace` | `?bool` | Optional | Gets or sets if this user has this workspace set as their default workspace. | getIsDefaultWorkspace(): ?bool | setIsDefaultWorkspace(?bool isDefaultWorkspace): void |
| `createdBy` | [`?TextTranslatorModelsResponseUserInfo`](../../doc/models/text-translator-models-response-user-info.md) | Optional | Basic user information - object used for<br>CreatedBy/ModifiedBy response fields | getCreatedBy(): ?TextTranslatorModelsResponseUserInfo | setCreatedBy(?TextTranslatorModelsResponseUserInfo createdBy): void |
| `createdDate` | `?\DateTime` | Optional | Gets or sets when the workspace was created. | getCreatedDate(): ?\DateTime | setCreatedDate(?\DateTime createdDate): void |
| `sharing` | [`?(TextTranslatorModelsSharingInfo[])`](../../doc/models/text-translator-models-sharing-info.md) | Optional | Gets or sets the information about who this workspace is shared with. | getSharing(): ?array | setSharing(?array sharing): void |
| `hasMigrations` | `?bool` | Optional | Gets or sets if the current workspace has any migrations. | getHasMigrations(): ?bool | setHasMigrations(?bool hasMigrations): void |
| `region` | [`?TextTranslatorModelsTextTranslatorBillingRegions`](../../doc/models/text-translator-models-text-translator-billing-regions.md) | Optional | Defines the a billing region | getRegion(): ?TextTranslatorModelsTextTranslatorBillingRegions | setRegion(?TextTranslatorModelsTextTranslatorBillingRegions region): void |
| `subscription` | [`?TextTranslatorModelsTextTranslatorSubscriptionResponse`](../../doc/models/text-translator-models-text-translator-subscription-response.md) | Optional | Defines an application subscription. | getSubscription(): ?TextTranslatorModelsTextTranslatorSubscriptionResponse | setSubscription(?TextTranslatorModelsTextTranslatorSubscriptionResponse subscription): void |

## Example (as JSON)

```json
{
  "id": null,
  "role": null,
  "name": null,
  "isCreator": null,
  "isDefaultWorkspace": null,
  "createdBy": null,
  "createdDate": null,
  "sharing": null,
  "hasMigrations": null,
  "region": null,
  "subscription": null
}
```

