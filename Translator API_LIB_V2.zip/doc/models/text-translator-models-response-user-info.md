
# Text Translator Models Response User Info

Basic user information - object used for
CreatedBy/ModifiedBy response fields

## Structure

`TextTranslatorModelsResponseUserInfo`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `id` | `string` | Required | Gets or Sets the User Id | getId(): string | setId(string id): void |
| `userName` | `string` | Required | Gets or Sets the User Name | getUserName(): string | setUserName(string userName): void |

## Example (as JSON)

```json
{
  "id": "00001770-0000-0000-0000-000000000000",
  "userName": "userName2"
}
```

