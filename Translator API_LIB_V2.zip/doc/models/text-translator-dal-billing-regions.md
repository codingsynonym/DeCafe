
# Text Translator DAL Billing Regions

## Structure

`TextTranslatorDALBillingRegions`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `billingRegionCode` | `?string` | Optional | - | getBillingRegionCode(): ?string | setBillingRegionCode(?string billingRegionCode): void |
| `billingRegionName` | `?string` | Optional | - | getBillingRegionName(): ?string | setBillingRegionName(?string billingRegionName): void |
| `billingEndpoint` | `?string` | Optional | - | getBillingEndpoint(): ?string | setBillingEndpoint(?string billingEndpoint): void |
| `monitoringStorageAccountName` | `?string` | Optional | - | getMonitoringStorageAccountName(): ?string | setMonitoringStorageAccountName(?string monitoringStorageAccountName): void |
| `meteringKeySecretName` | `?string` | Optional | - | getMeteringKeySecretName(): ?string | setMeteringKeySecretName(?string meteringKeySecretName): void |
| `applicationSubscriptionsBillingRegion` | [`?(TextTranslatorDALApplicationSubscriptions[])`](../../doc/models/text-translator-dal-application-subscriptions.md) | Optional | - | getApplicationSubscriptionsBillingRegion(): ?array | setApplicationSubscriptionsBillingRegion(?array applicationSubscriptionsBillingRegion): void |
| `applicationSubscriptionsDataRegion` | [`?(TextTranslatorDALApplicationSubscriptions[])`](../../doc/models/text-translator-dal-application-subscriptions.md) | Optional | - | getApplicationSubscriptionsDataRegion(): ?array | setApplicationSubscriptionsDataRegion(?array applicationSubscriptionsDataRegion): void |

## Example (as JSON)

```json
{
  "billingRegionCode": null,
  "billingRegionName": null,
  "billingEndpoint": null,
  "monitoringStorageAccountName": null,
  "meteringKeySecretName": null,
  "applicationSubscriptionsBillingRegion": null,
  "applicationSubscriptionsDataRegion": null
}
```

