
# Text Translator Models Response Text Translator Model Update Response

Contains the update model information.

## Structure

`TextTranslatorModelsResponseTextTranslatorModelUpdateResponse`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `name` | `string` | Required | Gets or sets the updated model name. | getName(): string | setName(string name): void |
| `documents` | `int[]` | Required | Gets or sets the ids used by the model | getDocuments(): array | setDocuments(array documents): void |

## Example (as JSON)

```json
{
  "name": "name0",
  "documents": [
    223,
    224,
    225
  ]
}
```

