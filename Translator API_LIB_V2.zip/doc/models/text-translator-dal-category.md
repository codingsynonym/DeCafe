
# Text Translator DAL Category

## Structure

`TextTranslatorDALCategory`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `id` | `?int` | Optional | - | getId(): ?int | setId(?int id): void |
| `name` | `?string` | Optional | - | getName(): ?string | setName(?string name): void |
| `code` | `?string` | Optional | - | getCode(): ?string | setCode(?string code): void |
| `project` | [`?(TextTranslatorDALProject[])`](../../doc/models/text-translator-dal-project.md) | Optional | - | getProject(): ?array | setProject(?array project): void |

## Example (as JSON)

```json
{
  "id": null,
  "name": null,
  "code": null,
  "project": null
}
```

