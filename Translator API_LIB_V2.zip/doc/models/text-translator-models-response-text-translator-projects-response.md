
# Text Translator Models Response Text Translator Projects Response

A container for project results.

## Structure

`TextTranslatorModelsResponseTextTranslatorProjectsResponse`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `projects` | [`TextTranslatorModelsTextTranslatorProjectInfo[]`](../../doc/models/text-translator-models-text-translator-project-info.md) | Required | Gets or sets projects | getProjects(): array | setProjects(array projects): void |
| `pageIndex` | `int` | Required | Gets or sets the page index. | getPageIndex(): int | setPageIndex(int pageIndex): void |
| `totalPageCount` | `int` | Required | Gets or sets the total number of pages. | getTotalPageCount(): int | setTotalPageCount(int totalPageCount): void |

## Example (as JSON)

```json
{
  "projects": [
    {
      "id": "0000000b-0000-0000-0000-000000000000",
      "name": "name1",
      "label": null,
      "description": null,
      "languagePair": {
        "id": null,
        "sourceLanguage": {
          "id": 93,
          "displayName": "displayName5",
          "languageCode": "languageCode3"
        },
        "targetLanguage": {
          "id": 253,
          "displayName": "displayName9",
          "languageCode": "languageCode9"
        }
      },
      "category": {
        "id": 195,
        "name": "name9"
      },
      "categoryDescriptor": null,
      "baselineBleuScoreCIPunctuated": null,
      "bleuScoreCIPunctuated": null,
      "status": "deploymentFailed",
      "modifiedDate": "2016-03-13T12:52:32.123Z",
      "createdDate": "2016-03-13T12:52:32.123Z",
      "createdBy": {
        "id": "0000120d-0000-0000-0000-000000000000",
        "userName": "userName3"
      },
      "modifiedBy": {
        "id": "00001c5d-0000-0000-0000-000000000000",
        "userName": "userName3"
      },
      "apiDomain": "apiDomain1",
      "isAvailable": true,
      "hubCategory": null,
      "hasFreeTraining": true,
      "modelRegionStatus": null
    },
    {
      "id": "0000000c-0000-0000-0000-000000000000",
      "name": "name2",
      "label": null,
      "description": null,
      "languagePair": {
        "id": null,
        "sourceLanguage": {
          "id": 94,
          "displayName": "displayName4",
          "languageCode": "languageCode4"
        },
        "targetLanguage": {
          "id": 252,
          "displayName": "displayName0",
          "languageCode": "languageCode8"
        }
      },
      "category": {
        "id": 196,
        "name": "name0"
      },
      "categoryDescriptor": null,
      "baselineBleuScoreCIPunctuated": null,
      "bleuScoreCIPunctuated": null,
      "status": "dataProcessingFailed",
      "modifiedDate": "2016-03-13T12:52:32.123Z",
      "createdDate": "2016-03-13T12:52:32.123Z",
      "createdBy": {
        "id": "0000120c-0000-0000-0000-000000000000",
        "userName": "userName2"
      },
      "modifiedBy": {
        "id": "00001c5e-0000-0000-0000-000000000000",
        "userName": "userName4"
      },
      "apiDomain": "apiDomain2",
      "isAvailable": false,
      "hubCategory": null,
      "hasFreeTraining": false,
      "modelRegionStatus": null
    }
  ],
  "pageIndex": 166,
  "totalPageCount": 32
}
```

