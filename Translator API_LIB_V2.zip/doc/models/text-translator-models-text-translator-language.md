
# Text Translator Models Text Translator Language

Defines a language that can be used in the text translator.

## Structure

`TextTranslatorModelsTextTranslatorLanguage`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `id` | `int` | Required | The Id of the language | getId(): int | setId(int id): void |
| `displayName` | `string` | Required | The Display Name of the language | getDisplayName(): string | setDisplayName(string displayName): void |
| `languageCode` | `string` | Required | The ISO code of the language | getLanguageCode(): string | setLanguageCode(string languageCode): void |

## Example (as JSON)

```json
{
  "id": 112,
  "displayName": "displayName2",
  "languageCode": "languageCode6"
}
```

