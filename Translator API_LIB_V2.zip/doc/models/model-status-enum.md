
# Model Status Enum

The status of the model training.

## Enumeration

`ModelStatusEnum`

## Fields

| Name |
|  --- |
| `UNKNOWN` |
| `DATAPROCESSING` |
| `SUBMITTED` |
| `TRAININGQUEUED` |
| `RUNNING` |
| `SUCCEEDED` |
| `TRAININGFAILED` |
| `DEPLOYING` |
| `DEPLOYED` |
| `UNDEPLOYING` |
| `UNDEPLOYED` |
| `DATAPROCESSINGFAILED` |
| `DEPLOYMENTFAILED` |
| `MIGRATEDDRAFT` |
| `UPDATINGDEPLOYMENT` |
| `DRAFT` |
| `HUBDEPLOYED` |

