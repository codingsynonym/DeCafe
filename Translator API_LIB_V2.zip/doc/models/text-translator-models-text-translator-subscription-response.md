
# Text Translator Models Text Translator Subscription Response

Defines an application subscription.

## Structure

`TextTranslatorModelsTextTranslatorSubscriptionResponse`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `id` | `?string` | Optional | Subscription id | getId(): ?string | setId(?string id): void |
| `name` | `?string` | Optional | Name of users Azure resource | getName(): ?string | setName(?string name): void |
| `kind` | `?string` | Optional | Kind of subscription<br>Example: TextTranslation | getKind(): ?string | setKind(?string kind): void |
| `sku` | `?string` | Optional | Subscription SKU type<br>Example: S1 | getSku(): ?string | setSku(?string sku): void |
| `isCMKEnabled` | `?bool` | Optional | If CMK is enabled on this subscription | getIsCMKEnabled(): ?bool | setIsCMKEnabled(?bool isCMKEnabled): void |
| `region` | [`?TextTranslatorModelsTextTranslatorBillingRegions`](../../doc/models/text-translator-models-text-translator-billing-regions.md) | Optional | Defines the a billing region | getRegion(): ?TextTranslatorModelsTextTranslatorBillingRegions | setRegion(?TextTranslatorModelsTextTranslatorBillingRegions region): void |
| `billing` | [`?TextTranslatorUtilitiesTrainingPriceInformation`](../../doc/models/text-translator-utilities-training-price-information.md) | Optional | - | getBilling(): ?TextTranslatorUtilitiesTrainingPriceInformation | setBilling(?TextTranslatorUtilitiesTrainingPriceInformation billing): void |

## Example (as JSON)

```json
{
  "id": null,
  "name": null,
  "kind": null,
  "sku": null,
  "isCMKEnabled": null,
  "region": null,
  "billing": null
}
```

