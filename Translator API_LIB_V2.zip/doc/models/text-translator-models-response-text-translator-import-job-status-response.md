
# Text Translator Models Response Text Translator Import Job Status Response

ImportJobStatus Response - POCO object

## Structure

`TextTranslatorModelsResponseTextTranslatorImportJobStatusResponse`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `jobName` | `string` | Required | Gets or sets the name for the job overall | getJobName(): string | setJobName(string jobName): void |
| `fileProcessingStatus` | [`TextTranslatorApiModelsResponseTextTranslatorImportJobFileStatusInfo[]`](../../doc/models/text-translator-api-models-response-text-translator-import-job-file-status-info.md) | Required | Gets or sets the file processing status. | getFileProcessingStatus(): array | setFileProcessingStatus(array fileProcessingStatus): void |
| `pageIndex` | `int` | Required | Gets or sets the page index. | getPageIndex(): int | setPageIndex(int pageIndex): void |
| `totalPageCount` | `int` | Required | Gets or sets the total number of pages. | getTotalPageCount(): int | setTotalPageCount(int totalPageCount): void |

## Example (as JSON)

```json
{
  "jobName": "jobName6",
  "fileProcessingStatus": [
    {
      "status": null,
      "modifiedDate": null,
      "fileName": null,
      "documentName": null,
      "summary": null,
      "id": null,
      "parentId": null,
      "language": null
    }
  ],
  "pageIndex": 166,
  "totalPageCount": 32
}
```

