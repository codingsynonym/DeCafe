
# Microsoft Asp Net Core Http I Form File

## Structure

`MicrosoftAspNetCoreHttpIFormFile`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `contentType` | `?string` | Optional | - | getContentType(): ?string | setContentType(?string contentType): void |
| `contentDisposition` | `?string` | Optional | - | getContentDisposition(): ?string | setContentDisposition(?string contentDisposition): void |
| `headers` | `?array` | Optional | - | getHeaders(): ?array | setHeaders(?array headers): void |
| `length` | `?int` | Optional | - | getLength(): ?int | setLength(?int length): void |
| `name` | `?string` | Optional | - | getName(): ?string | setName(?string name): void |
| `fileName` | `?string` | Optional | - | getFileName(): ?string | setFileName(?string fileName): void |

## Example (as JSON)

```json
{
  "contentType": null,
  "contentDisposition": null,
  "headers": null,
  "length": null,
  "name": null,
  "fileName": null
}
```

