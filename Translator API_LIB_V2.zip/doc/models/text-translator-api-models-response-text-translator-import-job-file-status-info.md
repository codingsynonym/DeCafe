
# Text Translator Api Models Response Text Translator Import Job File Status Info

Text Translator Import Job File Status

## Structure

`TextTranslatorApiModelsResponseTextTranslatorImportJobFileStatusInfo`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `status` | [`?TextTranslatorModelsTextTranslatorImportJobStatus`](../../doc/models/text-translator-models-text-translator-import-job-status.md) | Optional | Defines the status of an import job. | getStatus(): ?TextTranslatorModelsTextTranslatorImportJobStatus | setStatus(?TextTranslatorModelsTextTranslatorImportJobStatus status): void |
| `modifiedDate` | `?\DateTime` | Optional | Gets or sets the date the upload status was last modified | getModifiedDate(): ?\DateTime | setModifiedDate(?\DateTime modifiedDate): void |
| `fileName` | `?string` | Optional | Gets or sets the name of the file. | getFileName(): ?string | setFileName(?string fileName): void |
| `documentName` | `?string` | Optional | Gets or sets the name of the document. | getDocumentName(): ?string | setDocumentName(?string documentName): void |
| `summary` | `?string` | Optional | Gets or sets the summary. | getSummary(): ?string | setSummary(?string summary): void |
| `id` | `?int` | Optional | Gets or sets the identifier. | getId(): ?int | setId(?int id): void |
| `parentId` | `?int` | Optional | Gets or sets the parent identifier. | getParentId(): ?int | setParentId(?int parentId): void |
| `language` | [`?TextTranslatorModelsTextTranslatorLanguage`](../../doc/models/text-translator-models-text-translator-language.md) | Optional | Defines a language that can be used in the text translator. | getLanguage(): ?TextTranslatorModelsTextTranslatorLanguage | setLanguage(?TextTranslatorModelsTextTranslatorLanguage language): void |

## Example (as JSON)

```json
{
  "status": null,
  "modifiedDate": null,
  "fileName": null,
  "documentName": null,
  "summary": null,
  "id": null,
  "parentId": null,
  "language": null
}
```

