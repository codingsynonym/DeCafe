
# Text Translator DAL Project Billing Audit

## Structure

`TextTranslatorDALProjectBillingAudit`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `id` | `?int` | Optional | - | getId(): ?int | setId(?int id): void |
| `billingDate` | `?\DateTime` | Optional | - | getBillingDate(): ?\DateTime | setBillingDate(?\DateTime billingDate): void |
| `billingType` | `?string` | Optional | - | getBillingType(): ?string | setBillingType(?string billingType): void |
| `description` | `?string` | Optional | - | getDescription(): ?string | setDescription(?string description): void |
| `project` | [`?TextTranslatorDALProject`](../../doc/models/text-translator-dal-project.md) | Optional | - | getProject(): ?TextTranslatorDALProject | setProject(?TextTranslatorDALProject project): void |
| `projectId` | `?string` | Optional | - | getProjectId(): ?string | setProjectId(?string projectId): void |

## Example (as JSON)

```json
{
  "id": null,
  "billingDate": null,
  "billingType": null,
  "description": null,
  "project": null,
  "projectId": null
}
```

