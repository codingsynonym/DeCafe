
# Text Translator Models Role Info

Information about a users role in a workspace.

## Structure

`TextTranslatorModelsRoleInfo`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `id` | `int` | Required | Gets or sets the id for this role. | getId(): int | setId(int id): void |
| `roleName` | `string` | Required | Gets or sets the name of this role. | getRoleName(): string | setRoleName(string roleName): void |

## Example (as JSON)

```json
{
  "id": 112,
  "roleName": "roleName6"
}
```

