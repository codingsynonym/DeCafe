
# Text Translator Models Text Translator Document Instance

A class containing references to documents and corresponding processed documents.

## Structure

`TextTranslatorModelsTextTranslatorDocumentInstance`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `documentInfo` | [`?TextTranslatorModelsTextTranslatorDocumentInfo`](../../doc/models/text-translator-models-text-translator-document-info.md) | Optional | Class containing detailed information about document. | getDocumentInfo(): ?TextTranslatorModelsTextTranslatorDocumentInfo | setDocumentInfo(?TextTranslatorModelsTextTranslatorDocumentInfo documentInfo): void |
| `processedDocumentInfo` | [`?TextTranslatorModelsTextTranslatorProcessedDocumentInfo`](../../doc/models/text-translator-models-text-translator-processed-document-info.md) | Optional | A class containing information related to the document after it has been processed in a specific model training | getProcessedDocumentInfo(): ?TextTranslatorModelsTextTranslatorProcessedDocumentInfo | setProcessedDocumentInfo(?TextTranslatorModelsTextTranslatorProcessedDocumentInfo processedDocumentInfo): void |

## Example (as JSON)

```json
{
  "documentInfo": null,
  "processedDocumentInfo": null
}
```

