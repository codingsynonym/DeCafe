
# Status 1 Enum

Gets or sets Status

## Enumeration

`Status1Enum`

## Fields

| Name |
|  --- |
| `UNKNOWN` |
| `DATAPROCESSING` |
| `SUBMITTED` |
| `TRAININGQUEUED` |
| `RUNNING` |
| `SUCCEEDED` |
| `TRAININGFAILED` |
| `DEPLOYING` |
| `DEPLOYED` |
| `UNDEPLOYING` |
| `UNDEPLOYED` |
| `DATAPROCESSINGFAILED` |
| `DEPLOYMENTFAILED` |
| `MIGRATEDDRAFT` |
| `UPDATINGDEPLOYMENT` |
| `DRAFT` |
| `HUBDEPLOYED` |

