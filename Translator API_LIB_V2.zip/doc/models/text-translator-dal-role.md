
# Text Translator DAL Role

## Structure

`TextTranslatorDALRole`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `id` | `?int` | Optional | - | getId(): ?int | setId(?int id): void |
| `roleName` | `?string` | Optional | - | getRoleName(): ?string | setRoleName(?string roleName): void |
| `applicationSharings` | [`?(TextTranslatorDALApplicationSharing[])`](../../doc/models/text-translator-dal-application-sharing.md) | Optional | - | getApplicationSharings(): ?array | setApplicationSharings(?array applicationSharings): void |

## Example (as JSON)

```json
{
  "id": null,
  "roleName": null,
  "applicationSharings": null
}
```

