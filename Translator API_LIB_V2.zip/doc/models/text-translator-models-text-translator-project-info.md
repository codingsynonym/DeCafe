
# Text Translator Models Text Translator Project Info

## Structure

`TextTranslatorModelsTextTranslatorProjectInfo`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `id` | `string` | Required | Gets or sets Id | getId(): string | setId(string id): void |
| `name` | `string` | Required | Gets or sets Name | getName(): string | setName(string name): void |
| `label` | `?string` | Optional | Gets or sets the ProjectLabel | getLabel(): ?string | setLabel(?string label): void |
| `description` | `?string` | Optional | Gets or sets Description | getDescription(): ?string | setDescription(?string description): void |
| `languagePair` | [`TextTranslatorModelsLanguagePair`](../../doc/models/text-translator-models-language-pair.md) | Required | A language pair that is supported by the text translator for transalation. | getLanguagePair(): TextTranslatorModelsLanguagePair | setLanguagePair(TextTranslatorModelsLanguagePair languagePair): void |
| `category` | [`TextTranslatorModelsTextTranslatorCategory`](../../doc/models/text-translator-models-text-translator-category.md) | Required | Defines a category of the project. | getCategory(): TextTranslatorModelsTextTranslatorCategory | setCategory(TextTranslatorModelsTextTranslatorCategory category): void |
| `categoryDescriptor` | `?string` | Optional | Gets or sets CategoryDescriptor | getCategoryDescriptor(): ?string | setCategoryDescriptor(?string categoryDescriptor): void |
| `baselineBleuScoreCIPunctuated` | `?float` | Optional | Gets or sets baseline BleuScore (case-insensitive, punctuated). | getBaselineBleuScoreCIPunctuated(): ?float | setBaselineBleuScoreCIPunctuated(?float baselineBleuScoreCIPunctuated): void |
| `bleuScoreCIPunctuated` | `?float` | Optional | Gets or sets BleuScore (case-insensitive, punctuated). | getBleuScoreCIPunctuated(): ?float | setBleuScoreCIPunctuated(?float bleuScoreCIPunctuated): void |
| `status` | [`string (Status1Enum)`](../../doc/models/status-1-enum.md) | Required | Gets or sets Status | getStatus(): string | setStatus(string status): void |
| `modifiedDate` | `\DateTime` | Required | Gets or sets ModifiedDate | getModifiedDate(): \DateTime | setModifiedDate(\DateTime modifiedDate): void |
| `createdDate` | `\DateTime` | Required | Gets the CreatedDate | getCreatedDate(): \DateTime | setCreatedDate(\DateTime createdDate): void |
| `createdBy` | [`TextTranslatorModelsResponseUserInfo`](../../doc/models/text-translator-models-response-user-info.md) | Required | Basic user information - object used for<br>CreatedBy/ModifiedBy response fields | getCreatedBy(): TextTranslatorModelsResponseUserInfo | setCreatedBy(TextTranslatorModelsResponseUserInfo createdBy): void |
| `modifiedBy` | [`TextTranslatorModelsResponseUserInfo`](../../doc/models/text-translator-models-response-user-info.md) | Required | Basic user information - object used for<br>CreatedBy/ModifiedBy response fields | getModifiedBy(): TextTranslatorModelsResponseUserInfo | setModifiedBy(TextTranslatorModelsResponseUserInfo modifiedBy): void |
| `apiDomain` | `string` | Required | Gets the Api Domain | getApiDomain(): string | setApiDomain(string apiDomain): void |
| `isAvailable` | `bool` | Required | Maps to the IsAvailable of the unerlying Language pair. | getIsAvailable(): bool | setIsAvailable(bool isAvailable): void |
| `hubCategory` | `?string` | Optional | Gets the Category of this Model in Hub | getHubCategory(): ?string | setHubCategory(?string hubCategory): void |
| `hasFreeTraining` | `bool` | Required | Gets if this project has a free training available | getHasFreeTraining(): bool | setHasFreeTraining(bool hasFreeTraining): void |
| `modelRegionStatus` | [`?(TextTranslatorModelsTextTranslatorModelRegionStatusWithName[])`](../../doc/models/text-translator-models-text-translator-model-region-status-with-name.md) | Optional | Gets or sets the regions the model in this project is deployed in | getModelRegionStatus(): ?array | setModelRegionStatus(?array modelRegionStatus): void |

## Example (as JSON)

```json
{
  "id": "00001770-0000-0000-0000-000000000000",
  "name": "name0",
  "label": null,
  "description": null,
  "languagePair": {
    "id": null,
    "sourceLanguage": {
      "id": 22,
      "displayName": "displayName4",
      "languageCode": "languageCode4"
    },
    "targetLanguage": {
      "id": 144,
      "displayName": "displayName4",
      "languageCode": "languageCode4"
    }
  },
  "category": {
    "id": 232,
    "name": "name2"
  },
  "categoryDescriptor": null,
  "baselineBleuScoreCIPunctuated": null,
  "bleuScoreCIPunctuated": null,
  "status": "submitted",
  "modifiedDate": "2016-03-13T12:52:32.123Z",
  "createdDate": "2016-03-13T12:52:32.123Z",
  "createdBy": {
    "id": "000021b8-0000-0000-0000-000000000000",
    "userName": "userName4"
  },
  "modifiedBy": {
    "id": "0000222e-0000-0000-0000-000000000000",
    "userName": "userName2"
  },
  "apiDomain": "apiDomain0",
  "isAvailable": false,
  "hubCategory": null,
  "hasFreeTraining": false,
  "modelRegionStatus": null
}
```

