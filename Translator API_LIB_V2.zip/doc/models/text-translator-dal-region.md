
# Text Translator DAL Region

## Structure

`TextTranslatorDALRegion`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `id` | `?int` | Optional | - | getId(): ?int | setId(?int id): void |
| `regionName` | `?string` | Optional | - | getRegionName(): ?string | setRegionName(?string regionName): void |
| `billing` | [`?(TextTranslatorDALProjectBilling[])`](../../doc/models/text-translator-dal-project-billing.md) | Optional | - | getBilling(): ?array | setBilling(?array billing): void |

## Example (as JSON)

```json
{
  "id": null,
  "regionName": null,
  "billing": null
}
```

