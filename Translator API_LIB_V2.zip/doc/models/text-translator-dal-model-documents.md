
# Text Translator DAL Model Documents

## Structure

`TextTranslatorDALModelDocuments`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `id` | `?int` | Optional | - | getId(): ?int | setId(?int id): void |
| `modelId` | `?int` | Optional | - | getModelId(): ?int | setModelId(?int modelId): void |
| `documentId` | `?int` | Optional | - | getDocumentId(): ?int | setDocumentId(?int documentId): void |
| `document` | [`?TextTranslatorDALDocument`](../../doc/models/text-translator-dal-document.md) | Optional | - | getDocument(): ?TextTranslatorDALDocument | setDocument(?TextTranslatorDALDocument document): void |
| `model` | [`?TextTranslatorDALModel`](../../doc/models/text-translator-dal-model.md) | Optional | - | getModel(): ?TextTranslatorDALModel | setModel(?TextTranslatorDALModel model): void |

## Example (as JSON)

```json
{
  "id": null,
  "modelId": null,
  "documentId": null,
  "document": null,
  "model": null
}
```

