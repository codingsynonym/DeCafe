
# Text Translator DAL Application Sharing

## Structure

`TextTranslatorDALApplicationSharing`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `id` | `?int` | Optional | - | getId(): ?int | setId(?int id): void |
| `applicationId` | `?int` | Optional | - | getApplicationId(): ?int | setApplicationId(?int applicationId): void |
| `applicationUserId` | `?string` | Optional | - | getApplicationUserId(): ?string | setApplicationUserId(?string applicationUserId): void |
| `roleId` | `?int` | Optional | - | getRoleId(): ?int | setRoleId(?int roleId): void |
| `isDefaultApplication` | `?bool` | Optional | - | getIsDefaultApplication(): ?bool | setIsDefaultApplication(?bool isDefaultApplication): void |
| `applicationUser` | [`?TextTranslatorDALApplicationUser`](../../doc/models/text-translator-dal-application-user.md) | Optional | - | getApplicationUser(): ?TextTranslatorDALApplicationUser | setApplicationUser(?TextTranslatorDALApplicationUser applicationUser): void |
| `application` | [`?TextTranslatorDALApplication`](../../doc/models/text-translator-dal-application.md) | Optional | - | getApplication(): ?TextTranslatorDALApplication | setApplication(?TextTranslatorDALApplication application): void |
| `role` | [`?TextTranslatorDALRole`](../../doc/models/text-translator-dal-role.md) | Optional | - | getRole(): ?TextTranslatorDALRole | setRole(?TextTranslatorDALRole role): void |

## Example (as JSON)

```json
{
  "id": null,
  "applicationId": null,
  "applicationUserId": null,
  "roleId": null,
  "isDefaultApplication": null,
  "applicationUser": null,
  "application": null,
  "role": null
}
```

