
# Text Translator DAL Upload History

## Structure

`TextTranslatorDALUploadHistory`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `id` | `?int` | Optional | - | getId(): ?int | setId(?int id): void |
| `jobId` | `?string` | Optional | - | getJobId(): ?string | setJobId(?string jobId): void |
| `applicationId` | `?int` | Optional | - | getApplicationId(): ?int | setApplicationId(?int applicationId): void |
| `parentId` | `?int` | Optional | - | getParentId(): ?int | setParentId(?int parentId): void |
| `name` | `?string` | Optional | - | getName(): ?string | setName(?string name): void |
| `extension` | `?string` | Optional | - | getExtension(): ?string | setExtension(?string extension): void |
| `blobContainerName` | `?string` | Optional | - | getBlobContainerName(): ?string | setBlobContainerName(?string blobContainerName): void |
| `blobLocation` | `?string` | Optional | - | getBlobLocation(): ?string | setBlobLocation(?string blobLocation): void |
| `languageCode` | `?string` | Optional | - | getLanguageCode(): ?string | setLanguageCode(?string languageCode): void |
| `summary` | `?string` | Optional | - | getSummary(): ?string | setSummary(?string summary): void |
| `allowOverwrite` | `?bool` | Optional | - | getAllowOverwrite(): ?bool | setAllowOverwrite(?bool allowOverwrite): void |
| `status` | [`?string (Status2Enum)`](../../doc/models/status-2-enum.md) | Optional | - | getStatus(): ?string | setStatus(?string status): void |
| `createdBy` | `?string` | Optional | - | getCreatedBy(): ?string | setCreatedBy(?string createdBy): void |
| `createdDate` | `?\DateTime` | Optional | - | getCreatedDate(): ?\DateTime | setCreatedDate(?\DateTime createdDate): void |
| `modifiedDate` | `?\DateTime` | Optional | - | getModifiedDate(): ?\DateTime | setModifiedDate(?\DateTime modifiedDate): void |
| `documentTypeId` | `?int` | Optional | - | getDocumentTypeId(): ?int | setDocumentTypeId(?int documentTypeId): void |
| `documentName` | `?string` | Optional | - | getDocumentName(): ?string | setDocumentName(?string documentName): void |
| `application` | [`?TextTranslatorDALApplication`](../../doc/models/text-translator-dal-application.md) | Optional | - | getApplication(): ?TextTranslatorDALApplication | setApplication(?TextTranslatorDALApplication application): void |
| `documentType` | [`?TextTranslatorDALDocumentType`](../../doc/models/text-translator-dal-document-type.md) | Optional | - | getDocumentType(): ?TextTranslatorDALDocumentType | setDocumentType(?TextTranslatorDALDocumentType documentType): void |
| `createdByNavigation` | [`?TextTranslatorDALApplicationUser`](../../doc/models/text-translator-dal-application-user.md) | Optional | - | getCreatedByNavigation(): ?TextTranslatorDALApplicationUser | setCreatedByNavigation(?TextTranslatorDALApplicationUser createdByNavigation): void |

## Example (as JSON)

```json
{
  "id": null,
  "jobId": null,
  "applicationId": null,
  "parentId": null,
  "name": null,
  "extension": null,
  "blobContainerName": null,
  "blobLocation": null,
  "languageCode": null,
  "summary": null,
  "allowOverwrite": null,
  "status": null,
  "createdBy": null,
  "createdDate": null,
  "modifiedDate": null,
  "documentTypeId": null,
  "documentName": null,
  "application": null,
  "documentType": null,
  "createdByNavigation": null
}
```

