
# Text Translator Models Text Translator Category

Defines a category of the project.

## Structure

`TextTranslatorModelsTextTranslatorCategory`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `id` | `int` | Required | Id of the Category | getId(): int | setId(int id): void |
| `name` | `string` | Required | Name of the Category | getName(): string | setName(string name): void |

## Example (as JSON)

```json
{
  "id": 112,
  "name": "name0"
}
```

