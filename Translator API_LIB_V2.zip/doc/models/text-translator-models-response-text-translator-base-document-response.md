
# Text Translator Models Response Text Translator Base Document Response

## Structure

`TextTranslatorModelsResponseTextTranslatorBaseDocumentResponse`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `documents` | [`?(TextTranslatorModelsTextTranslatorBaseDocumentInfo[])`](../../doc/models/text-translator-models-text-translator-base-document-info.md) | Optional | - | getDocuments(): ?array | setDocuments(?array documents): void |

## Example (as JSON)

```json
{
  "documents": null
}
```

