
# Text Translator Models Response Text Translator Test Entriess Response

Result container for test entries.

## Structure

`TextTranslatorModelsResponseTextTranslatorTestEntriessResponse`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `testEntries` | [`TextTranslatorModelsTextTranslatorTestEntry[]`](../../doc/models/text-translator-models-text-translator-test-entry.md) | Required | Gets or sets Test result entries | getTestEntries(): array | setTestEntries(array testEntries): void |

## Example (as JSON)

```json
{
  "testEntries": [
    {
      "source": "source3",
      "target": "target1",
      "referenceString": null,
      "general": "general5"
    },
    {
      "source": "source2",
      "target": "target0",
      "referenceString": null,
      "general": "general4"
    }
  ]
}
```

