
# Text Translator DAL Language

## Structure

`TextTranslatorDALLanguage`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `id` | `?int` | Optional | - | getId(): ?int | setId(?int id): void |
| `displayName` | `?string` | Optional | - | getDisplayName(): ?string | setDisplayName(?string displayName): void |
| `languageCode` | `?string` | Optional | - | getLanguageCode(): ?string | setLanguageCode(?string languageCode): void |
| `languagePairSourceLanguage` | [`?(TextTranslatorDALLanguagePair[])`](../../doc/models/text-translator-dal-language-pair.md) | Optional | - | getLanguagePairSourceLanguage(): ?array | setLanguagePairSourceLanguage(?array languagePairSourceLanguage): void |
| `languagePairTargetLanguage` | [`?(TextTranslatorDALLanguagePair[])`](../../doc/models/text-translator-dal-language-pair.md) | Optional | - | getLanguagePairTargetLanguage(): ?array | setLanguagePairTargetLanguage(?array languagePairTargetLanguage): void |
| `files` | [`?(TextTranslatorDALFile[])`](../../doc/models/text-translator-dal-file.md) | Optional | - | getFiles(): ?array | setFiles(?array files): void |

## Example (as JSON)

```json
{
  "id": null,
  "displayName": null,
  "languageCode": null,
  "languagePairSourceLanguage": null,
  "languagePairTargetLanguage": null,
  "files": null
}
```

