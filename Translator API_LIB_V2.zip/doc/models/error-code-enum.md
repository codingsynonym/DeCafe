
# Error Code Enum

Gets the ErrorCode for failed trainings

## Enumeration

`ErrorCodeEnum`

## Fields

| Name |
|  --- |
| `NOERROR` |
| `UNKOWN` |
| `SELECTTESTSETS` |

