
# Document Type Enum

Gets or sets the DocumentType.

## Enumeration

`DocumentTypeEnum`

## Fields

| Name |
|  --- |
| `NONE` |
| `TRAINING` |
| `TESTING` |
| `TUNING` |
| `PHRASEDICTIONARY` |
| `SENTENCEDICTIONARY` |

