
# Text Translator DAL File

## Structure

`TextTranslatorDALFile`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `id` | `?int` | Optional | - | getId(): ?int | setId(?int id): void |
| `parentId` | `?int` | Optional | - | getParentId(): ?int | setParentId(?int parentId): void |
| `applicationId` | `?int` | Optional | - | getApplicationId(): ?int | setApplicationId(?int applicationId): void |
| `name` | `?string` | Optional | - | getName(): ?string | setName(?string name): void |
| `extension` | `?string` | Optional | - | getExtension(): ?string | setExtension(?string extension): void |
| `languageCode` | `?string` | Optional | - | getLanguageCode(): ?string | setLanguageCode(?string languageCode): void |
| `blobLocation` | `?string` | Optional | - | getBlobLocation(): ?string | setBlobLocation(?string blobLocation): void |
| `sntBlobLocation` | `?string` | Optional | - | getSntBlobLocation(): ?string | setSntBlobLocation(?string sntBlobLocation): void |
| `status` | [`?string (Status3Enum)`](../../doc/models/status-3-enum.md) | Optional | - | getStatus(): ?string | setStatus(?string status): void |
| `sentenceCount` | `?int` | Optional | - | getSentenceCount(): ?int | setSentenceCount(?int sentenceCount): void |
| `characterCount` | `?int` | Optional | - | getCharacterCount(): ?int | setCharacterCount(?int characterCount): void |
| `fileSize` | `?int` | Optional | - | getFileSize(): ?int | setFileSize(?int fileSize): void |
| `createdBy` | `?string` | Optional | - | getCreatedBy(): ?string | setCreatedBy(?string createdBy): void |
| `createdDate` | `?\DateTime` | Optional | - | getCreatedDate(): ?\DateTime | setCreatedDate(?\DateTime createdDate): void |
| `uploadHistoryId` | `?int` | Optional | - | getUploadHistoryId(): ?int | setUploadHistoryId(?int uploadHistoryId): void |
| `application` | [`?TextTranslatorDALApplication`](../../doc/models/text-translator-dal-application.md) | Optional | - | getApplication(): ?TextTranslatorDALApplication | setApplication(?TextTranslatorDALApplication application): void |
| `createdByNavigation` | [`?TextTranslatorDALApplicationUser`](../../doc/models/text-translator-dal-application-user.md) | Optional | - | getCreatedByNavigation(): ?TextTranslatorDALApplicationUser | setCreatedByNavigation(?TextTranslatorDALApplicationUser createdByNavigation): void |
| `documentFiles` | [`?(TextTranslatorDALDocumentFiles[])`](../../doc/models/text-translator-dal-document-files.md) | Optional | - | getDocumentFiles(): ?array | setDocumentFiles(?array documentFiles): void |
| `uploadHistory` | [`?TextTranslatorDALUploadHistory`](../../doc/models/text-translator-dal-upload-history.md) | Optional | - | getUploadHistory(): ?TextTranslatorDALUploadHistory | setUploadHistory(?TextTranslatorDALUploadHistory uploadHistory): void |
| `language` | [`?TextTranslatorDALLanguage`](../../doc/models/text-translator-dal-language.md) | Optional | - | getLanguage(): ?TextTranslatorDALLanguage | setLanguage(?TextTranslatorDALLanguage language): void |

## Example (as JSON)

```json
{
  "id": null,
  "parentId": null,
  "applicationId": null,
  "name": null,
  "extension": null,
  "languageCode": null,
  "blobLocation": null,
  "sntBlobLocation": null,
  "status": null,
  "sentenceCount": null,
  "characterCount": null,
  "fileSize": null,
  "createdBy": null,
  "createdDate": null,
  "uploadHistoryId": null,
  "application": null,
  "createdByNavigation": null,
  "documentFiles": null,
  "uploadHistory": null,
  "language": null
}
```

