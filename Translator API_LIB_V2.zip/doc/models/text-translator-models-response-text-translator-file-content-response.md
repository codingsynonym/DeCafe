
# Text Translator Models Response Text Translator File Content Response

Result container for file content.

## Structure

`TextTranslatorModelsResponseTextTranslatorFileContentResponse`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `items` | `string[]` | Required | Gets or sets the items of the document | getItems(): array | setItems(array items): void |
| `totalExtractedSentences` | `int` | Required | Gets or sets the total number of extracted sentences. | getTotalExtractedSentences(): int | setTotalExtractedSentences(int totalExtractedSentences): void |
| `pageIndex` | `int` | Required | Gets or sets the page index. | getPageIndex(): int | setPageIndex(int pageIndex): void |
| `totalPageCount` | `int` | Required | Gets or sets the total number of pages. | getTotalPageCount(): int | setTotalPageCount(int totalPageCount): void |

## Example (as JSON)

```json
{
  "items": [
    "items7",
    "items8"
  ],
  "totalExtractedSentences": 184,
  "pageIndex": 166,
  "totalPageCount": 32
}
```

