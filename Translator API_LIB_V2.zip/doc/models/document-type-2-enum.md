
# Document Type 2 Enum

The type of document uploaded by this job (ex: training, tuning, testing).

## Enumeration

`DocumentType2Enum`

## Fields

| Name |
|  --- |
| `NONE` |
| `TRAINING` |
| `TESTING` |
| `TUNING` |
| `PHRASEDICTIONARY` |
| `SENTENCEDICTIONARY` |

