
# Text Translator Models Text Translator Model Region Status With Name

Expanded information about regions a model is deployed in

## Structure

`TextTranslatorModelsTextTranslatorModelRegionStatusWithName`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `regionName` | `string` | Required | Gets or sets the region name | getRegionName(): string | setRegionName(string regionName): void |
| `region` | `int` | Required | Gets or sets the RegionId | getRegion(): int | setRegion(int region): void |
| `isDeployed` | `bool` | Required | Gets or sets the id for this role. | getIsDeployed(): bool | setIsDeployed(bool isDeployed): void |

## Example (as JSON)

```json
{
  "regionName": "regionName8",
  "region": 44,
  "isDeployed": false
}
```

