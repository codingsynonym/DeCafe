
# Text Translator Models Response Text Translator Workspaces Reponse

A container for workspace results

## Structure

`TextTranslatorModelsResponseTextTranslatorWorkspacesReponse`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `workspaces` | [`TextTranslatorApiModelsTextTranslatorWorkspaceInfo[]`](../../doc/models/text-translator-api-models-text-translator-workspace-info.md) | Required | Gets or sets information for workspaces. | getWorkspaces(): array | setWorkspaces(array workspaces): void |

## Example (as JSON)

```json
{
  "workspaces": [
    {
      "id": null,
      "role": null,
      "name": null,
      "isCreator": null,
      "isDefaultWorkspace": null,
      "createdBy": null,
      "createdDate": null,
      "sharing": null,
      "hasMigrations": null,
      "region": null,
      "subscription": null
    },
    {
      "id": null,
      "role": null,
      "name": null,
      "isCreator": null,
      "isDefaultWorkspace": null,
      "createdBy": null,
      "createdDate": null,
      "sharing": null,
      "hasMigrations": null,
      "region": null,
      "subscription": null
    },
    {
      "id": null,
      "role": null,
      "name": null,
      "isCreator": null,
      "isDefaultWorkspace": null,
      "createdBy": null,
      "createdDate": null,
      "sharing": null,
      "hasMigrations": null,
      "region": null,
      "subscription": null
    }
  ]
}
```

