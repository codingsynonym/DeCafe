
# Text Translator Models Text Translator Processed Document Info

A class containing information related to the document after it has been processed in a specific model training

## Structure

`TextTranslatorModelsTextTranslatorProcessedDocumentInfo`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `id` | `int` | Required | Gets or Sets Id | getId(): int | setId(int id): void |
| `modelId` | `int` | Required | Gets or Sets parent model Id | getModelId(): int | setModelId(int modelId): void |
| `documentId` | `int` | Required | Gets or Sets document set from which the documents were derived | getDocumentId(): int | setDocumentId(int documentId): void |
| `alignedSentenceCount` | `?int` | Optional | Aligned sentence count after sentence alignment is executed | getAlignedSentenceCount(): ?int | setAlignedSentenceCount(?int alignedSentenceCount): void |
| `usedSentenceCount` | `?int` | Optional | Sentences used after filtering and auto selection occur | getUsedSentenceCount(): ?int | setUsedSentenceCount(?int usedSentenceCount): void |

## Example (as JSON)

```json
{
  "id": 112,
  "modelId": 108,
  "documentId": 92,
  "alignedSentenceCount": null,
  "usedSentenceCount": null
}
```

