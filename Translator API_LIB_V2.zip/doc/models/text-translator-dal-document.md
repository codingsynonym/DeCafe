
# Text Translator DAL Document

## Structure

`TextTranslatorDALDocument`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `id` | `?int` | Optional | - | getId(): ?int | setId(?int id): void |
| `applicationId` | `?int` | Optional | - | getApplicationId(): ?int | setApplicationId(?int applicationId): void |
| `name` | `?string` | Optional | - | getName(): ?string | setName(?string name): void |
| `documentTypeId` | `?int` | Optional | - | getDocumentTypeId(): ?int | setDocumentTypeId(?int documentTypeId): void |
| `isParallel` | `?bool` | Optional | - | getIsParallel(): ?bool | setIsParallel(?bool isParallel): void |
| `alignedSentenceCount` | `?int` | Optional | - | getAlignedSentenceCount(): ?int | setAlignedSentenceCount(?int alignedSentenceCount): void |
| `createdBy` | `?string` | Optional | - | getCreatedBy(): ?string | setCreatedBy(?string createdBy): void |
| `modifiedBy` | `?string` | Optional | - | getModifiedBy(): ?string | setModifiedBy(?string modifiedBy): void |
| `createdDate` | `?\DateTime` | Optional | - | getCreatedDate(): ?\DateTime | setCreatedDate(?\DateTime createdDate): void |
| `isAvailable` | `?bool` | Optional | - | getIsAvailable(): ?bool | setIsAvailable(?bool isAvailable): void |
| `application` | [`?TextTranslatorDALApplication`](../../doc/models/text-translator-dal-application.md) | Optional | - | getApplication(): ?TextTranslatorDALApplication | setApplication(?TextTranslatorDALApplication application): void |
| `createdByNavigation` | [`?TextTranslatorDALApplicationUser`](../../doc/models/text-translator-dal-application-user.md) | Optional | - | getCreatedByNavigation(): ?TextTranslatorDALApplicationUser | setCreatedByNavigation(?TextTranslatorDALApplicationUser createdByNavigation): void |
| `documentType` | [`?TextTranslatorDALDocumentType`](../../doc/models/text-translator-dal-document-type.md) | Optional | - | getDocumentType(): ?TextTranslatorDALDocumentType | setDocumentType(?TextTranslatorDALDocumentType documentType): void |
| `modifiedByNavigation` | [`?TextTranslatorDALApplicationUser`](../../doc/models/text-translator-dal-application-user.md) | Optional | - | getModifiedByNavigation(): ?TextTranslatorDALApplicationUser | setModifiedByNavigation(?TextTranslatorDALApplicationUser modifiedByNavigation): void |
| `documentFiles` | [`?(TextTranslatorDALDocumentFiles[])`](../../doc/models/text-translator-dal-document-files.md) | Optional | - | getDocumentFiles(): ?array | setDocumentFiles(?array documentFiles): void |
| `modelDocuments` | [`?(TextTranslatorDALModelDocuments[])`](../../doc/models/text-translator-dal-model-documents.md) | Optional | - | getModelDocuments(): ?array | setModelDocuments(?array modelDocuments): void |
| `processedDocument` | [`?(TextTranslatorDALProcessedDocument[])`](../../doc/models/text-translator-dal-processed-document.md) | Optional | - | getProcessedDocument(): ?array | setProcessedDocument(?array processedDocument): void |

## Example (as JSON)

```json
{
  "id": null,
  "applicationId": null,
  "name": null,
  "documentTypeId": null,
  "isParallel": null,
  "alignedSentenceCount": null,
  "createdBy": null,
  "modifiedBy": null,
  "createdDate": null,
  "isAvailable": null,
  "application": null,
  "createdByNavigation": null,
  "documentType": null,
  "modifiedByNavigation": null,
  "documentFiles": null,
  "modelDocuments": null,
  "processedDocument": null
}
```

