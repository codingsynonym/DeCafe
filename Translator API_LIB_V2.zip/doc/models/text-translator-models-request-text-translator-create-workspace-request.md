
# Text Translator Models Request Text Translator Create Workspace Request

The input class for creating a new workspace.

## Structure

`TextTranslatorModelsRequestTextTranslatorCreateWorkspaceRequest`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `name` | `string` | Required | Gets or sets the name of the workspace | getName(): string | setName(string name): void |
| `subscription` | [`TextTranslatorModelsRequestTextTranslatorSubscriptionRequest`](../../doc/models/text-translator-models-request-text-translator-subscription-request.md) | Required | The input class for subscription requests. | getSubscription(): TextTranslatorModelsRequestTextTranslatorSubscriptionRequest | setSubscription(TextTranslatorModelsRequestTextTranslatorSubscriptionRequest subscription): void |

## Example (as JSON)

```json
{
  "name": "name0",
  "subscription": {
    "subscriptionKey": "subscriptionKey4",
    "billingRegionCode": "billingRegionCode8"
  }
}
```

