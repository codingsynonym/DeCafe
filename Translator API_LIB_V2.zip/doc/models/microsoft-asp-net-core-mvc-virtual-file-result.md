
# Microsoft Asp Net Core Mvc Virtual File Result

## Structure

`MicrosoftAspNetCoreMvcVirtualFileResult`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `fileName` | `?string` | Optional | - | getFileName(): ?string | setFileName(?string fileName): void |
| `fileProvider` | `?array` | Optional | - | getFileProvider(): ?array | setFileProvider(?array fileProvider): void |
| `contentType` | `?string` | Optional | - | getContentType(): ?string | setContentType(?string contentType): void |
| `fileDownloadName` | `?string` | Optional | - | getFileDownloadName(): ?string | setFileDownloadName(?string fileDownloadName): void |
| `lastModified` | `?\DateTime` | Optional | - | getLastModified(): ?\DateTime | setLastModified(?\DateTime lastModified): void |
| `entityTag` | [`?MicrosoftNetHttpHeadersEntityTagHeaderValue`](../../doc/models/microsoft-net-http-headers-entity-tag-header-value.md) | Optional | - | getEntityTag(): ?MicrosoftNetHttpHeadersEntityTagHeaderValue | setEntityTag(?MicrosoftNetHttpHeadersEntityTagHeaderValue entityTag): void |

## Example (as JSON)

```json
{
  "fileName": null,
  "fileProvider": null,
  "contentType": null,
  "fileDownloadName": null,
  "lastModified": null,
  "entityTag": null
}
```

