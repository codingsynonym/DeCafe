
# Text Translator Models Response Text Translator Models Response

A container for models results.

## Structure

`TextTranslatorModelsResponseTextTranslatorModelsResponse`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `models` | [`TextTranslatorModelsTextTranslatorModelInfo[]`](../../doc/models/text-translator-models-text-translator-model-info.md) | Required | Gets or sets training models. | getModels(): array | setModels(array models): void |
| `pageIndex` | `int` | Required | Gets or sets the page index. | getPageIndex(): int | setPageIndex(int pageIndex): void |
| `totalPageCount` | `int` | Required | Gets or sets the total number of pages. | getTotalPageCount(): int | setTotalPageCount(int totalPageCount): void |

## Example (as JSON)

```json
{
  "models": [
    {
      "id": 116,
      "name": "name6",
      "modelIdentifier": null,
      "projectId": "000006be-0000-0000-0000-000000000000",
      "documents": null,
      "modelRegionStatuses": null,
      "baselineBleuScorePunctuated": null,
      "bleuScorePunctuated": null,
      "baselineBleuScoreUnpunctuated": null,
      "bleuScoreUnpunctuated": null,
      "baselineBleuScoreCIPunctuated": null,
      "bleuScoreCIPunctuated": null,
      "baselineBleuScoreCIUnpunctuated": null,
      "bleuScoreCIUnpunctuated": null,
      "startDate": null,
      "completionDate": null,
      "modifiedDate": "2016-03-13T12:52:32.123Z",
      "createdDate": "2016-03-13T12:52:32.123Z",
      "createdBy": {
        "id": "000023cc-0000-0000-0000-000000000000",
        "userName": "userName6"
      },
      "modifiedBy": {
        "id": "00002356-0000-0000-0000-000000000000",
        "userName": "userName8"
      },
      "trainingSentenceCount": null,
      "tuningSentenceCount": null,
      "testingSentenceCount": null,
      "phraseDictionarySentenceCount": null,
      "sentenceDictionarySentenceCount": null,
      "monolingualSentenceCount": null,
      "modelStatus": "trainingFailed",
      "isTuningAuto": false,
      "isTestingAuto": false,
      "isAutoDeploy": false,
      "autoDeployThreshold": 223.36,
      "hubBLEUScore": null,
      "hubCategory": null,
      "errorCode": null
    },
    {
      "id": 117,
      "name": "name7",
      "modelIdentifier": null,
      "projectId": "000006bf-0000-0000-0000-000000000000",
      "documents": null,
      "modelRegionStatuses": null,
      "baselineBleuScorePunctuated": null,
      "bleuScorePunctuated": null,
      "baselineBleuScoreUnpunctuated": null,
      "bleuScoreUnpunctuated": null,
      "baselineBleuScoreCIPunctuated": null,
      "bleuScoreCIPunctuated": null,
      "baselineBleuScoreCIUnpunctuated": null,
      "bleuScoreCIUnpunctuated": null,
      "startDate": null,
      "completionDate": null,
      "modifiedDate": "2016-03-13T12:52:32.123Z",
      "createdDate": "2016-03-13T12:52:32.123Z",
      "createdBy": {
        "id": "000023cd-0000-0000-0000-000000000000",
        "userName": "userName7"
      },
      "modifiedBy": {
        "id": "00002357-0000-0000-0000-000000000000",
        "userName": "userName9"
      },
      "trainingSentenceCount": null,
      "tuningSentenceCount": null,
      "testingSentenceCount": null,
      "phraseDictionarySentenceCount": null,
      "sentenceDictionarySentenceCount": null,
      "monolingualSentenceCount": null,
      "modelStatus": "deploying",
      "isTuningAuto": true,
      "isTestingAuto": true,
      "isAutoDeploy": true,
      "autoDeployThreshold": 223.37,
      "hubBLEUScore": null,
      "hubCategory": null,
      "errorCode": null
    }
  ],
  "pageIndex": 166,
  "totalPageCount": 32
}
```

