
# Text Translator Models Request Text Translator Project Request

The input class for model requests.

## Structure

`TextTranslatorModelsRequestTextTranslatorProjectRequest`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `languagePairId` | `int` | Required | The Id for the language pair. | getLanguagePairId(): int | setLanguagePairId(int languagePairId): void |
| `categoryId` | `int` | Required | Gets or sets Category | getCategoryId(): int | setCategoryId(int categoryId): void |
| `name` | `?string` | Optional | Gets or sets Name | getName(): ?string | setName(?string name): void |
| `categoryDescriptor` | `?string` | Optional | Gets or sets CategoryDescriptor | getCategoryDescriptor(): ?string | setCategoryDescriptor(?string categoryDescriptor): void |
| `description` | `?string` | Optional | Gets or sets Description | getDescription(): ?string | setDescription(?string description): void |
| `label` | `?string` | Optional | Gets or sets the project label. | getLabel(): ?string | setLabel(?string label): void |

## Example (as JSON)

```json
{
  "languagePairId": 236,
  "categoryId": 240,
  "name": null,
  "categoryDescriptor": null,
  "description": null,
  "label": null
}
```

