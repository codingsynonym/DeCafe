
# Text Translator Models Request Text Translator Workspace Permission Info

Class for a single workspace permission request.

## Structure

`TextTranslatorModelsRequestTextTranslatorWorkspacePermissionInfo`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `emailAddress` | `string` | Required | Gets or sets the email address for the user this workspace has been<br>shared with. | getEmailAddress(): string | setEmailAddress(string emailAddress): void |
| `roleId` | `int` | Required | Gets or sets the id for this role. | getRoleId(): int | setRoleId(int roleId): void |

## Example (as JSON)

```json
{
  "emailAddress": "emailAddress0",
  "roleId": 200
}
```

