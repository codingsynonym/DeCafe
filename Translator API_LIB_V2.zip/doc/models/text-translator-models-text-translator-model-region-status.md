
# Text Translator Models Text Translator Model Region Status

Information about a region a model is deployed or not deployed in

## Structure

`TextTranslatorModelsTextTranslatorModelRegionStatus`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `region` | `int` | Required | Gets or sets the RegionId | getRegion(): int | setRegion(int region): void |
| `isDeployed` | `bool` | Required | Gets or sets the id for this role. | getIsDeployed(): bool | setIsDeployed(bool isDeployed): void |

## Example (as JSON)

```json
{
  "region": 44,
  "isDeployed": false
}
```

