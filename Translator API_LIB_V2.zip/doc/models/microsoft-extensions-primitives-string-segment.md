
# Microsoft Extensions Primitives String Segment

## Structure

`MicrosoftExtensionsPrimitivesStringSegment`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `buffer` | `?string` | Optional | - | getBuffer(): ?string | setBuffer(?string buffer): void |
| `offset` | `?int` | Optional | - | getOffset(): ?int | setOffset(?int offset): void |
| `length` | `?int` | Optional | - | getLength(): ?int | setLength(?int length): void |
| `value` | `?string` | Optional | - | getValue(): ?string | setValue(?string value): void |
| `hasValue` | `?bool` | Optional | - | getHasValue(): ?bool | setHasValue(?bool hasValue): void |

## Example (as JSON)

```json
{
  "buffer": null,
  "offset": null,
  "length": null,
  "value": null,
  "hasValue": null
}
```

