
# Text Translator DAL Processed Document

## Structure

`TextTranslatorDALProcessedDocument`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `id` | `?int` | Optional | - | getId(): ?int | setId(?int id): void |
| `modelId` | `?int` | Optional | - | getModelId(): ?int | setModelId(?int modelId): void |
| `documentType` | `?string` | Optional | - | getDocumentType(): ?string | setDocumentType(?string documentType): void |
| `alignedSentenceCount` | `?int` | Optional | - | getAlignedSentenceCount(): ?int | setAlignedSentenceCount(?int alignedSentenceCount): void |
| `usedSentenceCount` | `?int` | Optional | - | getUsedSentenceCount(): ?int | setUsedSentenceCount(?int usedSentenceCount): void |
| `documentId` | `?int` | Optional | - | getDocumentId(): ?int | setDocumentId(?int documentId): void |
| `document` | [`?TextTranslatorDALDocument`](../../doc/models/text-translator-dal-document.md) | Optional | - | getDocument(): ?TextTranslatorDALDocument | setDocument(?TextTranslatorDALDocument document): void |
| `model` | [`?TextTranslatorDALModel`](../../doc/models/text-translator-dal-model.md) | Optional | - | getModel(): ?TextTranslatorDALModel | setModel(?TextTranslatorDALModel model): void |

## Example (as JSON)

```json
{
  "id": null,
  "modelId": null,
  "documentType": null,
  "alignedSentenceCount": null,
  "usedSentenceCount": null,
  "documentId": null,
  "document": null,
  "model": null
}
```

