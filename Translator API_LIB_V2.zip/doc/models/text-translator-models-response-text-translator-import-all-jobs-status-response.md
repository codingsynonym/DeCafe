
# Text Translator Models Response Text Translator Import All Jobs Status Response

API results container for TextTranslatorImportAllJobs response.

## Structure

`TextTranslatorModelsResponseTextTranslatorImportAllJobsStatusResponse`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `jobs` | [`TextTranslatorModelsResponseTextTranslatorImportAllJobsStatusInfo[]`](../../doc/models/text-translator-models-response-text-translator-import-all-jobs-status-info.md) | Required | Gets or sets the list of upload jobs. | getJobs(): array | setJobs(array jobs): void |
| `pageIndex` | `int` | Required | Gets or sets the page index. | getPageIndex(): int | setPageIndex(int pageIndex): void |
| `totalPageCount` | `int` | Required | Gets or sets the total number of pages. | getTotalPageCount(): int | setTotalPageCount(int totalPageCount): void |

## Example (as JSON)

```json
{
  "jobs": [
    {
      "jobId": null,
      "numberFiles": null,
      "numberFilesWithErrors": null,
      "name": null,
      "status": null,
      "documentType": null,
      "createdDate": null,
      "createdBy": null,
      "languages": null
    }
  ],
  "pageIndex": 166,
  "totalPageCount": 32
}
```

