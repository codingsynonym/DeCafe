
# Text Translator Models Response Text Translator Document Info Response

## Structure

`TextTranslatorModelsResponseTextTranslatorDocumentInfoResponse`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `documents` | [`TextTranslatorModelsTextTranslatorDocumentInfo[]`](../../doc/models/text-translator-models-text-translator-document-info.md) | Required | Gets or sets the documents. | getDocuments(): array | setDocuments(array documents): void |
| `pageIndex` | `int` | Required | Gets or sets the page index. | getPageIndex(): int | setPageIndex(int pageIndex): void |
| `totalPageCount` | `int` | Required | Gets or sets the total number of pages. | getTotalPageCount(): int | setTotalPageCount(int totalPageCount): void |

## Example (as JSON)

```json
{
  "documents": [
    {
      "name": "name7",
      "isParallel": true,
      "createdBy": {
        "id": "000017d9-0000-0000-0000-000000000000",
        "userName": "userName7"
      },
      "modifiedBy": {
        "id": "0000184f-0000-0000-0000-000000000000",
        "userName": "userName5"
      },
      "files": null,
      "languages": null,
      "createdDate": null,
      "isAvailable": null,
      "id": 79,
      "documentType": "tuning",
      "extractedSentenceCount": 141,
      "characterCount": 163,
      "usedByPrioritizedModel": null
    },
    {
      "name": "name8",
      "isParallel": false,
      "createdBy": {
        "id": "000017d8-0000-0000-0000-000000000000",
        "userName": "userName6"
      },
      "modifiedBy": {
        "id": "0000184e-0000-0000-0000-000000000000",
        "userName": "userName4"
      },
      "files": null,
      "languages": null,
      "createdDate": null,
      "isAvailable": null,
      "id": 80,
      "documentType": "phraseDictionary",
      "extractedSentenceCount": 142,
      "characterCount": 162,
      "usedByPrioritizedModel": null
    },
    {
      "name": "name9",
      "isParallel": true,
      "createdBy": {
        "id": "000017d7-0000-0000-0000-000000000000",
        "userName": "userName5"
      },
      "modifiedBy": {
        "id": "0000184d-0000-0000-0000-000000000000",
        "userName": "userName3"
      },
      "files": null,
      "languages": null,
      "createdDate": null,
      "isAvailable": null,
      "id": 81,
      "documentType": "sentenceDictionary",
      "extractedSentenceCount": 143,
      "characterCount": 161,
      "usedByPrioritizedModel": null
    }
  ],
  "pageIndex": 166,
  "totalPageCount": 32
}
```

