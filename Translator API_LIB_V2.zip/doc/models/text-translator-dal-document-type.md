
# Text Translator DAL Document Type

## Structure

`TextTranslatorDALDocumentType`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `id` | `?int` | Optional | - | getId(): ?int | setId(?int id): void |
| `docType` | `?string` | Optional | - | getDocType(): ?string | setDocType(?string docType): void |
| `documents` | [`?(TextTranslatorDALDocument[])`](../../doc/models/text-translator-dal-document.md) | Optional | - | getDocuments(): ?array | setDocuments(?array documents): void |
| `uploadHistoryRecords` | [`?(TextTranslatorDALUploadHistory[])`](../../doc/models/text-translator-dal-upload-history.md) | Optional | - | getUploadHistoryRecords(): ?array | setUploadHistoryRecords(?array uploadHistoryRecords): void |

## Example (as JSON)

```json
{
  "id": null,
  "docType": null,
  "documents": null,
  "uploadHistoryRecords": null
}
```

