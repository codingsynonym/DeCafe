
# Text Translator DAL Project Billing

## Structure

`TextTranslatorDALProjectBilling`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `id` | `?int` | Optional | - | getId(): ?int | setId(?int id): void |
| `lastBillingDate` | `?\DateTime` | Optional | - | getLastBillingDate(): ?\DateTime | setLastBillingDate(?\DateTime lastBillingDate): void |
| `project` | [`?TextTranslatorDALProject`](../../doc/models/text-translator-dal-project.md) | Optional | - | getProject(): ?TextTranslatorDALProject | setProject(?TextTranslatorDALProject project): void |
| `projectId` | `?string` | Optional | - | getProjectId(): ?string | setProjectId(?string projectId): void |
| `region` | [`?TextTranslatorDALRegion`](../../doc/models/text-translator-dal-region.md) | Optional | - | getRegion(): ?TextTranslatorDALRegion | setRegion(?TextTranslatorDALRegion region): void |
| `regionId` | `?int` | Optional | - | getRegionId(): ?int | setRegionId(?int regionId): void |

## Example (as JSON)

```json
{
  "id": null,
  "lastBillingDate": null,
  "project": null,
  "projectId": null,
  "region": null,
  "regionId": null
}
```

