
# Text Translator Models Text Translator Base Document Info

Class containing base information about a document. Used for
select all/none functionality on the front end.

## Structure

`TextTranslatorModelsTextTranslatorBaseDocumentInfo`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `id` | `int` | Required | Gets or sets Id | getId(): int | setId(int id): void |
| `documentType` | [`string (DocumentTypeEnum)`](../../doc/models/document-type-enum.md) | Required | Gets or sets the DocumentType. | getDocumentType(): string | setDocumentType(string documentType): void |
| `extractedSentenceCount` | `int` | Required | Gets or sets extracted sentence count. | getExtractedSentenceCount(): int | setExtractedSentenceCount(int extractedSentenceCount): void |
| `characterCount` | `int` | Required | Gets or sets character count. | getCharacterCount(): int | setCharacterCount(int characterCount): void |
| `usedByPrioritizedModel` | `?bool` | Optional | Gets or sets if this model is used by the specified prioritized model | getUsedByPrioritizedModel(): ?bool | setUsedByPrioritizedModel(?bool usedByPrioritizedModel): void |

## Example (as JSON)

```json
{
  "id": 112,
  "documentType": "testing",
  "extractedSentenceCount": 174,
  "characterCount": 130,
  "usedByPrioritizedModel": null
}
```

