
# Status 3 Enum

## Enumeration

`Status3Enum`

## Fields

| Name |
|  --- |
| `PROCESSING` |
| `PROCESSED` |

