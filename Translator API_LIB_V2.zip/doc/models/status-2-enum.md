
# Status 2 Enum

## Enumeration

`Status2Enum`

## Fields

| Name |
|  --- |
| `DEFAULT_` |
| `USERFILESUPLOADED` |
| `PROCESSING` |
| `EXTRACTING` |
| `EXTRACTED` |
| `VALIDATING` |
| `SENTENCEBREAKING` |
| `PROCESSEDFILESUPLOADING` |
| `FAILED` |
| `SUCCEEDED` |

