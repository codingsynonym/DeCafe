
# Text Translator Models Response Text Translator Workspace Users Response

A container for workspace users results

## Structure

`TextTranslatorModelsResponseTextTranslatorWorkspaceUsersResponse`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `users` | [`TextTranslatorModelsSharingInfo[]`](../../doc/models/text-translator-models-sharing-info.md) | Required | Gets or sets information for users with access to this workspace. | getUsers(): array | setUsers(array users): void |

## Example (as JSON)

```json
{
  "users": [
    {
      "id": 213,
      "user": {
        "id": "00002691-0000-0000-0000-000000000000",
        "emailAddress": "emailAddress3"
      },
      "role": {
        "id": 185,
        "roleName": "roleName3"
      }
    },
    {
      "id": 214,
      "user": {
        "id": "00002692-0000-0000-0000-000000000000",
        "emailAddress": "emailAddress4"
      },
      "role": {
        "id": 184,
        "roleName": "roleName4"
      }
    }
  ]
}
```

