
# Text Translator DAL Application User

## Structure

`TextTranslatorDALApplicationUser`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `id` | `?string` | Optional | - | getId(): ?string | setId(?string id): void |
| `userName` | `?string` | Optional | - | getUserName(): ?string | setUserName(?string userName): void |
| `organizationName` | `?string` | Optional | - | getOrganizationName(): ?string | setOrganizationName(?string organizationName): void |
| `inviteEmail` | `?string` | Optional | - | getInviteEmail(): ?string | setInviteEmail(?string inviteEmail): void |
| `createdDate` | `?\DateTime` | Optional | - | getCreatedDate(): ?\DateTime | setCreatedDate(?\DateTime createdDate): void |
| `modifiedDate` | `?\DateTime` | Optional | - | getModifiedDate(): ?\DateTime | setModifiedDate(?\DateTime modifiedDate): void |
| `isNewUser` | `?bool` | Optional | - | getIsNewUser(): ?bool | setIsNewUser(?bool isNewUser): void |
| `canShare` | `?bool` | Optional | - | getCanShare(): ?bool | setCanShare(?bool canShare): void |
| `objectId` | `?string` | Optional | - | getObjectId(): ?string | setObjectId(?string objectId): void |
| `tenantId` | `?string` | Optional | - | getTenantId(): ?string | setTenantId(?string tenantId): void |
| `upn` | `?string` | Optional | - | getUpn(): ?string | setUpn(?string upn): void |
| `documentCreatedByNavigation` | [`?(TextTranslatorDALDocument[])`](../../doc/models/text-translator-dal-document.md) | Optional | - | getDocumentCreatedByNavigation(): ?array | setDocumentCreatedByNavigation(?array documentCreatedByNavigation): void |
| `documentModifiedByNavigation` | [`?(TextTranslatorDALDocument[])`](../../doc/models/text-translator-dal-document.md) | Optional | - | getDocumentModifiedByNavigation(): ?array | setDocumentModifiedByNavigation(?array documentModifiedByNavigation): void |
| `file` | [`?(TextTranslatorDALFile[])`](../../doc/models/text-translator-dal-file.md) | Optional | - | getFile(): ?array | setFile(?array file): void |
| `modelCreatedByNavigation` | [`?(TextTranslatorDALModel[])`](../../doc/models/text-translator-dal-model.md) | Optional | - | getModelCreatedByNavigation(): ?array | setModelCreatedByNavigation(?array modelCreatedByNavigation): void |
| `modelModifiedByNavigation` | [`?(TextTranslatorDALModel[])`](../../doc/models/text-translator-dal-model.md) | Optional | - | getModelModifiedByNavigation(): ?array | setModelModifiedByNavigation(?array modelModifiedByNavigation): void |
| `projectCreatedByNavigation` | [`?(TextTranslatorDALProject[])`](../../doc/models/text-translator-dal-project.md) | Optional | - | getProjectCreatedByNavigation(): ?array | setProjectCreatedByNavigation(?array projectCreatedByNavigation): void |
| `projectModifiedByNavigation` | [`?(TextTranslatorDALProject[])`](../../doc/models/text-translator-dal-project.md) | Optional | - | getProjectModifiedByNavigation(): ?array | setProjectModifiedByNavigation(?array projectModifiedByNavigation): void |
| `testCreatedByNavigation` | [`?(TextTranslatorDALTest[])`](../../doc/models/text-translator-dal-test.md) | Optional | - | getTestCreatedByNavigation(): ?array | setTestCreatedByNavigation(?array testCreatedByNavigation): void |
| `testModifiedByNavigation` | [`?(TextTranslatorDALTest[])`](../../doc/models/text-translator-dal-test.md) | Optional | - | getTestModifiedByNavigation(): ?array | setTestModifiedByNavigation(?array testModifiedByNavigation): void |
| `uploadHistoryCreatedByNavigation` | [`?(TextTranslatorDALUploadHistory[])`](../../doc/models/text-translator-dal-upload-history.md) | Optional | - | getUploadHistoryCreatedByNavigation(): ?array | setUploadHistoryCreatedByNavigation(?array uploadHistoryCreatedByNavigation): void |
| `applications` | [`?(TextTranslatorDALApplication[])`](../../doc/models/text-translator-dal-application.md) | Optional | - | getApplications(): ?array | setApplications(?array applications): void |
| `applicationSharings` | [`?(TextTranslatorDALApplicationSharing[])`](../../doc/models/text-translator-dal-application-sharing.md) | Optional | - | getApplicationSharings(): ?array | setApplicationSharings(?array applicationSharings): void |

## Example (as JSON)

```json
{
  "id": null,
  "userName": null,
  "organizationName": null,
  "inviteEmail": null,
  "createdDate": null,
  "modifiedDate": null,
  "isNewUser": null,
  "canShare": null,
  "objectId": null,
  "tenantId": null,
  "upn": null,
  "documentCreatedByNavigation": null,
  "documentModifiedByNavigation": null,
  "file": null,
  "modelCreatedByNavigation": null,
  "modelModifiedByNavigation": null,
  "projectCreatedByNavigation": null,
  "projectModifiedByNavigation": null,
  "testCreatedByNavigation": null,
  "testModifiedByNavigation": null,
  "uploadHistoryCreatedByNavigation": null,
  "applications": null,
  "applicationSharings": null
}
```

