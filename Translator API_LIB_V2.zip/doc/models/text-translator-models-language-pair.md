
# Text Translator Models Language Pair

A language pair that is supported by the text translator for transalation.

## Structure

`TextTranslatorModelsLanguagePair`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `id` | `?int` | Optional | The Id for the language pair. | getId(): ?int | setId(?int id): void |
| `sourceLanguage` | [`TextTranslatorModelsTextTranslatorLanguage`](../../doc/models/text-translator-models-text-translator-language.md) | Required | Defines a language that can be used in the text translator. | getSourceLanguage(): TextTranslatorModelsTextTranslatorLanguage | setSourceLanguage(TextTranslatorModelsTextTranslatorLanguage sourceLanguage): void |
| `targetLanguage` | [`TextTranslatorModelsTextTranslatorLanguage`](../../doc/models/text-translator-models-text-translator-language.md) | Required | Defines a language that can be used in the text translator. | getTargetLanguage(): TextTranslatorModelsTextTranslatorLanguage | setTargetLanguage(TextTranslatorModelsTextTranslatorLanguage targetLanguage): void |

## Example (as JSON)

```json
{
  "id": null,
  "sourceLanguage": {
    "id": 50,
    "displayName": "displayName6",
    "languageCode": "languageCode2"
  },
  "targetLanguage": {
    "id": 172,
    "displayName": "displayName6",
    "languageCode": "languageCode2"
  }
}
```

