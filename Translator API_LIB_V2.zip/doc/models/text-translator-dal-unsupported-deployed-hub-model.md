
# Text Translator DAL Unsupported Deployed Hub Model

## Structure

`TextTranslatorDALUnsupportedDeployedHubModel`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `hubProjectId` | `?int` | Optional | - | getHubProjectId(): ?int | setHubProjectId(?int hubProjectId): void |
| `ctProjectId` | `?string` | Optional | - | getCtProjectId(): ?string | setCtProjectId(?string ctProjectId): void |
| `hubCategoryId` | `?string` | Optional | - | getHubCategoryId(): ?string | setHubCategoryId(?string hubCategoryId): void |
| `modelId` | `?int` | Optional | - | getModelId(): ?int | setModelId(?int modelId): void |
| `isDeployed` | `?bool` | Optional | - | getIsDeployed(): ?bool | setIsDeployed(?bool isDeployed): void |
| `isDeleted` | `?bool` | Optional | - | getIsDeleted(): ?bool | setIsDeleted(?bool isDeleted): void |
| `model` | [`?TextTranslatorDALModel`](../../doc/models/text-translator-dal-model.md) | Optional | - | getModel(): ?TextTranslatorDALModel | setModel(?TextTranslatorDALModel model): void |

## Example (as JSON)

```json
{
  "hubProjectId": null,
  "ctProjectId": null,
  "hubCategoryId": null,
  "modelId": null,
  "isDeployed": null,
  "isDeleted": null,
  "model": null
}
```

