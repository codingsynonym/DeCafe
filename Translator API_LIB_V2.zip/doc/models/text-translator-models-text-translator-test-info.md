
# Text Translator Models Text Translator Test Info

Contains the required details of a Translator Studio Test

## Structure

`TextTranslatorModelsTextTranslatorTestInfo`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `id` | `int` | Required | Gets or sets Id | getId(): int | setId(int id): void |
| `name` | `string` | Required | The Name of this test | getName(): string | setName(string name): void |
| `modelId` | `int` | Required | The Model with which the test is associated | getModelId(): int | setModelId(int modelId): void |
| `status` | [`string (StatusEnum)`](../../doc/models/status-enum.md) | Required | The test status | getStatus(): string | setStatus(string status): void |
| `baselineBleuScorePunctuated` | `?float` | Optional | Gets or sets baseline BleuScore (case-sensitive, punctuated). | getBaselineBleuScorePunctuated(): ?float | setBaselineBleuScorePunctuated(?float baselineBleuScorePunctuated): void |
| `bleuScorePunctuated` | `?float` | Optional | Gets or sets BleuScore (case-sensitive, punctuated). | getBleuScorePunctuated(): ?float | setBleuScorePunctuated(?float bleuScorePunctuated): void |
| `baselineBleuScoreUnpunctuated` | `?float` | Optional | Gets or sets baseline BleuScore (case-sensitive, Unpunctuated). | getBaselineBleuScoreUnpunctuated(): ?float | setBaselineBleuScoreUnpunctuated(?float baselineBleuScoreUnpunctuated): void |
| `bleuScoreUnpunctuated` | `?float` | Optional | Gets or sets BleuScore (case-sensitive, Unpunctuated). | getBleuScoreUnpunctuated(): ?float | setBleuScoreUnpunctuated(?float bleuScoreUnpunctuated): void |
| `baselineBleuScoreCIPunctuated` | `?float` | Optional | Gets or sets baseline BleuScore (case-insensitive, punctuated). | getBaselineBleuScoreCIPunctuated(): ?float | setBaselineBleuScoreCIPunctuated(?float baselineBleuScoreCIPunctuated): void |
| `bleuScoreCIPunctuated` | `?float` | Optional | Gets or sets BleuScore (case-insensitive, punctuated). | getBleuScoreCIPunctuated(): ?float | setBleuScoreCIPunctuated(?float bleuScoreCIPunctuated): void |
| `baselineBleuScoreCIUnpunctuated` | `?float` | Optional | Gets or sets baseline BleuScore (case-insensitive, Unpunctuated). | getBaselineBleuScoreCIUnpunctuated(): ?float | setBaselineBleuScoreCIUnpunctuated(?float baselineBleuScoreCIUnpunctuated): void |
| `bleuScoreCIUnpunctuated` | `?float` | Optional | Gets or sets BleuScore (case-insensitive, Unpunctuated). | getBleuScoreCIUnpunctuated(): ?float | setBleuScoreCIUnpunctuated(?float bleuScoreCIUnpunctuated): void |
| `sentenceCount` | `?int` | Optional | The SentenceCount of the test | getSentenceCount(): ?int | setSentenceCount(?int sentenceCount): void |
| `createdBy` | [`TextTranslatorModelsResponseUserInfo`](../../doc/models/text-translator-models-response-user-info.md) | Required | Basic user information - object used for<br>CreatedBy/ModifiedBy response fields | getCreatedBy(): TextTranslatorModelsResponseUserInfo | setCreatedBy(TextTranslatorModelsResponseUserInfo createdBy): void |
| `modifiedBy` | [`TextTranslatorModelsResponseUserInfo`](../../doc/models/text-translator-models-response-user-info.md) | Required | Basic user information - object used for<br>CreatedBy/ModifiedBy response fields | getModifiedBy(): TextTranslatorModelsResponseUserInfo | setModifiedBy(TextTranslatorModelsResponseUserInfo modifiedBy): void |

## Example (as JSON)

```json
{
  "id": 112,
  "name": "name0",
  "modelId": 108,
  "status": "testing",
  "baselineBleuScorePunctuated": null,
  "bleuScorePunctuated": null,
  "baselineBleuScoreUnpunctuated": null,
  "bleuScoreUnpunctuated": null,
  "baselineBleuScoreCIPunctuated": null,
  "bleuScoreCIPunctuated": null,
  "baselineBleuScoreCIUnpunctuated": null,
  "bleuScoreCIUnpunctuated": null,
  "sentenceCount": null,
  "createdBy": {
    "id": "000021b8-0000-0000-0000-000000000000",
    "userName": "userName4"
  },
  "modifiedBy": {
    "id": "0000222e-0000-0000-0000-000000000000",
    "userName": "userName2"
  }
}
```

