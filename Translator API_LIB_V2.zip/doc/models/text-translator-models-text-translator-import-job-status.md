
# Text Translator Models Text Translator Import Job Status

Defines the status of an import job.

## Structure

`TextTranslatorModelsTextTranslatorImportJobStatus`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `displayName` | `string` | Required | The display name of the status. | getDisplayName(): string | setDisplayName(string displayName): void |
| `id` | `int` | Required | The id for the status. | getId(): int | setId(int id): void |

## Example (as JSON)

```json
{
  "displayName": "displayName2",
  "id": 112
}
```

