
# Text Translator Models Response Text Translator Documents Response

API results container for TextTranslatorDocuments.

## Structure

`TextTranslatorModelsResponseTextTranslatorDocumentsResponse`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `paginatedDocuments` | [`TextTranslatorModelsResponseTextTranslatorDocumentInfoResponse`](../../doc/models/text-translator-models-response-text-translator-document-info-response.md) | Required | - | getPaginatedDocuments(): TextTranslatorModelsResponseTextTranslatorDocumentInfoResponse | setPaginatedDocuments(TextTranslatorModelsResponseTextTranslatorDocumentInfoResponse paginatedDocuments): void |
| `allDocuments` | [`?TextTranslatorModelsResponseTextTranslatorBaseDocumentResponse`](../../doc/models/text-translator-models-response-text-translator-base-document-response.md) | Optional | - | getAllDocuments(): ?TextTranslatorModelsResponseTextTranslatorBaseDocumentResponse | setAllDocuments(?TextTranslatorModelsResponseTextTranslatorBaseDocumentResponse allDocuments): void |

## Example (as JSON)

```json
{
  "paginatedDocuments": {
    "documents": [
      {
        "name": "name9",
        "isParallel": true,
        "createdBy": {
          "id": "00000c79-0000-0000-0000-000000000000",
          "userName": "userName5"
        },
        "modifiedBy": {
          "id": "00000cef-0000-0000-0000-000000000000",
          "userName": "userName3"
        },
        "files": null,
        "languages": null,
        "createdDate": null,
        "isAvailable": null,
        "id": 191,
        "documentType": "tuning",
        "extractedSentenceCount": 253,
        "characterCount": 51,
        "usedByPrioritizedModel": null
      },
      {
        "name": "name0",
        "isParallel": false,
        "createdBy": {
          "id": "00000c78-0000-0000-0000-000000000000",
          "userName": "userName4"
        },
        "modifiedBy": {
          "id": "00000cee-0000-0000-0000-000000000000",
          "userName": "userName2"
        },
        "files": null,
        "languages": null,
        "createdDate": null,
        "isAvailable": null,
        "id": 192,
        "documentType": "phraseDictionary",
        "extractedSentenceCount": 254,
        "characterCount": 50,
        "usedByPrioritizedModel": null
      },
      {
        "name": "name1",
        "isParallel": true,
        "createdBy": {
          "id": "00000c77-0000-0000-0000-000000000000",
          "userName": "userName3"
        },
        "modifiedBy": {
          "id": "00000ced-0000-0000-0000-000000000000",
          "userName": "userName1"
        },
        "files": null,
        "languages": null,
        "createdDate": null,
        "isAvailable": null,
        "id": 193,
        "documentType": "sentenceDictionary",
        "extractedSentenceCount": 255,
        "characterCount": 49,
        "usedByPrioritizedModel": null
      }
    ],
    "pageIndex": 146,
    "totalPageCount": 52
  },
  "allDocuments": null
}
```

