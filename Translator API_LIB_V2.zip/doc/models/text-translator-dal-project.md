
# Text Translator DAL Project

## Structure

`TextTranslatorDALProject`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `id` | `?string` | Optional | - | getId(): ?string | setId(?string id): void |
| `applicationId` | `?int` | Optional | - | getApplicationId(): ?int | setApplicationId(?int applicationId): void |
| `categoryId` | `?int` | Optional | - | getCategoryId(): ?int | setCategoryId(?int categoryId): void |
| `categoryDescriptor` | `?string` | Optional | - | getCategoryDescriptor(): ?string | setCategoryDescriptor(?string categoryDescriptor): void |
| `projectName` | `?string` | Optional | - | getProjectName(): ?string | setProjectName(?string projectName): void |
| `projectLabel` | `?string` | Optional | - | getProjectLabel(): ?string | setProjectLabel(?string projectLabel): void |
| `description` | `?string` | Optional | - | getDescription(): ?string | setDescription(?string description): void |
| `status` | `?string` | Optional | - | getStatus(): ?string | setStatus(?string status): void |
| `isDeleted` | `?bool` | Optional | - | getIsDeleted(): ?bool | setIsDeleted(?bool isDeleted): void |
| `createdBy` | `?string` | Optional | - | getCreatedBy(): ?string | setCreatedBy(?string createdBy): void |
| `modifiedBy` | `?string` | Optional | - | getModifiedBy(): ?string | setModifiedBy(?string modifiedBy): void |
| `createdDate` | `?\DateTime` | Optional | - | getCreatedDate(): ?\DateTime | setCreatedDate(?\DateTime createdDate): void |
| `modifiedDate` | `?\DateTime` | Optional | - | getModifiedDate(): ?\DateTime | setModifiedDate(?\DateTime modifiedDate): void |
| `languagePairId` | `?int` | Optional | - | getLanguagePairId(): ?int | setLanguagePairId(?int languagePairId): void |
| `application` | [`?TextTranslatorDALApplication`](../../doc/models/text-translator-dal-application.md) | Optional | - | getApplication(): ?TextTranslatorDALApplication | setApplication(?TextTranslatorDALApplication application): void |
| `category` | [`?TextTranslatorDALCategory`](../../doc/models/text-translator-dal-category.md) | Optional | - | getCategory(): ?TextTranslatorDALCategory | setCategory(?TextTranslatorDALCategory category): void |
| `createdByNavigation` | [`?TextTranslatorDALApplicationUser`](../../doc/models/text-translator-dal-application-user.md) | Optional | - | getCreatedByNavigation(): ?TextTranslatorDALApplicationUser | setCreatedByNavigation(?TextTranslatorDALApplicationUser createdByNavigation): void |
| `languagePair` | [`?TextTranslatorDALLanguagePair`](../../doc/models/text-translator-dal-language-pair.md) | Optional | - | getLanguagePair(): ?TextTranslatorDALLanguagePair | setLanguagePair(?TextTranslatorDALLanguagePair languagePair): void |
| `modifiedByNavigation` | [`?TextTranslatorDALApplicationUser`](../../doc/models/text-translator-dal-application-user.md) | Optional | - | getModifiedByNavigation(): ?TextTranslatorDALApplicationUser | setModifiedByNavigation(?TextTranslatorDALApplicationUser modifiedByNavigation): void |
| `projectCredit` | [`?TextTranslatorDALProjectCredit`](../../doc/models/text-translator-dal-project-credit.md) | Optional | - | getProjectCredit(): ?TextTranslatorDALProjectCredit | setProjectCredit(?TextTranslatorDALProjectCredit projectCredit): void |
| `model` | [`?(TextTranslatorDALModel[])`](../../doc/models/text-translator-dal-model.md) | Optional | - | getModel(): ?array | setModel(?array model): void |
| `billing` | [`?(TextTranslatorDALProjectBilling[])`](../../doc/models/text-translator-dal-project-billing.md) | Optional | - | getBilling(): ?array | setBilling(?array billing): void |
| `billingAudits` | [`?(TextTranslatorDALProjectBillingAudit[])`](../../doc/models/text-translator-dal-project-billing-audit.md) | Optional | - | getBillingAudits(): ?array | setBillingAudits(?array billingAudits): void |

## Example (as JSON)

```json
{
  "id": null,
  "applicationId": null,
  "categoryId": null,
  "categoryDescriptor": null,
  "projectName": null,
  "projectLabel": null,
  "description": null,
  "status": null,
  "isDeleted": null,
  "createdBy": null,
  "modifiedBy": null,
  "createdDate": null,
  "modifiedDate": null,
  "languagePairId": null,
  "application": null,
  "category": null,
  "createdByNavigation": null,
  "languagePair": null,
  "modifiedByNavigation": null,
  "projectCredit": null,
  "model": null,
  "billing": null,
  "billingAudits": null
}
```

