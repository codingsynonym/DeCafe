
# Text Translator Models Text Translator File Info

A class for the file information.

## Structure

`TextTranslatorModelsTextTranslatorFileInfo`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `id` | `?int` | Optional | Gets or sets Id | getId(): ?int | setId(?int id): void |
| `fileName` | `?string` | Optional | Gets or sets the File Name | getFileName(): ?string | setFileName(?string fileName): void |
| `language` | [`?TextTranslatorModelsTextTranslatorLanguage`](../../doc/models/text-translator-models-text-translator-language.md) | Optional | Defines a language that can be used in the text translator. | getLanguage(): ?TextTranslatorModelsTextTranslatorLanguage | setLanguage(?TextTranslatorModelsTextTranslatorLanguage language): void |
| `uploadDate` | `?\DateTime` | Optional | Gets or sets UploadDate | getUploadDate(): ?\DateTime | setUploadDate(?\DateTime uploadDate): void |
| `extractedSentenceCount` | `?int` | Optional | Gets or sets ExtractedSentenceCount | getExtractedSentenceCount(): ?int | setExtractedSentenceCount(?int extractedSentenceCount): void |

## Example (as JSON)

```json
{
  "id": null,
  "fileName": null,
  "language": null,
  "uploadDate": null,
  "extractedSentenceCount": null
}
```

