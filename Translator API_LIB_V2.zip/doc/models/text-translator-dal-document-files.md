
# Text Translator DAL Document Files

## Structure

`TextTranslatorDALDocumentFiles`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `id` | `?int` | Optional | - | getId(): ?int | setId(?int id): void |
| `documentId` | `?int` | Optional | - | getDocumentId(): ?int | setDocumentId(?int documentId): void |
| `fileId` | `?int` | Optional | - | getFileId(): ?int | setFileId(?int fileId): void |
| `document` | [`?TextTranslatorDALDocument`](../../doc/models/text-translator-dal-document.md) | Optional | - | getDocument(): ?TextTranslatorDALDocument | setDocument(?TextTranslatorDALDocument document): void |
| `file` | [`?TextTranslatorDALFile`](../../doc/models/text-translator-dal-file.md) | Optional | - | getFile(): ?TextTranslatorDALFile | setFile(?TextTranslatorDALFile file): void |

## Example (as JSON)

```json
{
  "id": null,
  "documentId": null,
  "fileId": null,
  "document": null,
  "file": null
}
```

