
# Text Translator Api Models Response Test Translator Import Files Response

ImportFiles response.
Return the job ids for imported files

## Structure

`TextTranslatorApiModelsResponseTestTranslatorImportFilesResponse`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `jobId` | `?string` | Optional | Gets or sets the job identifier. | getJobId(): ?string | setJobId(?string jobId): void |
| `filesAcceptedForProcessing` | `?(string[])` | Optional | Gets or sets the files accepted for processing. | getFilesAcceptedForProcessing(): ?array | setFilesAcceptedForProcessing(?array filesAcceptedForProcessing): void |

## Example (as JSON)

```json
{
  "jobId": null,
  "filesAcceptedForProcessing": null
}
```

