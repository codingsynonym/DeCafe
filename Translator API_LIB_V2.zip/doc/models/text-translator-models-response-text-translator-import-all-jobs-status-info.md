
# Text Translator Models Response Text Translator Import All Jobs Status Info

ImportAllJobsStatusResponse

## Structure

`TextTranslatorModelsResponseTextTranslatorImportAllJobsStatusInfo`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `jobId` | `?string` | Optional | Relevant job id. | getJobId(): ?string | setJobId(?string jobId): void |
| `numberFiles` | `?int` | Optional | The number of files represented by this job id. The parent placeholder<br>for .zip and .tmx files is only included in this count if it is the only<br>item listed in UploadHistory for the job. | getNumberFiles(): ?int | setNumberFiles(?int numberFiles): void |
| `numberFilesWithErrors` | `?int` | Optional | The number of files represented by this job id that have failed. The<br>parent placeholder for .zip and .tmx files is only included in this count<br>if it is the only item listed in UploadHistory for the job. | getNumberFilesWithErrors(): ?int | setNumberFilesWithErrors(?int numberFilesWithErrors): void |
| `name` | `?string` | Optional | Display name of the job. For .zip/ .tmx files, this is name + extension<br>of the parent item. For parallel data this "DocumentName" row<br>in the UploadHistory table. | getName(): ?string | setName(?string name): void |
| `status` | [`?TextTranslatorModelsTextTranslatorImportJobStatus`](../../doc/models/text-translator-models-text-translator-import-job-status.md) | Optional | Defines the status of an import job. | getStatus(): ?TextTranslatorModelsTextTranslatorImportJobStatus | setStatus(?TextTranslatorModelsTextTranslatorImportJobStatus status): void |
| `documentType` | [`?string (DocumentType2Enum)`](../../doc/models/document-type-2-enum.md) | Optional | The type of document uploaded by this job (ex: training, tuning, testing). | getDocumentType(): ?string | setDocumentType(?string documentType): void |
| `createdDate` | `?\DateTime` | Optional | Job creation date. | getCreatedDate(): ?\DateTime | setCreatedDate(?\DateTime createdDate): void |
| `createdBy` | [`?TextTranslatorModelsResponseUserInfo`](../../doc/models/text-translator-models-response-user-info.md) | Optional | Basic user information - object used for<br>CreatedBy/ModifiedBy response fields | getCreatedBy(): ?TextTranslatorModelsResponseUserInfo | setCreatedBy(?TextTranslatorModelsResponseUserInfo createdBy): void |
| `languages` | [`?(TextTranslatorModelsTextTranslatorLanguage[])`](../../doc/models/text-translator-models-text-translator-language.md) | Optional | The file languages associated with this document. | getLanguages(): ?array | setLanguages(?array languages): void |

## Example (as JSON)

```json
{
  "jobId": null,
  "numberFiles": null,
  "numberFilesWithErrors": null,
  "name": null,
  "status": null,
  "documentType": null,
  "createdDate": null,
  "createdBy": null,
  "languages": null
}
```

