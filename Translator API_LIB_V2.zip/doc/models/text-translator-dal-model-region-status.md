
# Text Translator DAL Model Region Status

## Structure

`TextTranslatorDALModelRegionStatus`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `id` | `?int` | Optional | - | getId(): ?int | setId(?int id): void |
| `modelId` | `?int` | Optional | - | getModelId(): ?int | setModelId(?int modelId): void |
| `region` | `?int` | Optional | - | getRegion(): ?int | setRegion(?int region): void |
| `isDeployed` | `?bool` | Optional | - | getIsDeployed(): ?bool | setIsDeployed(?bool isDeployed): void |
| `deploymentStatus` | `?int` | Optional | - | getDeploymentStatus(): ?int | setDeploymentStatus(?int deploymentStatus): void |
| `model` | [`?TextTranslatorDALModel`](../../doc/models/text-translator-dal-model.md) | Optional | - | getModel(): ?TextTranslatorDALModel | setModel(?TextTranslatorDALModel model): void |

## Example (as JSON)

```json
{
  "id": null,
  "modelId": null,
  "region": null,
  "isDeployed": null,
  "deploymentStatus": null,
  "model": null
}
```

