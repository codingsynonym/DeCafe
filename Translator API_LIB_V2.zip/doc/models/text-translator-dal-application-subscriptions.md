
# Text Translator DAL Application Subscriptions

## Structure

`TextTranslatorDALApplicationSubscriptions`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `id` | `?int` | Optional | - | getId(): ?int | setId(?int id): void |
| `applicationIdentifier` | `?string` | Optional | - | getApplicationIdentifier(): ?string | setApplicationIdentifier(?string applicationIdentifier): void |
| `resourceId` | `?string` | Optional | - | getResourceId(): ?string | setResourceId(?string resourceId): void |
| `billingRegion` | `?string` | Optional | - | getBillingRegion(): ?string | setBillingRegion(?string billingRegion): void |
| `encryptionScopeName` | `?string` | Optional | - | getEncryptionScopeName(): ?string | setEncryptionScopeName(?string encryptionScopeName): void |
| `dataRegion` | `?string` | Optional | - | getDataRegion(): ?string | setDataRegion(?string dataRegion): void |
| `isCMKEnabled` | `?bool` | Optional | - | getIsCMKEnabled(): ?bool | setIsCMKEnabled(?bool isCMKEnabled): void |
| `applicationIdentifierNavigation` | [`?TextTranslatorDALApplication`](../../doc/models/text-translator-dal-application.md) | Optional | - | getApplicationIdentifierNavigation(): ?TextTranslatorDALApplication | setApplicationIdentifierNavigation(?TextTranslatorDALApplication applicationIdentifierNavigation): void |
| `billingRegionNavigation` | [`?TextTranslatorDALBillingRegions`](../../doc/models/text-translator-dal-billing-regions.md) | Optional | - | getBillingRegionNavigation(): ?TextTranslatorDALBillingRegions | setBillingRegionNavigation(?TextTranslatorDALBillingRegions billingRegionNavigation): void |
| `dataRegionNavigation` | [`?TextTranslatorDALBillingRegions`](../../doc/models/text-translator-dal-billing-regions.md) | Optional | - | getDataRegionNavigation(): ?TextTranslatorDALBillingRegions | setDataRegionNavigation(?TextTranslatorDALBillingRegions dataRegionNavigation): void |

## Example (as JSON)

```json
{
  "id": null,
  "applicationIdentifier": null,
  "resourceId": null,
  "billingRegion": null,
  "encryptionScopeName": null,
  "dataRegion": null,
  "isCMKEnabled": null,
  "applicationIdentifierNavigation": null,
  "billingRegionNavigation": null,
  "dataRegionNavigation": null
}
```

