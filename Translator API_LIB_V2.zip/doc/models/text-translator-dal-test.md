
# Text Translator DAL Test

## Structure

`TextTranslatorDALTest`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `id` | `?int` | Optional | - | getId(): ?int | setId(?int id): void |
| `name` | `?string` | Optional | - | getName(): ?string | setName(?string name): void |
| `modelId` | `?int` | Optional | - | getModelId(): ?int | setModelId(?int modelId): void |
| `status` | `?string` | Optional | - | getStatus(): ?string | setStatus(?string status): void |
| `sentenceCount` | `?int` | Optional | - | getSentenceCount(): ?int | setSentenceCount(?int sentenceCount): void |
| `baselineBleuScorePunctuated` | `?float` | Optional | - | getBaselineBleuScorePunctuated(): ?float | setBaselineBleuScorePunctuated(?float baselineBleuScorePunctuated): void |
| `bleuScorePunctuated` | `?float` | Optional | - | getBleuScorePunctuated(): ?float | setBleuScorePunctuated(?float bleuScorePunctuated): void |
| `baselineBleuScoreUnpunctuated` | `?float` | Optional | - | getBaselineBleuScoreUnpunctuated(): ?float | setBaselineBleuScoreUnpunctuated(?float baselineBleuScoreUnpunctuated): void |
| `bleuScoreUnpunctuated` | `?float` | Optional | - | getBleuScoreUnpunctuated(): ?float | setBleuScoreUnpunctuated(?float bleuScoreUnpunctuated): void |
| `baselineBleuScoreCipunctuated` | `?float` | Optional | - | getBaselineBleuScoreCipunctuated(): ?float | setBaselineBleuScoreCipunctuated(?float baselineBleuScoreCipunctuated): void |
| `bleuScoreCipunctuated` | `?float` | Optional | - | getBleuScoreCipunctuated(): ?float | setBleuScoreCipunctuated(?float bleuScoreCipunctuated): void |
| `baselineBleuScoreCiunpunctuated` | `?float` | Optional | - | getBaselineBleuScoreCiunpunctuated(): ?float | setBaselineBleuScoreCiunpunctuated(?float baselineBleuScoreCiunpunctuated): void |
| `bleuScoreCiunpunctuated` | `?float` | Optional | - | getBleuScoreCiunpunctuated(): ?float | setBleuScoreCiunpunctuated(?float bleuScoreCiunpunctuated): void |
| `createdBy` | `?string` | Optional | - | getCreatedBy(): ?string | setCreatedBy(?string createdBy): void |
| `modifiedBy` | `?string` | Optional | - | getModifiedBy(): ?string | setModifiedBy(?string modifiedBy): void |
| `createdByNavigation` | [`?TextTranslatorDALApplicationUser`](../../doc/models/text-translator-dal-application-user.md) | Optional | - | getCreatedByNavigation(): ?TextTranslatorDALApplicationUser | setCreatedByNavigation(?TextTranslatorDALApplicationUser createdByNavigation): void |
| `model` | [`?TextTranslatorDALModel`](../../doc/models/text-translator-dal-model.md) | Optional | - | getModel(): ?TextTranslatorDALModel | setModel(?TextTranslatorDALModel model): void |
| `modifiedByNavigation` | [`?TextTranslatorDALApplicationUser`](../../doc/models/text-translator-dal-application-user.md) | Optional | - | getModifiedByNavigation(): ?TextTranslatorDALApplicationUser | setModifiedByNavigation(?TextTranslatorDALApplicationUser modifiedByNavigation): void |

## Example (as JSON)

```json
{
  "id": null,
  "name": null,
  "modelId": null,
  "status": null,
  "sentenceCount": null,
  "baselineBleuScorePunctuated": null,
  "bleuScorePunctuated": null,
  "baselineBleuScoreUnpunctuated": null,
  "bleuScoreUnpunctuated": null,
  "baselineBleuScoreCipunctuated": null,
  "bleuScoreCipunctuated": null,
  "baselineBleuScoreCiunpunctuated": null,
  "bleuScoreCiunpunctuated": null,
  "createdBy": null,
  "modifiedBy": null,
  "createdByNavigation": null,
  "model": null,
  "modifiedByNavigation": null
}
```

