
# Text Translator Models Text Translator Billing Regions

Defines the a billing region

## Structure

`TextTranslatorModelsTextTranslatorBillingRegions`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `billingRegionCode` | `string` | Required | Gets or sets the billing region (GBL, USW2, etc) | getBillingRegionCode(): string | setBillingRegionCode(string billingRegionCode): void |
| `billingRegionName` | `string` | Required | Gets or sets the billing region name (Global, US West 2, etc) | getBillingRegionName(): string | setBillingRegionName(string billingRegionName): void |

## Example (as JSON)

```json
{
  "billingRegionCode": "billingRegionCode6",
  "billingRegionName": "billingRegionName2"
}
```

