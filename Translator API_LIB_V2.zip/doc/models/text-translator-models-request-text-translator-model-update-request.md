
# Text Translator Models Request Text Translator Model Update Request

The input class for model update requests.

## Structure

`TextTranslatorModelsRequestTextTranslatorModelUpdateRequest`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `name` | `?string` | Optional | Gets or sets Name | getName(): ?string | setName(?string name): void |
| `addDocuments` | `?(int[])` | Optional | Adds documents to the model. | getAddDocuments(): ?array | setAddDocuments(?array addDocuments): void |
| `removeDocuments` | `?(int[])` | Optional | Removes documents from the model. | getRemoveDocuments(): ?array | setRemoveDocuments(?array removeDocuments): void |

## Example (as JSON)

```json
{
  "name": null,
  "addDocuments": null,
  "removeDocuments": null
}
```

