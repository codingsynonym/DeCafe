
# Microsoft Net Http Headers Entity Tag Header Value

## Structure

`MicrosoftNetHttpHeadersEntityTagHeaderValue`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `tag` | [`?MicrosoftExtensionsPrimitivesStringSegment`](../../doc/models/microsoft-extensions-primitives-string-segment.md) | Optional | - | getTag(): ?MicrosoftExtensionsPrimitivesStringSegment | setTag(?MicrosoftExtensionsPrimitivesStringSegment tag): void |
| `isWeak` | `?bool` | Optional | - | getIsWeak(): ?bool | setIsWeak(?bool isWeak): void |

## Example (as JSON)

```json
{
  "tag": null,
  "isWeak": null
}
```

