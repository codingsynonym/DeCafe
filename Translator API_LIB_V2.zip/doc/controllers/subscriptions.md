# Subscriptions

```php
$subscriptionsController = $client->getSubscriptionsController();
```

## Class Name

`SubscriptionsController`

## Methods

* [Api Texttranslator V1 0 Subscriptions Get](../../doc/controllers/subscriptions.md#api-texttranslator-v1-0-subscriptions-get)
* [Api Texttranslator V1 0 Subscriptions Put](../../doc/controllers/subscriptions.md#api-texttranslator-v1-0-subscriptions-put)
* [Api Texttranslator V1 0 Subscriptions Post](../../doc/controllers/subscriptions.md#api-texttranslator-v1-0-subscriptions-post)
* [Api Texttranslator V1 0 Subscriptions Delete](../../doc/controllers/subscriptions.md#api-texttranslator-v1-0-subscriptions-delete)
* [Api Texttranslator V1 0 Subscriptions Billingregions Get](../../doc/controllers/subscriptions.md#api-texttranslator-v1-0-subscriptions-billingregions-get)


# Api Texttranslator V1 0 Subscriptions Get

Gets the translator text subscription for this workspace.

```php
function apiTexttranslatorV10SubscriptionsGet(
    string $authorization,
    string $workspaceId
): TextTranslatorModelsTextTranslatorSubscriptionResponse
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `authorization` | `string` | Header, Required | Access token |
| `workspaceId` | `string` | Query, Required | Workspace id |

## Response Type

[`TextTranslatorModelsTextTranslatorSubscriptionResponse`](../../doc/models/text-translator-models-text-translator-subscription-response.md)

## Example Usage

```php
$authorization = 'authorization6';
$workspaceId = 'workspaceId6';

$result = $subscriptionsController->apiTexttranslatorV10SubscriptionsGet($authorization, $workspaceId);
```


# Api Texttranslator V1 0 Subscriptions Put

Updates a subscription key

```php
function apiTexttranslatorV10SubscriptionsPut(
    TextTranslatorModelsRequestTextTranslatorSubscriptionRequest $subscription,
    string $authorization,
    string $workspaceId
): void
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `subscription` | [`TextTranslatorModelsRequestTextTranslatorSubscriptionRequest`](../../doc/models/text-translator-models-request-text-translator-subscription-request.md) | Body, Required | The subscription |
| `authorization` | `string` | Header, Required | Access token |
| `workspaceId` | `string` | Query, Required | Workspace to add the subscription to |

## Response Type

`void`

## Example Usage

```php
$subscription_subscriptionKey = 'subscriptionKey4';
$subscription_billingRegionCode = 'billingRegionCode8';
$subscription = new Models\TextTranslatorModelsRequestTextTranslatorSubscriptionRequest(
    $subscription_subscriptionKey,
    $subscription_billingRegionCode
);
$authorization = 'authorization6';
$workspaceId = 'workspaceId6';

$subscriptionsController->apiTexttranslatorV10SubscriptionsPut($subscription, $authorization, $workspaceId);
```


# Api Texttranslator V1 0 Subscriptions Post

Add a subscription key.

```php
function apiTexttranslatorV10SubscriptionsPost(
    TextTranslatorModelsRequestTextTranslatorSubscriptionRequest $subscription,
    string $authorization,
    string $workspaceId
): void
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `subscription` | [`TextTranslatorModelsRequestTextTranslatorSubscriptionRequest`](../../doc/models/text-translator-models-request-text-translator-subscription-request.md) | Body, Required | The subscription |
| `authorization` | `string` | Header, Required | Access token |
| `workspaceId` | `string` | Query, Required | Workspace to add the subscription to |

## Response Type

`void`

## Example Usage

```php
$subscription_subscriptionKey = 'subscriptionKey4';
$subscription_billingRegionCode = 'billingRegionCode8';
$subscription = new Models\TextTranslatorModelsRequestTextTranslatorSubscriptionRequest(
    $subscription_subscriptionKey,
    $subscription_billingRegionCode
);
$authorization = 'authorization6';
$workspaceId = 'workspaceId6';

$subscriptionsController->apiTexttranslatorV10SubscriptionsPost($subscription, $authorization, $workspaceId);
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 400 | A subscription key for this workspace already exists. | `ApiException` |
| 404 | The user does not have permission to access the given workspace, or it does not exist. | `ApiException` |


# Api Texttranslator V1 0 Subscriptions Delete

Deletes a subscription key.

```php
function apiTexttranslatorV10SubscriptionsDelete(string $workspaceId, string $authorization): void
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `workspaceId` | `string` | Query, Required | Workspace id to delete the subscription key from |
| `authorization` | `string` | Header, Required | Access token |

## Response Type

`void`

## Example Usage

```php
$workspaceId = 'workspaceId6';
$authorization = 'authorization6';

$subscriptionsController->apiTexttranslatorV10SubscriptionsDelete($workspaceId, $authorization);
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 404 | NotFound | `ApiException` |


# Api Texttranslator V1 0 Subscriptions Billingregions Get

Gets the translator text subscription regions.

```php
function apiTexttranslatorV10SubscriptionsBillingregionsGet(string $authorization): array
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `authorization` | `string` | Header, Required | - |

## Response Type

[`TextTranslatorModelsTextTranslatorBillingRegions[]`](../../doc/models/text-translator-models-text-translator-billing-regions.md)

## Example Usage

```php
$authorization = 'authorization6';

$result = $subscriptionsController->apiTexttranslatorV10SubscriptionsBillingregionsGet($authorization);
```

