# Workspaces

```php
$workspacesController = $client->getWorkspacesController();
```

## Class Name

`WorkspacesController`

## Methods

* [Api Texttranslator V1 0 Workspaces Get](../../doc/controllers/workspaces.md#api-texttranslator-v1-0-workspaces-get)
* [Api Texttranslator V1 0 Workspaces Post](../../doc/controllers/workspaces.md#api-texttranslator-v1-0-workspaces-post)
* [Api Texttranslator V1 0 Workspaces by Id Get](../../doc/controllers/workspaces.md#api-texttranslator-v1-0-workspaces-by-id-get)
* [Api Texttranslator V1 0 Workspaces by Id Delete](../../doc/controllers/workspaces.md#api-texttranslator-v1-0-workspaces-by-id-delete)
* [Api Texttranslator V1 0 Workspaces by Id Name Put](../../doc/controllers/workspaces.md#api-texttranslator-v1-0-workspaces-by-id-name-put)
* [Api Texttranslator V1 0 Workspaces by Id Pin Put](../../doc/controllers/workspaces.md#api-texttranslator-v1-0-workspaces-by-id-pin-put)
* [Api Texttranslator V1 0 Workspaces by Id Users Get](../../doc/controllers/workspaces.md#api-texttranslator-v1-0-workspaces-by-id-users-get)
* [Api Texttranslator V1 0 Workspaces by Id Users Post](../../doc/controllers/workspaces.md#api-texttranslator-v1-0-workspaces-by-id-users-post)
* [Api Texttranslator V1 0 Workspaces by Id Users by User Id Delete](../../doc/controllers/workspaces.md#api-texttranslator-v1-0-workspaces-by-id-users-by-user-id-delete)
* [Api Texttranslator V1 0 Workspaces by Id Migration Get](../../doc/controllers/workspaces.md#api-texttranslator-v1-0-workspaces-by-id-migration-get)
* [Api Texttranslator V1 0 Workspaces by Id Export by Migration Id Post](../../doc/controllers/workspaces.md#api-texttranslator-v1-0-workspaces-by-id-export-by-migration-id-post)


# Api Texttranslator V1 0 Workspaces Get

Gets the list of workspaces that the user has access to.

```php
function apiTexttranslatorV10WorkspacesGet(
    string $authorization
): TextTranslatorModelsResponseTextTranslatorWorkspacesReponse
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `authorization` | `string` | Header, Required | Access token |

## Response Type

[`TextTranslatorModelsResponseTextTranslatorWorkspacesReponse`](../../doc/models/text-translator-models-response-text-translator-workspaces-reponse.md)

## Example Usage

```php
$authorization = 'authorization6';

$result = $workspacesController->apiTexttranslatorV10WorkspacesGet($authorization);
```


# Api Texttranslator V1 0 Workspaces Post

Creates a new workspace

```php
function apiTexttranslatorV10WorkspacesPost(
    TextTranslatorModelsRequestTextTranslatorCreateWorkspaceRequest $newWorkspace,
    string $authorization
): void
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `newWorkspace` | [`TextTranslatorModelsRequestTextTranslatorCreateWorkspaceRequest`](../../doc/models/text-translator-models-request-text-translator-create-workspace-request.md) | Body, Required | Subscription and workspace name |
| `authorization` | `string` | Header, Required | Access token |

## Response Type

`void`

## Example Usage

```php
$newWorkspace_name = 'name4';
$newWorkspace_subscription_subscriptionKey = 'subscriptionKey8';
$newWorkspace_subscription_billingRegionCode = 'billingRegionCode6';
$newWorkspace_subscription = new Models\TextTranslatorModelsRequestTextTranslatorSubscriptionRequest(
    $newWorkspace_subscription_subscriptionKey,
    $newWorkspace_subscription_billingRegionCode
);
$newWorkspace = new Models\TextTranslatorModelsRequestTextTranslatorCreateWorkspaceRequest(
    $newWorkspace_name,
    $newWorkspace_subscription
);
$authorization = 'authorization6';

$workspacesController->apiTexttranslatorV10WorkspacesPost($newWorkspace, $authorization);
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 400 | The request was not formatted correctly. | `ApiException` |


# Api Texttranslator V1 0 Workspaces by Id Get

Gets the information for a specific workspace.

```php
function apiTexttranslatorV10WorkspacesByIdGet(
    string $id,
    string $authorization
): TextTranslatorApiModelsTextTranslatorWorkspaceInfo
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `id` | `string` | Template, Required | The id for the workspace |
| `authorization` | `string` | Header, Required | Access token |

## Response Type

[`TextTranslatorApiModelsTextTranslatorWorkspaceInfo`](../../doc/models/text-translator-api-models-text-translator-workspace-info.md)

## Example Usage

```php
$id = 'id0';
$authorization = 'authorization6';

$result = $workspacesController->apiTexttranslatorV10WorkspacesByIdGet($id, $authorization);
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 404 | The user does not have permission to access the given workspace, or it does not exist. | `ApiException` |


# Api Texttranslator V1 0 Workspaces by Id Delete

Deletes a workspace

```php
function apiTexttranslatorV10WorkspacesByIdDelete(string $id, string $authorization): void
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `id` | `string` | Template, Required | The id for the workspace |
| `authorization` | `string` | Header, Required | Access token |

## Response Type

`void`

## Example Usage

```php
$id = 'id0';
$authorization = 'authorization6';

$workspacesController->apiTexttranslatorV10WorkspacesByIdDelete($id, $authorization);
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 404 | The user does not have permission to access the given workspace, or it does not exist. | `ApiException` |


# Api Texttranslator V1 0 Workspaces by Id Name Put

Changes the name of a workspace

```php
function apiTexttranslatorV10WorkspacesByIdNamePut(
    TextTranslatorModelsRequestTextTranslatorWorkspaceNameRequest $name,
    string $id,
    string $authorization
): void
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `name` | [`TextTranslatorModelsRequestTextTranslatorWorkspaceNameRequest`](../../doc/models/text-translator-models-request-text-translator-workspace-name-request.md) | Body, Required | The new name |
| `id` | `string` | Template, Required | The id for the workspace |
| `authorization` | `string` | Header, Required | Access token |

## Response Type

`void`

## Example Usage

```php
$name_name = 'name0';
$name = new Models\TextTranslatorModelsRequestTextTranslatorWorkspaceNameRequest(
    $name_name
);
$id = 'id0';
$authorization = 'authorization6';

$workspacesController->apiTexttranslatorV10WorkspacesByIdNamePut($name, $id, $authorization);
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 400 | The request was not formatted correctly. | `ApiException` |
| 404 | The user does not have permission to access the given workspace, or it does not exist. | `ApiException` |


# Api Texttranslator V1 0 Workspaces by Id Pin Put

Pins this workspace as the default workspace.

```php
function apiTexttranslatorV10WorkspacesByIdPinPut(
    string $id,
    string $authorization
): TextTranslatorApiModelsTextTranslatorWorkspaceInfo
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `id` | `string` | Template, Required | The id for the workspace |
| `authorization` | `string` | Header, Required | Access token |

## Response Type

[`TextTranslatorApiModelsTextTranslatorWorkspaceInfo`](../../doc/models/text-translator-api-models-text-translator-workspace-info.md)

## Example Usage

```php
$id = 'id0';
$authorization = 'authorization6';

$result = $workspacesController->apiTexttranslatorV10WorkspacesByIdPinPut($id, $authorization);
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 400 | The request was not formatted correctly. | `ApiException` |
| 404 | The user does not have permission to access the given workspace, or it does not exist. | `ApiException` |


# Api Texttranslator V1 0 Workspaces by Id Users Get

Gets the list of users with access to a specific workspace

```php
function apiTexttranslatorV10WorkspacesByIdUsersGet(
    string $id,
    string $authorization
): TextTranslatorModelsResponseTextTranslatorWorkspaceUsersResponse
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `id` | `string` | Template, Required | The id for the workspace |
| `authorization` | `string` | Header, Required | Access token |

## Response Type

[`TextTranslatorModelsResponseTextTranslatorWorkspaceUsersResponse`](../../doc/models/text-translator-models-response-text-translator-workspace-users-response.md)

## Example Usage

```php
$id = 'id0';
$authorization = 'authorization6';

$result = $workspacesController->apiTexttranslatorV10WorkspacesByIdUsersGet($id, $authorization);
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 404 | The user does not have permission to access the given workspace, or it does not exist. | `ApiException` |


# Api Texttranslator V1 0 Workspaces by Id Users Post

Adds users to the workspace. If the user already has permissions to the
workspace, this  will update their level of permissions to whatever is
specified.

```php
function apiTexttranslatorV10WorkspacesByIdUsersPost(array $users, string $id, string $authorization): void
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `users` | [`TextTranslatorModelsRequestTextTranslatorWorkspacePermissionInfo[]`](../../doc/models/text-translator-models-request-text-translator-workspace-permission-info.md) | Body, Required | The users to be added |
| `id` | `string` | Template, Required | The id for the workspace |
| `authorization` | `string` | Header, Required | Access token |

## Response Type

`void`

## Example Usage

```php
$users = [];

$users_0_emailAddress = 'emailAddress3';
$users_0_roleId = 99;
$users[0] = new Models\TextTranslatorModelsRequestTextTranslatorWorkspacePermissionInfo(
    $users_0_emailAddress,
    $users_0_roleId
);

$users_1_emailAddress = 'emailAddress4';
$users_1_roleId = 98;
$users[1] = new Models\TextTranslatorModelsRequestTextTranslatorWorkspacePermissionInfo(
    $users_1_emailAddress,
    $users_1_roleId
);

$id = 'id0';
$authorization = 'authorization6';

$workspacesController->apiTexttranslatorV10WorkspacesByIdUsersPost($users, $id, $authorization);
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 400 | The request was not formatted correctly. | `ApiException` |
| 404 | The user does not have permission to access the given workspace, or it does not exist. | `ApiException` |


# Api Texttranslator V1 0 Workspaces by Id Users by User Id Delete

Removes a users permissions to the workspace.

```php
function apiTexttranslatorV10WorkspacesByIdUsersByUserIdDelete(
    string $id,
    int $userId,
    string $authorization
): void
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `id` | `string` | Template, Required | The id for the workspace |
| `userId` | `int` | Template, Required | The user to be deleted |
| `authorization` | `string` | Header, Required | Access token |

## Response Type

`void`

## Example Usage

```php
$id = 'id0';
$userId = 28;
$authorization = 'authorization6';

$workspacesController->apiTexttranslatorV10WorkspacesByIdUsersByUserIdDelete($id, $userId, $authorization);
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 404 | The user does not have permission to access the given workspace, or it does not exist. | `ApiException` |


# Api Texttranslator V1 0 Workspaces by Id Migration Get

Get the summary for all migration operations on the current workspace

```php
function apiTexttranslatorV10WorkspacesByIdMigrationGet(string $id, string $authorization): void
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `id` | `string` | Template, Required | Workspace Id |
| `authorization` | `string` | Header, Required | Authorization token |

## Response Type

`void`

## Example Usage

```php
$id = 'id0';
$authorization = 'authorization6';

$workspacesController->apiTexttranslatorV10WorkspacesByIdMigrationGet($id, $authorization);
```


# Api Texttranslator V1 0 Workspaces by Id Export by Migration Id Post

Gets the details of the migration operation in a zip file.

```php
function apiTexttranslatorV10WorkspacesByIdExportByMigrationIdPost(
    string $id,
    string $migrationId,
    string $authorization
): MicrosoftAspNetCoreMvcVirtualFileResult
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `id` | `string` | Template, Required | The Id of the workspace |
| `migrationId` | `string` | Template, Required | The migration id for which details are served. |
| `authorization` | `string` | Header, Required | - |

## Response Type

[`MicrosoftAspNetCoreMvcVirtualFileResult`](../../doc/models/microsoft-asp-net-core-mvc-virtual-file-result.md)

## Example Usage

```php
$id = 'id0';
$migrationId = 'migrationId4';
$authorization = 'authorization6';

$result = $workspacesController->apiTexttranslatorV10WorkspacesByIdExportByMigrationIdPost($id, $migrationId, $authorization);
```

