# Languages

```php
$languagesController = $client->getLanguagesController();
```

## Class Name

`LanguagesController`

## Methods

* [Api Texttranslator V1 0 Languages Get](../../doc/controllers/languages.md#api-texttranslator-v1-0-languages-get)
* [Api Texttranslator V1 0 Languages Supportedlanguagepairs Get](../../doc/controllers/languages.md#api-texttranslator-v1-0-languages-supportedlanguagepairs-get)


# Api Texttranslator V1 0 Languages Get

Gets the list of languages supported by Translator Studio

```php
function apiTexttranslatorV10LanguagesGet(string $authorization): array
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `authorization` | `string` | Header, Required | The auth token for the system |

## Response Type

[`TextTranslatorModelsTextTranslatorLanguage[]`](../../doc/models/text-translator-models-text-translator-language.md)

## Example Usage

```php
$authorization = 'authorization6';

$result = $languagesController->apiTexttranslatorV10LanguagesGet($authorization);
```


# Api Texttranslator V1 0 Languages Supportedlanguagepairs Get

Gets the list of language pairs are supported by the text translator for transalation.

```php
function apiTexttranslatorV10LanguagesSupportedlanguagepairsGet(string $authorization): array
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `authorization` | `string` | Header, Required | The auth token for the system |

## Response Type

[`TextTranslatorModelsLanguagePair[]`](../../doc/models/text-translator-models-language-pair.md)

## Example Usage

```php
$authorization = 'authorization6';

$result = $languagesController->apiTexttranslatorV10LanguagesSupportedlanguagepairsGet($authorization);
```

