# Models

```php
$modelsController = $client->getModelsController();
```

## Class Name

`ModelsController`

## Methods

* [Api Texttranslator V1 0 Models by Id Get](../../doc/controllers/models.md#api-texttranslator-v1-0-models-by-id-get)
* [Api Texttranslator V1 0 Models by Id Put](../../doc/controllers/models.md#api-texttranslator-v1-0-models-by-id-put)
* [Api Texttranslator V1 0 Models by Id Delete](../../doc/controllers/models.md#api-texttranslator-v1-0-models-by-id-delete)
* [Api Texttranslator V1 0 Models Post](../../doc/controllers/models.md#api-texttranslator-v1-0-models-post)
* [Api Texttranslator V1 0 Models by Id Train Post](../../doc/controllers/models.md#api-texttranslator-v1-0-models-by-id-train-post)
* [Api Texttranslator V1 0 Models by Id Deployment Post](../../doc/controllers/models.md#api-texttranslator-v1-0-models-by-id-deployment-post)
* [Api Texttranslator V1 0 Models by Id Tests Get](../../doc/controllers/models.md#api-texttranslator-v1-0-models-by-id-tests-get)
* [Api Texttranslator V1 0 Models by Id Undeployhubmodel Delete](../../doc/controllers/models.md#api-texttranslator-v1-0-models-by-id-undeployhubmodel-delete)


# Api Texttranslator V1 0 Models by Id Get

### REMARKS

To sort the returned results please use the standard OData $orderby syntax. Supported fields are:

- sourceSentences - Orders documents returned by number of source sentences.
- targetSentences - Orders documents returned by number of target sentences.
- alignedSentences - Orders documents returned by number of aligned sentences.
- usedSentences - Orders documents returned by number of used sentences.
  <br /><br />
  Only one orderBy field can be used at a time, else a 404  will be returned.
  <br />
  Example with SourceSentences : /api/texttranslator/v1/documents?$orderby=sourceSentences desc
  <br />
  Example with TargetSentences : /api/texttranslator/v1/documents?$orderby=targetSentences asc
  <br />
  Example with AlignedSentences: /api/texttranslator/v1/documents?$orderby=alignedSentences desc
  <br />
  Example with UsedSentences: /api/texttranslator/v1/documents?$orderby=usedSentences asc

```php
function apiTexttranslatorV10ModelsByIdGet(
    int $id,
    string $authorization,
    ?string $orderby = null
): TextTranslatorModelsTextTranslatorModelInfo
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `id` | `int` | Template, Required | The Id of the requested model. |
| `authorization` | `string` | Header, Required | Access token. |
| `orderby` | `?string` | Query, Optional | The OData $orderby parameter. |

## Response Type

[`TextTranslatorModelsTextTranslatorModelInfo`](../../doc/models/text-translator-models-text-translator-model-info.md)

## Example Usage

```php
$id = 112;
$authorization = 'authorization6';

$result = $modelsController->apiTexttranslatorV10ModelsByIdGet($id, $authorization);
```


# Api Texttranslator V1 0 Models by Id Put

### REMARKS

Documents can only be added or removed from the model if it is in a draft state.

```php
function apiTexttranslatorV10ModelsByIdPut(
    int $id,
    TextTranslatorModelsRequestTextTranslatorModelUpdateRequest $model,
    string $authorization
): TextTranslatorModelsResponseTextTranslatorModelUpdateResponse
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `id` | `int` | Template, Required | The id of the model to update. |
| `model` | [`TextTranslatorModelsRequestTextTranslatorModelUpdateRequest`](../../doc/models/text-translator-models-request-text-translator-model-update-request.md) | Body, Required | The updated model object. |
| `authorization` | `string` | Header, Required | - |

## Response Type

[`TextTranslatorModelsResponseTextTranslatorModelUpdateResponse`](../../doc/models/text-translator-models-response-text-translator-model-update-response.md)

## Example Usage

```php
$id = 112;
$model = new Models\TextTranslatorModelsRequestTextTranslatorModelUpdateRequest;
$authorization = 'authorization6';

$result = $modelsController->apiTexttranslatorV10ModelsByIdPut($id, $model, $authorization);
```


# Api Texttranslator V1 0 Models by Id Delete

Deletes the model.

```php
function apiTexttranslatorV10ModelsByIdDelete(int $id, string $authorization): void
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `id` | `int` | Template, Required | The Id of the model to delete. |
| `authorization` | `string` | Header, Required | Access token. |

## Response Type

`void`

## Example Usage

```php
$id = 112;
$authorization = 'authorization6';

$modelsController->apiTexttranslatorV10ModelsByIdDelete($id, $authorization);
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 404 | NotFound | `ApiException` |


# Api Texttranslator V1 0 Models Post

### REMARKS

The field 'isAutoTrain' defaults to true if not set. If it is set to false, it
creates the model in a draft state.

```php
function apiTexttranslatorV10ModelsPost(
    TextTranslatorModelsRequestTextTranslatorModelRequest $modelRequest,
    string $authorization
): void
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `modelRequest` | [`TextTranslatorModelsRequestTextTranslatorModelRequest`](../../doc/models/text-translator-models-request-text-translator-model-request.md) | Body, Required | The model to be added. |
| `authorization` | `string` | Header, Required | Access token. |

## Response Type

`void`

## Example Usage

```php
$modelRequest_name = 'name2';
$modelRequest_projectId = '000003cc-0000-0000-0000-000000000000';
$modelRequest = new Models\TextTranslatorModelsRequestTextTranslatorModelRequest(
    $modelRequest_name,
    $modelRequest_projectId
);
$authorization = 'authorization6';

$modelsController->apiTexttranslatorV10ModelsPost($modelRequest, $authorization);
```


# Api Texttranslator V1 0 Models by Id Train Post

Train a model.

```php
function apiTexttranslatorV10ModelsByIdTrainPost(int $id, string $authorization): void
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `id` | `int` | Template, Required | The Id of the model to train. |
| `authorization` | `string` | Header, Required | The authorization. |

## Response Type

`void`

## Example Usage

```php
$id = 112;
$authorization = 'authorization6';

$modelsController->apiTexttranslatorV10ModelsByIdTrainPost($id, $authorization);
```


# Api Texttranslator V1 0 Models by Id Deployment Post

Deploy or undeploy a model.

```php
function apiTexttranslatorV10ModelsByIdDeploymentPost(
    int $id,
    string $authorization,
    array $requestedRegionalDeployments
): void
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `id` | `int` | Template, Required | The id of the model to deploy or undeploy. |
| `authorization` | `string` | Header, Required | The authorization. |
| `requestedRegionalDeployments` | [`TextTranslatorModelsTextTranslatorModelRegionStatus[]`](../../doc/models/text-translator-models-text-translator-model-region-status.md) | Body, Required | An array of regions to be deployed/undeployed |

## Response Type

`void`

## Example Usage

```php
$id = 112;
$authorization = 'authorization6';
$requestedRegionalDeployments = [];

$requestedRegionalDeployments_0_region = 169;
$requestedRegionalDeployments_0_isDeployed = true;
$requestedRegionalDeployments[0] = new Models\TextTranslatorModelsTextTranslatorModelRegionStatus(
    $requestedRegionalDeployments_0_region,
    $requestedRegionalDeployments_0_isDeployed
);

$requestedRegionalDeployments_1_region = 170;
$requestedRegionalDeployments_1_isDeployed = false;
$requestedRegionalDeployments[1] = new Models\TextTranslatorModelsTextTranslatorModelRegionStatus(
    $requestedRegionalDeployments_1_region,
    $requestedRegionalDeployments_1_isDeployed
);


$modelsController->apiTexttranslatorV10ModelsByIdDeploymentPost($id, $authorization, $requestedRegionalDeployments);
```


# Api Texttranslator V1 0 Models by Id Tests Get

### REMARKS

Tests can be filtered using standard OData $filter syntax. Supported fields and operations:

- TestName - test name to filter by. Supported operations are 'eq' and 'substringof'.
- Status - Supported operations are 'eq'.
  <br /><br />
  Only basic 'and' operator is supported between different field filters. Also no nested conditions are supported.
  <br />
  Example: /api/texttranslator/v1/models/{id}/tests?$filter=substringof(testName, 'Test 1') and status eq 'Complete'

```php
function apiTexttranslatorV10ModelsByIdTestsGet(
    int $id,
    string $authorization,
    int $pageIndex,
    ?string $filter = null
): TextTranslatorModelsResponseTextTranslatorTestsResponse
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `id` | `int` | Template, Required | The Id of the model to which tests belong. |
| `authorization` | `string` | Header, Required | Access token |
| `pageIndex` | `int` | Query, Required | The page index. Default is 1. |
| `filter` | `?string` | Query, Optional | The OData $filter parameter. |

## Response Type

[`TextTranslatorModelsResponseTextTranslatorTestsResponse`](../../doc/models/text-translator-models-response-text-translator-tests-response.md)

## Example Usage

```php
$id = 112;
$authorization = 'authorization6';
$pageIndex = 166;

$result = $modelsController->apiTexttranslatorV10ModelsByIdTestsGet($id, $authorization, $pageIndex);
```


# Api Texttranslator V1 0 Models by Id Undeployhubmodel Delete

Accepts a request to undeploy a Hub model deployed to API V3.

```php
function apiTexttranslatorV10ModelsByIdUndeployhubmodelDelete(int $id, string $authorization): void
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `id` | `int` | Template, Required | Id of the corresponding model in Custom Translator with status Hub Deployed. |
| `authorization` | `string` | Header, Required | Access token |

## Response Type

`void`

## Example Usage

```php
$id = 112;
$authorization = 'authorization6';

$modelsController->apiTexttranslatorV10ModelsByIdUndeployhubmodelDelete($id, $authorization);
```

