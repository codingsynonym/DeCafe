# Tests

```php
$testsController = $client->getTestsController();
```

## Class Name

`TestsController`

## Methods

* [Api Texttranslator V1 0 Tests by Id Get](../../doc/controllers/tests.md#api-texttranslator-v1-0-tests-by-id-get)
* [Api Texttranslator V1 0 Tests by Id Export Post](../../doc/controllers/tests.md#api-texttranslator-v1-0-tests-by-id-export-post)
* [Api Texttranslator V1 0 Tests by Id Results Get](../../doc/controllers/tests.md#api-texttranslator-v1-0-tests-by-id-results-get)


# Api Texttranslator V1 0 Tests by Id Get

Gets details of a specific test.

```php
function apiTexttranslatorV10TestsByIdGet(
    int $id,
    string $authorization
): TextTranslatorModelsTextTranslatorTestInfo
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `id` | `int` | Template, Required | The test identifier. |
| `authorization` | `string` | Header, Required | Access token |

## Response Type

[`TextTranslatorModelsTextTranslatorTestInfo`](../../doc/models/text-translator-models-text-translator-test-info.md)

## Example Usage

```php
$id = 112;
$authorization = 'authorization6';

$result = $testsController->apiTexttranslatorV10TestsByIdGet($id, $authorization);
```


# Api Texttranslator V1 0 Tests by Id Export Post

Export the test resuls as a zip file.

```php
function apiTexttranslatorV10TestsByIdExportPost(
    int $id,
    string $authorization
): MicrosoftAspNetCoreMvcVirtualFileResult
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `id` | `int` | Template, Required | The test identifier. |
| `authorization` | `string` | Header, Required | access token |

## Response Type

[`MicrosoftAspNetCoreMvcVirtualFileResult`](../../doc/models/microsoft-asp-net-core-mvc-virtual-file-result.md)

## Example Usage

```php
$id = 112;
$authorization = 'authorization6';

$result = $testsController->apiTexttranslatorV10TestsByIdExportPost($id, $authorization);
```


# Api Texttranslator V1 0 Tests by Id Results Get

Gets aligned source, ref, general, and MT sentences.

```php
function apiTexttranslatorV10TestsByIdResultsGet(
    int $id,
    string $authorization
): TextTranslatorModelsResponseTextTranslatorTestEntriessResponse
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `id` | `int` | Template, Required | The test identifier. |
| `authorization` | `string` | Header, Required | access token |

## Response Type

[`TextTranslatorModelsResponseTextTranslatorTestEntriessResponse`](../../doc/models/text-translator-models-response-text-translator-test-entriess-response.md)

## Example Usage

```php
$id = 112;
$authorization = 'authorization6';

$result = $testsController->apiTexttranslatorV10TestsByIdResultsGet($id, $authorization);
```

