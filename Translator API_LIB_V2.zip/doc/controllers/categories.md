# Categories

```php
$categoriesController = $client->getCategoriesController();
```

## Class Name

`CategoriesController`


# Api Texttranslator V1 0 Categories Get

Gets the list of categories that can be assigned to the project.

```php
function apiTexttranslatorV10CategoriesGet(string $authorization): array
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `authorization` | `string` | Header, Required | - |

## Response Type

[`TextTranslatorModelsTextTranslatorCategory[]`](../../doc/models/text-translator-models-text-translator-category.md)

## Example Usage

```php
$authorization = 'authorization6';

$result = $categoriesController->apiTexttranslatorV10CategoriesGet($authorization);
```

