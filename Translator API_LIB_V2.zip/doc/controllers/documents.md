# Documents

```php
$documentsController = $client->getDocumentsController();
```

## Class Name

`DocumentsController`

## Methods

* [Api Texttranslator V1 0 Documents Get](../../doc/controllers/documents.md#api-texttranslator-v1-0-documents-get)
* [Api Texttranslator V1 0 Documents by Id Get](../../doc/controllers/documents.md#api-texttranslator-v1-0-documents-by-id-get)
* [Api Texttranslator V1 0 Documents by Id Delete](../../doc/controllers/documents.md#api-texttranslator-v1-0-documents-by-id-delete)
* [Api Texttranslator V1 0 Documents by Id Files Get](../../doc/controllers/documents.md#api-texttranslator-v1-0-documents-by-id-files-get)
* [Api Texttranslator V1 0 Documents by Id Files by Language Contents Get](../../doc/controllers/documents.md#api-texttranslator-v1-0-documents-by-id-files-by-language-contents-get)
* [Api Texttranslator V1 0 Documents by Id Files by File Id Content Get](../../doc/controllers/documents.md#api-texttranslator-v1-0-documents-by-id-files-by-file-id-content-get)
* [Api Texttranslator V1 0 Documents by Id Export Get](../../doc/controllers/documents.md#api-texttranslator-v1-0-documents-by-id-export-get)
* [Api Texttranslator V1 0 Documents Import Post](../../doc/controllers/documents.md#api-texttranslator-v1-0-documents-import-post)
* [Api Texttranslator V1 0 Documents Import Jobs by Job Id Get](../../doc/controllers/documents.md#api-texttranslator-v1-0-documents-import-jobs-by-job-id-get)
* [Api Texttranslator V1 0 Documents Import Jobs All Get](../../doc/controllers/documents.md#api-texttranslator-v1-0-documents-import-jobs-all-get)
* [Api Texttranslator V1 0 Documents Download Get](../../doc/controllers/documents.md#api-texttranslator-v1-0-documents-download-get)
* [Api Texttranslator V1 0 Documents Export Get](../../doc/controllers/documents.md#api-texttranslator-v1-0-documents-export-get)


# Api Texttranslator V1 0 Documents Get

### REMARKS

Documents can be filtered using standard OData $filter syntax. Supported fields and operations:

- Name - document name to filter by. Supported operations are 'eq' and 'substringof'.
- DocumentType - Document type filter. Supported operations are 'eq'. Can support multi-selection.
- LanguageCode - Language code filter. Supported operations are 'eq' . Can support multi-selection.
- IsParallel - Filter by the IsParallel boolean flag. Supported operations are 'eq'.
- ProjectLanguages - Filter for documents applicable to a project with the specified language pair.  Language pair should be specified with a '-&gt;' between the languages. Supported operations are 'eq'.
  <br /><br />
  Only basic 'and' operator is supported between different field filters. DocumentType allow for 'or' operation within the group. Also no nested conditions are supported.
  <br />
  Example: /api/texttranslator/v1/documents?$filter=substringof(Name, 'Document 1') and documentType eq 'training,testing' and languageCode eq 'de' and isParallel eq false
  <br />
  Example with ProjectLanguages - /api/texttranslator/v1/documents?$filter=projectLanguage eq 'en-&gt;de'
  <br /><br />
  To sort the returned results please use the standard OData $orderby syntax. Supported fields are:
- name- document name to order by.
- createdDate- document created date to order by.
- documentType- document type to order by - Training,Testing,Tuning, Phrase Dictionary and Sentence Dictionary in ascending or descending.
  <br /><br />
  Only one orderBy field can be used at a time, else a 404  will be returned.
  <br />
  Example with Name : /api/texttranslator/v1/documents?$orderby=name desc
  <br />
  Example with CreatedDate: /api/texttranslator/v1/documents?$orderby=createdDate asc
  <br />
  Example with DocumentType: /api/texttranslator/v1/documents?$orderby=documentType desc

```php
function apiTexttranslatorV10DocumentsGet(
    string $authorization,
    int $pageIndex,
    string $workspaceId,
    ?bool $includeAllDocumentsFields = null,
    ?int $prioritizeModel = null,
    ?string $filter = null,
    ?string $orderby = null,
    ?int $limit = null
): TextTranslatorModelsResponseTextTranslatorDocumentsResponse
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `authorization` | `string` | Header, Required | Access token |
| `pageIndex` | `int` | Query, Required | Index of the page. |
| `workspaceId` | `string` | Query, Required | Id of the workspace |
| `includeAllDocumentsFields` | `?bool` | Query, Optional | Whether or not to return the optional field 'AllDocuments'<br>that includes basic information about documents outside the pagination range. |
| `prioritizeModel` | `?int` | Query, Optional | When paginating results, ensures that documents that are part of this model<br>are listed before all other documents. If both prioritizeModel and orderby are provided, prioritzeModel will<br>be ignored. |
| `filter` | `?string` | Query, Optional | The OData $filter parameter. |
| `orderby` | `?string` | Query, Optional | The OData $orderby parameter. |
| `limit` | `?int` | Query, Optional | Limits the number of items per page. If not provided, defaults to 10. |

## Response Type

[`TextTranslatorModelsResponseTextTranslatorDocumentsResponse`](../../doc/models/text-translator-models-response-text-translator-documents-response.md)

## Example Usage

```php
$authorization = 'authorization6';
$pageIndex = 166;
$workspaceId = 'workspaceId6';

$result = $documentsController->apiTexttranslatorV10DocumentsGet($authorization, $pageIndex, $workspaceId);
```


# Api Texttranslator V1 0 Documents by Id Get

Gets the requested document

```php
function apiTexttranslatorV10DocumentsByIdGet(
    int $id,
    string $authorization
): TextTranslatorModelsTextTranslatorDocumentInfo
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `id` | `int` | Template, Required | The Id of the document for which details are requested |
| `authorization` | `string` | Header, Required | Access token |

## Response Type

[`TextTranslatorModelsTextTranslatorDocumentInfo`](../../doc/models/text-translator-models-text-translator-document-info.md)

## Example Usage

```php
$id = 112;
$authorization = 'authorization6';

$result = $documentsController->apiTexttranslatorV10DocumentsByIdGet($id, $authorization);
```


# Api Texttranslator V1 0 Documents by Id Delete

Delete the document

```php
function apiTexttranslatorV10DocumentsByIdDelete(int $id, string $authorization): void
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `id` | `int` | Template, Required | The id of the document to be deleted |
| `authorization` | `string` | Header, Required | Access token |

## Response Type

`void`

## Example Usage

```php
$id = 112;
$authorization = 'authorization6';

$documentsController->apiTexttranslatorV10DocumentsByIdDelete($id, $authorization);
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 404 | NotFound | `ApiException` |


# Api Texttranslator V1 0 Documents by Id Files Get

Gets the files for the document

```php
function apiTexttranslatorV10DocumentsByIdFilesGet(int $id, string $authorization): array
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `id` | `int` | Template, Required | The Id of the document for which the files information is requested |
| `authorization` | `string` | Header, Required | Access token |

## Response Type

[`TextTranslatorModelsTextTranslatorFileInfo[]`](../../doc/models/text-translator-models-text-translator-file-info.md)

## Example Usage

```php
$id = 112;
$authorization = 'authorization6';

$result = $documentsController->apiTexttranslatorV10DocumentsByIdFilesGet($id, $authorization);
```


# Api Texttranslator V1 0 Documents by Id Files by Language Contents Get

Gets the content of the requested file

```php
function apiTexttranslatorV10DocumentsByIdFilesByLanguageContentsGet(
    int $id,
    string $language,
    string $authorization,
    int $pageIndex
): TextTranslatorModelsResponseTextTranslatorFileContentResponse
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `id` | `int` | Template, Required | The document identifier. |
| `language` | `string` | Template, Required | The language. |
| `authorization` | `string` | Header, Required | The access token |
| `pageIndex` | `int` | Query, Required | Index of the page. |

## Response Type

[`TextTranslatorModelsResponseTextTranslatorFileContentResponse`](../../doc/models/text-translator-models-response-text-translator-file-content-response.md)

## Example Usage

```php
$id = 112;
$language = 'language2';
$authorization = 'authorization6';
$pageIndex = 166;

$result = $documentsController->apiTexttranslatorV10DocumentsByIdFilesByLanguageContentsGet($id, $language, $authorization, $pageIndex);
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 404 | NotFound | `ApiException` |


# Api Texttranslator V1 0 Documents by Id Files by File Id Content Get

Gets the content of the requested file

```php
function apiTexttranslatorV10DocumentsByIdFilesByFileIdContentGet(
    int $id,
    int $fileId,
    string $authorization,
    int $pageIndex,
    int $limit
): TextTranslatorModelsResponseTextTranslatorFileContentResponse
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `id` | `int` | Template, Required | The document identifier. |
| `fileId` | `int` | Template, Required | The file id. |
| `authorization` | `string` | Header, Required | The access token |
| `pageIndex` | `int` | Query, Required | Index of the page |
| `limit` | `int` | Query, Required | Number of items per page |

## Response Type

[`TextTranslatorModelsResponseTextTranslatorFileContentResponse`](../../doc/models/text-translator-models-response-text-translator-file-content-response.md)

## Example Usage

```php
$id = 112;
$fileId = 12;
$authorization = 'authorization6';
$pageIndex = 166;
$limit = 172;

$result = $documentsController->apiTexttranslatorV10DocumentsByIdFilesByFileIdContentGet($id, $fileId, $authorization, $pageIndex, $limit);
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 404 | NotFound | `ApiException` |


# Api Texttranslator V1 0 Documents by Id Export Get

Downloads a zip containing the file(s) belonging to this document

```php
function apiTexttranslatorV10DocumentsByIdExportGet(
    int $id,
    string $authorization
): MicrosoftAspNetCoreMvcVirtualFileResult
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `id` | `int` | Template, Required | The Id of the document for which files are requested |
| `authorization` | `string` | Header, Required | Access token |

## Response Type

[`MicrosoftAspNetCoreMvcVirtualFileResult`](../../doc/models/microsoft-asp-net-core-mvc-virtual-file-result.md)

## Example Usage

```php
$id = 112;
$authorization = 'authorization6';

$result = $documentsController->apiTexttranslatorV10DocumentsByIdExportGet($id, $authorization);
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 404 | NotFound | `ApiException` |


# Api Texttranslator V1 0 Documents Import Post

Upload files for processing. Documents are created asynchronously. Upload status can be checked using the returned job id

```php
function apiTexttranslatorV10DocumentsImportPost(
    array $files,
    string $documentDetails,
    string $authorization,
    string $workspaceId
): TextTranslatorApiModelsResponseTestTranslatorImportFilesResponse
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `files` | `array[]` | Form, Required | Gets or sets the uploaded Files |
| `documentDetails` | `string` | Form, Required | Gets or sets the document details with their files that are being uploaded.<br>multipart/form-data type does not serialize/de-serialize to anything other than file or string<br>This will be parsed in the controller to type IEnumerable[ImportDocumentRequestDetails] |
| `authorization` | `string` | Header, Required | Access token |
| `workspaceId` | `string` | Query, Required | Workspace id |

## Response Type

[`TextTranslatorApiModelsResponseTestTranslatorImportFilesResponse`](../../doc/models/text-translator-api-models-response-test-translator-import-files-response.md)

## Example Usage

```php
$files = [MicrosoftCustomTranslatorAPIPreview10Lib\ApiHelper::deserialize('{"key1":"val1","key2":"val2"}')];
$documentDetails = 'DocumentDetails8';
$authorization = 'authorization6';
$workspaceId = 'workspaceId6';

$result = $documentsController->apiTexttranslatorV10DocumentsImportPost($files, $documentDetails, $authorization, $workspaceId);
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 404 | NotFound | `ApiException` |


# Api Texttranslator V1 0 Documents Import Jobs by Job Id Get

### REMARKS

Document import status can be filtered using standard OData $filter syntax. Supported fields and operations:

- FileName - Filters by document name. Supported operations are 'eq' and 'substringof'.
- LanguageCode - Filters by language code. Supported operation is 'eq'.
- Status - Filters by the import status. Supported operation is 'eq', 'lt' (less than), 'gt' (greater than).
  <br /><br />
  Only basic 'and' operator is supported between different field filters, and nested conditions are not supported.
  <br /><br />
  Example: /api/texttranslator/v1/documents/import/jobs/{jobId}?$filter=substringof(FileName, 'Document 1') and languageCode eq 'de' and status lt '254'
  <br />

```php
function apiTexttranslatorV10DocumentsImportJobsByJobIdGet(
    string $authorization,
    string $jobId,
    int $pageIndex,
    int $limit,
    ?string $filter = null
): TextTranslatorModelsResponseTextTranslatorImportJobStatusResponse
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `authorization` | `string` | Header, Required | Access token |
| `jobId` | `string` | Template, Required | The job identifier |
| `pageIndex` | `int` | Query, Required | Index of the page. If not provided, defaults to returning the first page. |
| `limit` | `int` | Query, Required | Limits the number of items per page. If not provided, defaults to 10. |
| `filter` | `?string` | Query, Optional | The OData $filter parameter |

## Response Type

[`TextTranslatorModelsResponseTextTranslatorImportJobStatusResponse`](../../doc/models/text-translator-models-response-text-translator-import-job-status-response.md)

## Example Usage

```php
$authorization = 'authorization6';
$jobId = '000011b2-0000-0000-0000-000000000000';
$pageIndex = 166;
$limit = 172;

$result = $documentsController->apiTexttranslatorV10DocumentsImportJobsByJobIdGet($authorization, $jobId, $pageIndex, $limit);
```


# Api Texttranslator V1 0 Documents Import Jobs All Get

### REMARKS

Document import status can be filtered using standard OData $filter syntax. Supported fields and operations:

- Name - Filters by document name. Supported operations are 'eq' and 'substringof'.
- LanguageCode - Filters by language code. Supported operation is 'eq'.
- Status - Filters by the import status. Supported operations are 'eq', 'lt' (less than), 'gt' (greater than).
- UploadDateStart - Supported operation is 'ge' (greater than or equal to)
- UploadDateEnd - Supported operation is 'le' (less than or equal to)
  <br /><br />
  Only basic 'and' operator is supported between different field filters, and nested conditions are not supported.
  <br /><br />
  Example: /api/texttranslator/v1/documents/import/jobs/all?$filter=substringof(Name, 'Document 1') and languagePair eq 'de,en' and status lt '254'
  <br />

```php
function apiTexttranslatorV10DocumentsImportJobsAllGet(
    string $authorization,
    string $workspaceId,
    int $pageIndex,
    int $limit,
    ?string $filter = null
): TextTranslatorModelsResponseTextTranslatorImportAllJobsStatusResponse
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `authorization` | `string` | Header, Required | Access token |
| `workspaceId` | `string` | Query, Required | Id for the workspace to fetch the jobs from. |
| `pageIndex` | `int` | Query, Required | Index of the page. If not provided, defaults to returning the first page. |
| `limit` | `int` | Query, Required | Limits the number of items per page. If not provided, defaults to 10. |
| `filter` | `?string` | Query, Optional | The OData $filter parameter |

## Response Type

[`TextTranslatorModelsResponseTextTranslatorImportAllJobsStatusResponse`](../../doc/models/text-translator-models-response-text-translator-import-all-jobs-status-response.md)

## Example Usage

```php
$authorization = 'authorization6';
$workspaceId = 'workspaceId6';
$pageIndex = 166;
$limit = 172;

$result = $documentsController->apiTexttranslatorV10DocumentsImportJobsAllGet($authorization, $workspaceId, $pageIndex, $limit);
```


# Api Texttranslator V1 0 Documents Download Get

Downloads a zip containing Documents file(s) selected from project or all documents for model

```php
function apiTexttranslatorV10DocumentsDownloadGet(
    string $authorization
): MicrosoftAspNetCoreMvcVirtualFileResult
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `authorization` | `string` | Header, Required | Access token |

## Response Type

[`MicrosoftAspNetCoreMvcVirtualFileResult`](../../doc/models/microsoft-asp-net-core-mvc-virtual-file-result.md)

## Example Usage

```php
$authorization = 'authorization6';

$result = $documentsController->apiTexttranslatorV10DocumentsDownloadGet($authorization);
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 404 | NotFound | `ApiException` |


# Api Texttranslator V1 0 Documents Export Get

Downloads a zip containing Documents file(s) selected from project or all documents for model (does not require method override on header)

```php
function apiTexttranslatorV10DocumentsExportGet(
    array $documentIds,
    string $authorization
): MicrosoftAspNetCoreMvcVirtualFileResult
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `documentIds` | `int[]` | Query, Required | The Ids of the document for which files are requested |
| `authorization` | `string` | Header, Required | Access token |

## Response Type

[`MicrosoftAspNetCoreMvcVirtualFileResult`](../../doc/models/microsoft-asp-net-core-mvc-virtual-file-result.md)

## Example Usage

```php
$documentIds = [164, 165, 166];
$authorization = 'authorization6';

$result = $documentsController->apiTexttranslatorV10DocumentsExportGet($documentIds, $authorization);
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 404 | NotFound | `ApiException` |

