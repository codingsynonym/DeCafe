# Regions

```php
$regionsController = $client->getRegionsController();
```

## Class Name

`RegionsController`


# Api Texttranslator V1 0 Regions Get

Gets the list of regions.

```php
function apiTexttranslatorV10RegionsGet(string $authorization): array
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `authorization` | `string` | Header, Required | Access token |

## Response Type

[`TextTranslatorDALRegion[]`](../../doc/models/text-translator-dal-region.md)

## Example Usage

```php
$authorization = 'authorization6';

$result = $regionsController->apiTexttranslatorV10RegionsGet($authorization);
```

