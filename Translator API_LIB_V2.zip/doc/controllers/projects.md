# Projects

```php
$projectsController = $client->getProjectsController();
```

## Class Name

`ProjectsController`

## Methods

* [Api Texttranslator V1 0 Projects Get](../../doc/controllers/projects.md#api-texttranslator-v1-0-projects-get)
* [Api Texttranslator V1 0 Projects Post](../../doc/controllers/projects.md#api-texttranslator-v1-0-projects-post)
* [Api Texttranslator V1 0 Projects by Id Get](../../doc/controllers/projects.md#api-texttranslator-v1-0-projects-by-id-get)
* [Api Texttranslator V1 0 Projects by Id Put](../../doc/controllers/projects.md#api-texttranslator-v1-0-projects-by-id-put)
* [Api Texttranslator V1 0 Projects by Id Delete](../../doc/controllers/projects.md#api-texttranslator-v1-0-projects-by-id-delete)
* [Api Texttranslator V1 0 Projects by Id Models Get](../../doc/controllers/projects.md#api-texttranslator-v1-0-projects-by-id-models-get)


# Api Texttranslator V1 0 Projects Get

### REMARKS

Projects can be filtered using standard OData $filter syntax. Supported fields and operations:

- Name- project name to filter by. Supported operations are 'eq' and 'substringof'.
- SourceLanguage- Supported operations are 'eq'.
- TargetLanguage- Supported operations are 'eq'.
- Category- Supported operations are 'eq'.
  <br /><br />
  Only basic 'and' operator is supported between different field filters. Source language, target language, and category
  allow for 'or' operator within the group.
  <br />
  Example: /api/texttranslator/v1/projects?$filter=substringof(name, 'Project 1') and status eq 'Deployed' and targetLanguage eq 'de,en'
  <br /><br /><br />
  To sort the returned results please use the standard OData $orderby syntax. Supported fields are:
- name- project name to order by.
- createdDate- project created date to order by.
  <br /><br />
  Only one orderBy field can be used at a time, else a 404  will be returned.
  <br />
  Example with Name : /api/texttranslator/v1/projects?$orderby=name desc
  <br />
  Example with CreatedDate : /api/texttranslator/v1/projects?$orderby=createdDate asc

```php
function apiTexttranslatorV10ProjectsGet(
    string $authorization,
    string $workspaceId,
    ?string $filter = null,
    ?string $orderby = null,
    ?int $pageIndex = null
): TextTranslatorModelsResponseTextTranslatorProjectsResponse
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `authorization` | `string` | Header, Required | Access token |
| `workspaceId` | `string` | Query, Required | The id of the workspace. |
| `filter` | `?string` | Query, Optional | The OData $filter parameter. |
| `orderby` | `?string` | Query, Optional | The OData $orderby parameter. |
| `pageIndex` | `?int` | Query, Optional | The page index. Optional, if not provided returns all results. |

## Response Type

[`TextTranslatorModelsResponseTextTranslatorProjectsResponse`](../../doc/models/text-translator-models-response-text-translator-projects-response.md)

## Example Usage

```php
$authorization = 'authorization6';
$workspaceId = 'workspaceId6';

$result = $projectsController->apiTexttranslatorV10ProjectsGet($authorization, $workspaceId);
```


# Api Texttranslator V1 0 Projects Post

Create a project.

```php
function apiTexttranslatorV10ProjectsPost(
    TextTranslatorModelsRequestTextTranslatorProjectRequest $project,
    string $authorization,
    string $workspaceId
): void
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `project` | [`TextTranslatorModelsRequestTextTranslatorProjectRequest`](../../doc/models/text-translator-models-request-text-translator-project-request.md) | Body, Required | The project to create |
| `authorization` | `string` | Header, Required | Access token |
| `workspaceId` | `string` | Query, Required | Workspace id |

## Response Type

`void`

## Example Usage

```php
$project_languagePairId = 120;
$project_categoryId = 124;
$project = new Models\TextTranslatorModelsRequestTextTranslatorProjectRequest(
    $project_languagePairId,
    $project_categoryId
);
$authorization = 'authorization6';
$workspaceId = 'workspaceId6';

$projectsController->apiTexttranslatorV10ProjectsPost($project, $authorization, $workspaceId);
```


# Api Texttranslator V1 0 Projects by Id Get

Gets the project specified by Id.

```php
function apiTexttranslatorV10ProjectsByIdGet(
    string $id,
    string $authorization
): TextTranslatorModelsTextTranslatorProjectInfo
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `id` | `string` | Template, Required | The Id for the project for which details are requested. |
| `authorization` | `string` | Header, Required | Access token |

## Response Type

[`TextTranslatorModelsTextTranslatorProjectInfo`](../../doc/models/text-translator-models-text-translator-project-info.md)

## Example Usage

```php
$id = '00001770-0000-0000-0000-000000000000';
$authorization = 'authorization6';

$result = $projectsController->apiTexttranslatorV10ProjectsByIdGet($id, $authorization);
```


# Api Texttranslator V1 0 Projects by Id Put

Updates the project.

```php
function apiTexttranslatorV10ProjectsByIdPut(
    string $id,
    TextTranslatorModelsRequestTextTranslatorProjectUpdateRequest $project,
    string $authorization
): TextTranslatorModelsTextTranslatorProjectInfo
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `id` | `string` | Template, Required | The id of the project to update. |
| `project` | [`TextTranslatorModelsRequestTextTranslatorProjectUpdateRequest`](../../doc/models/text-translator-models-request-text-translator-project-update-request.md) | Body, Required | The project to update |
| `authorization` | `string` | Header, Required | Access token |

## Response Type

[`TextTranslatorModelsTextTranslatorProjectInfo`](../../doc/models/text-translator-models-text-translator-project-info.md)

## Example Usage

```php
$id = '00001770-0000-0000-0000-000000000000';
$project = new Models\TextTranslatorModelsRequestTextTranslatorProjectUpdateRequest;
$authorization = 'authorization6';

$result = $projectsController->apiTexttranslatorV10ProjectsByIdPut($id, $project, $authorization);
```


# Api Texttranslator V1 0 Projects by Id Delete

Delete the current project

```php
function apiTexttranslatorV10ProjectsByIdDelete(string $id, string $authorization): void
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `id` | `string` | Template, Required | Id of the project |
| `authorization` | `string` | Header, Required | access token |

## Response Type

`void`

## Example Usage

```php
$id = '00001770-0000-0000-0000-000000000000';
$authorization = 'authorization6';

$projectsController->apiTexttranslatorV10ProjectsByIdDelete($id, $authorization);
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 404 | NotFound | `ApiException` |


# Api Texttranslator V1 0 Projects by Id Models Get

### REMARKS

Models can be filtered using standard OData $filter syntax. Supported fields and operations:

- ModelName - Model name to filter by. Supported operations are 'eq' and 'substringof'.
- DocumentType - Returns the model if it uses the given document type. Supported operations are 'eq'.
- Status - Current status of the model (for example: 'deployed'). Supported operation is 'eq' and 'or' operator within the group.
  <br /><br />
  Only basic 'and' operator is supported between different field filters. Also no nested conditions are supported.
  <br />
  Example: /api/texttranslator/v1/projects/{id}/models?$filter=substringof(modelName, 'Model 1') and documentType eq 'training' and status eq 'deployed,draft'
  <br /><br /><br />
  To sort the returned results please use the standard OData $orderby syntax. If an $orderby parameter is not provided, default sort order
  returns any published models first, followed by most recently modified. Supported fields are:
- name - Model name to order by
- modifiedDate - Model modified date to order by
  <br /><br />
  Only one orderBy field can be used at a time, else a 404  will be returned.
  <br />
  Example with Name : /api/texttranslator/v1/documents?$orderby=name desc
  <br />
  Example with ModifiedDate: /api/texttranslator/v1/documents?$orderby=modifiedDate asc

```php
function apiTexttranslatorV10ProjectsByIdModelsGet(
    string $id,
    string $authorization,
    ?string $filter = null,
    ?string $orderby = null,
    ?int $pageIndex = null
): TextTranslatorModelsResponseTextTranslatorModelsResponse
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `id` | `string` | Template, Required | - |
| `authorization` | `string` | Header, Required | - |
| `filter` | `?string` | Query, Optional | The OData $filter parameter. |
| `orderby` | `?string` | Query, Optional | The OData $orderby parameter. |
| `pageIndex` | `?int` | Query, Optional | The page index. Optional, if not provided returns all results. |

## Response Type

[`TextTranslatorModelsResponseTextTranslatorModelsResponse`](../../doc/models/text-translator-models-response-text-translator-models-response.md)

## Example Usage

```php
$id = '00001770-0000-0000-0000-000000000000';
$authorization = 'authorization6';

$result = $projectsController->apiTexttranslatorV10ProjectsByIdModelsGet($id, $authorization);
```

