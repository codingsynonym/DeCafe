# Decoders

Examine available decoders

```php
$decodersController = $client->getDecodersController();
```

## Class Name

`DecodersController`


# List Available Decoders

Get a list of available decoders to choose from, each decoder is described with a title and a simple description.

```php
function listAvailableDecoders(?string $apiVersion = null): ListDecoders
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `apiVersion` | `?string` | Header, Optional | API Version. If no version is provided it defaults to latest version. |

## Response Type

[`ListDecoders`](../../doc/models/list-decoders.md)

## Example Usage

```php
$result = $decodersController->listAvailableDecoders();
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 400 | Bad request | [`ErrorException`](../../doc/models/error-exception.md) |
| 401 | Unauthorized | [`ErrorException`](../../doc/models/error-exception.md) |
| 403 | forbidden | [`ErrorException`](../../doc/models/error-exception.md) |
| 404 | not found | [`ErrorException`](../../doc/models/error-exception.md) |
| 429 | too many requests | [`ErrorException`](../../doc/models/error-exception.md) |
| 500 | server error | [`ErrorException`](../../doc/models/error-exception.md) |
| 503 | service unavailable | [`ErrorException`](../../doc/models/error-exception.md) |

