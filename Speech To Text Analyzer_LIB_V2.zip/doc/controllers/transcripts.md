# Transcripts

Create and view transcripts

```php
$transcriptsController = $client->getTranscriptsController();
```

## Class Name

`TranscriptsController`

## Methods

* [Create New Transcript](../../doc/controllers/transcripts.md#create-new-transcript)
* [Get a List of Transcripts Uploaded by the Client](../../doc/controllers/transcripts.md#get-a-list-of-transcripts-uploaded-by-the-client)
* [Retreive the Json Transcript of a Finished Transcription Job](../../doc/controllers/transcripts.md#retreive-the-json-transcript-of-a-finished-transcription-job)
* [Check Transcription Process Status](../../doc/controllers/transcripts.md#check-transcription-process-status)


# Create New Transcript

To create a new transcript with analyzer metadata ,you have to follow these steps:

+ Accepted formats:
  
  - .wav
  - .mp3
  - .opus

+ Preferred requirements:
  
  - Bitrate: 256Kbit/s
  - Sample rate: 16KHz
  - Uncompressed files preferred

+ Minimum requirements:
  
  - Bitrate: 32Kbit/s
  - Sample rate: 8KHz
  - Uncompressed files preferred

+ Max audio file size: 10MB + Provide the appropriate decoder id (retrieved by GET /decoders), depending on the language spoken in the audio file.
  
  **Note :** For file size greater than 10MB use the audio link atribute.

+ An optional callback URL can be provided where a notification will be send when the transcription process is finished.

+ An optional JSON object can be provided, which is passed through as is to the callback url (if given) when transcript is done.

```php
function createNewTranscript(
    FileWrapper $audio,
    ?string $apiVersion = null,
    ?string $progressNotifications = null,
    ?string $callbackurl = null,
    ?array $data = null,
    ?string $audioLink = null,
    ?int $numSpeakers = null,
    ?string $decoder = null
): CreatedTranscript
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `audio` | `FileWrapper` | Form, Required | The audio file to be transcribed. The file must honor the following conditions; File format is .wav, .mp3 or .opus File is mono channel, bitrate; 256k, sampling rate; 16khz, encoding; pcm_s16le.' If, file size is more than 10MB use the '''audioLink'''. |
| `apiVersion` | `?string` | Header, Optional | API Version. If no version is provided it defaults to latest version. |
| `progressNotifications` | `?string` | Form, Optional | A url where a notification an be sent when job progress changes |
| `callbackurl` | `?string` | Form, Optional | A post endpoint where a notification is sent when transcription is done. |
| `data` | `?array` | Form, Optional | A json object which is passed through as is to the callback url (if given) when transcript is done. |
| `audioLink` | `?string` | Form, Optional | A URI that points to a hosted audio file. can be used as an alternative to uploading audio file directly. |
| `numSpeakers` | `?int` | Form, Optional | number of speakers in audio file. (For multi-channel, a single speaker per channel is assumed and num_speakers parameter is ignored.) |
| `decoder` | `?string` | Form, Optional | String id of one of the decoders retrieved by GET /decoders. If missing, standard dutch decoder is used |

## Response Type

[`CreatedTranscript`](../../doc/models/created-transcript.md)

## Example Usage

```php
$audio = 'dummy_file';
$decoder = '5b16b7c7fb6fc02bcb8ec28e';

$result = $transcriptsController->createNewTranscript($audio, null, null, null, null, null, null, $decoder);
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 400 | Bad request | [`ErrorException`](../../doc/models/error-exception.md) |
| 401 | Unauthorized | [`ErrorException`](../../doc/models/error-exception.md) |
| 403 | forbidden | [`ErrorException`](../../doc/models/error-exception.md) |
| 404 | not found | [`ErrorException`](../../doc/models/error-exception.md) |
| 412 | uploaded file has size 0 | [`ErrorException`](../../doc/models/error-exception.md) |
| 429 | too many requests | [`ErrorException`](../../doc/models/error-exception.md) |
| 500 | server error | [`ErrorException`](../../doc/models/error-exception.md) |
| 503 | service unavailable | [`ErrorException`](../../doc/models/error-exception.md) |


# Get a List of Transcripts Uploaded by the Client

Gets a list of transcriptions.
This feature is only available in production

```php
function getAListOfTranscriptsUploadedByTheClient(?string $apiVersion = null): array
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `apiVersion` | `?string` | Header, Optional | API Version. If no version is provided it defaults to latest version. |

## Response Type

[`Transcript[]`](../../doc/models/transcript.md)

## Example Usage

```php
$result = $transcriptsController->getAListOfTranscriptsUploadedByTheClient();
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 400 | Bad request | [`ErrorException`](../../doc/models/error-exception.md) |
| 401 | Unauthorized | [`ErrorException`](../../doc/models/error-exception.md) |
| 403 | forbidden | [`ErrorException`](../../doc/models/error-exception.md) |
| 428 | precondition required | [`ErrorException`](../../doc/models/error-exception.md) |
| 429 | too many requests | [`ErrorException`](../../doc/models/error-exception.md) |
| 500 | server error | [`ErrorException`](../../doc/models/error-exception.md) |
| 503 | service unavailable | [`ErrorException`](../../doc/models/error-exception.md) |


# Retreive the Json Transcript of a Finished Transcription Job

Produce json file with the transcript of a previously uploaded audio file.

### Note:

If Process status from `GET /status/{transcriptId}` call shows `"status": "PROCESSING"`. This API will return `412 Precondition Failed`. It will return a valid response only if `"status": "COMPLETED"`.

```php
function retreiveTheJsonTranscriptOfAFinishedTranscriptionJob(
    string $transcriptId,
    ?string $apiVersion = null
): AnalysisTranscriptsResponse
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `transcriptId` | `string` | Template, Required | Id of transcript to show |
| `apiVersion` | `?string` | Header, Optional | API Version. If no version is provided it defaults to latest version. |

## Response Type

[`AnalysisTranscriptsResponse`](../../doc/models/analysis-transcripts-response.md)

## Example Usage

```php
$transcriptId = 'transcriptId8';

$result = $transcriptsController->retreiveTheJsonTranscriptOfAFinishedTranscriptionJob($transcriptId);
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 400 | Bad request | [`ErrorException`](../../doc/models/error-exception.md) |
| 401 | Unauthorized | [`ErrorException`](../../doc/models/error-exception.md) |
| 403 | forbidden | [`ErrorException`](../../doc/models/error-exception.md) |
| 404 | not found | [`ErrorException`](../../doc/models/error-exception.md) |
| 412 | uploaded file has size 0 | [`ErrorException`](../../doc/models/error-exception.md) |
| 429 | too many requests | [`ErrorException`](../../doc/models/error-exception.md) |
| 500 | server error | [`ErrorException`](../../doc/models/error-exception.md) |
| 503 | service unavailable | [`ErrorException`](../../doc/models/error-exception.md) |


# Check Transcription Process Status

Check the status of the transcription process for a previously uploaded audio file

```php
function checkTranscriptionProcessStatus(
    string $transcriptId,
    ?string $apiVersion = null
): TranscriptsStatusResponse
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `transcriptId` | `string` | Template, Required | Id of transcript to show |
| `apiVersion` | `?string` | Header, Optional | API Version. If no version is provided it defaults to latest version. |

## Response Type

[`TranscriptsStatusResponse`](../../doc/models/transcripts-status-response.md)

## Example Usage

```php
$transcriptId = 'transcriptId8';

$result = $transcriptsController->checkTranscriptionProcessStatus($transcriptId);
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 400 | Bad request | [`ErrorException`](../../doc/models/error-exception.md) |
| 401 | Unauthorized | [`ErrorException`](../../doc/models/error-exception.md) |
| 403 | forbidden | [`ErrorException`](../../doc/models/error-exception.md) |
| 404 | not found | [`ErrorException`](../../doc/models/error-exception.md) |
| 429 | too many requests | [`ErrorException`](../../doc/models/error-exception.md) |
| 500 | server error | [`ErrorException`](../../doc/models/error-exception.md) |
| 503 | service unavailable | [`ErrorException`](../../doc/models/error-exception.md) |

