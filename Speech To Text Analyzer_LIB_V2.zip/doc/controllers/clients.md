# Clients

Client Onboarding

```php
$clientsController = $client->getClientsController();
```

## Class Name

`ClientsController`


# Get Client Information

Get client information

```php
function getClientInformation(): ClientsMe
```

## Response Type

[`ClientsMe`](../../doc/models/clients-me.md)

## Example Usage

```php
$result = $clientsController->getClientInformation();
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 400 | Bad request | [`ErrorException`](../../doc/models/error-exception.md) |
| 401 | Unauthorized | [`ErrorException`](../../doc/models/error-exception.md) |
| 403 | forbidden | [`ErrorException`](../../doc/models/error-exception.md) |
| 404 | not found | [`ErrorException`](../../doc/models/error-exception.md) |
| 429 | too many requests | [`ErrorException`](../../doc/models/error-exception.md) |
| 500 | server error | [`ErrorException`](../../doc/models/error-exception.md) |
| 502 | gateway_error | [`ErrorException`](../../doc/models/error-exception.md) |
| 503 | service unavailable | [`ErrorException`](../../doc/models/error-exception.md) |

