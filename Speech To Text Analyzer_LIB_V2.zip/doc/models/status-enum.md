
# Status Enum

## Enumeration

`StatusEnum`

## Fields

| Name |
|  --- |
| `PENDING` |
| `PROCESSING` |
| `DONE` |
| `FAILED` |

