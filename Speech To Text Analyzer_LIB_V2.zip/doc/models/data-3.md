
# Data 3

## Structure

`Data3`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `transcriptId` | `?string` | Optional | The newly created transcript Id. | getTranscriptId(): ?string | setTranscriptId(?string transcriptId): void |
| `status` | [`?string (Status1Enum)`](../../doc/models/status-1-enum.md) | Optional | DONE \| FAILED | getStatus(): ?string | setStatus(?string status): void |

## Example (as JSON)

```json
{
  "transcriptId": null,
  "status": null
}
```

