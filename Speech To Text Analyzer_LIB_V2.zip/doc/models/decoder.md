
# Decoder

## Structure

`Decoder`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `id` | `?string` | Optional | - | getId(): ?string | setId(?string id): void |
| `title` | `?string` | Optional | - | getTitle(): ?string | setTitle(?string title): void |

## Example (as JSON)

```json
{
  "_id": null,
  "title": null
}
```

