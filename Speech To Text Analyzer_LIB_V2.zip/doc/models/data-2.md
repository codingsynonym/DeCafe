
# Data 2

## Structure

`Data2`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `transcriptId` | `?string` | Optional | The unique ID of the transcript that is created from your audio file. you can use this ID to retreive information on the transcription process of your file, as well as the transcript itself when done. | getTranscriptId(): ?string | setTranscriptId(?string transcriptId): void |

## Example (as JSON)

```json
{
  "transcript_id": null
}
```

