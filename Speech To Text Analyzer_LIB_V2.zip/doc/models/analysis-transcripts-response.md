
# Analysis Transcripts Response

## Structure

`AnalysisTranscriptsResponse`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `data` | `?array` | Optional | - | getData(): ?array | setData(?array data): void |

## Example (as JSON)

```json
{
  "data": null
}
```

