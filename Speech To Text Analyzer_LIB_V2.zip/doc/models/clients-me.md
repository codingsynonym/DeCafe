
# Clients Me

## Structure

`ClientsMe`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `data` | [`?Data`](../../doc/models/data.md) | Optional | - | getData(): ?Data | setData(?Data data): void |

## Example (as JSON)

```json
{
  "data": null
}
```

