
# Transcript

information per transcript

## Structure

`Transcript`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `id` | `?string` | Optional | - | getId(): ?string | setId(?string id): void |
| `duration` | `?float` | Optional | - | getDuration(): ?float | setDuration(?float duration): void |
| `numSpeakers` | `?int` | Optional | - | getNumSpeakers(): ?int | setNumSpeakers(?int numSpeakers): void |
| `decoder` | [`?Decoder`](../../doc/models/decoder.md) | Optional | - | getDecoder(): ?Decoder | setDecoder(?Decoder decoder): void |
| `callbackurl` | `?string` | Optional | - | getCallbackurl(): ?string | setCallbackurl(?string callbackurl): void |
| `progressNotifications` | `?string` | Optional | - | getProgressNotifications(): ?string | setProgressNotifications(?string progressNotifications): void |
| `data` | `?string` | Optional | - | getData(): ?string | setData(?string data): void |
| `originalName` | `?string` | Optional | - | getOriginalName(): ?string | setOriginalName(?string originalName): void |
| `status` | [`?string (StatusEnum)`](../../doc/models/status-enum.md) | Optional | - | getStatus(): ?string | setStatus(?string status): void |
| `createdAt` | `?string` | Optional | - | getCreatedAt(): ?string | setCreatedAt(?string createdAt): void |

## Example (as JSON)

```json
{
  "_id": null,
  "duration": null,
  "numSpeakers": null,
  "decoder": null,
  "callbackurl": null,
  "progressNotifications": null,
  "data": null,
  "originalName": null,
  "status": null,
  "created_at": null
}
```

