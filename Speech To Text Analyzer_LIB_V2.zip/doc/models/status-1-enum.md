
# Status 1 Enum

DONE | FAILED

## Enumeration

`Status1Enum`

## Fields

| Name |
|  --- |
| `DONE` |
| `FAILED` |

