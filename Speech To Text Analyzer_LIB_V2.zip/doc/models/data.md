
# Data

## Structure

`Data`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `id` | `?string` | Optional | id of the client. | getId(): ?string | setId(?string id): void |
| `email` | `?string` | Optional | email of the client | getEmail(): ?string | setEmail(?string email): void |
| `name` | `?string` | Optional | The name of the client | getName(): ?string | setName(?string name): void |
| `persistData` | `?bool` | Optional | Should client's audio data be persisted. | getPersistData(): ?bool | setPersistData(?bool persistData): void |

## Example (as JSON)

```json
{
  "id": null,
  "email": null,
  "name": null,
  "persistData": null
}
```

