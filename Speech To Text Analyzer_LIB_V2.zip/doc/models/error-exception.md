
# Error Exception

## Structure

`ErrorException`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `transactionId` | `?string` | Optional | transaction id of the the request | getTransactionId(): ?string | setTransactionId(?string transactionId): void |
| `status` | `?string` | Optional | Status | getStatus(): ?string | setStatus(?string status): void |
| `name` | `?string` | Optional | Error name | getName(): ?string | setName(?string name): void |
| `message` | `?string` | Optional | Error message | getMessage(): ?string | setMessage(?string message): void |
| `info` | `?string` | Optional | Additional information about error | getInfo(): ?string | setInfo(?string info): void |

## Example (as JSON)

```json
{
  "transactionId": null,
  "status": null,
  "name": null,
  "message": null,
  "info": null
}
```

