
# Created Transcript

## Structure

`CreatedTranscript`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `data` | [`?Data2`](../../doc/models/data-2.md) | Optional | - | getData(): ?Data2 | setData(?Data2 data): void |

## Example (as JSON)

```json
{
  "data": null
}
```

