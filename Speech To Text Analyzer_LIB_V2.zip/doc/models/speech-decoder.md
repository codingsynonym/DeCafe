
# Speech Decoder

Information per decoder

## Structure

`SpeechDecoder`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `title` | `?string` | Optional | Title of the decoder | getTitle(): ?string | setTitle(?string title): void |
| `description` | `?string` | Optional | A description of the decoder | getDescription(): ?string | setDescription(?string description): void |
| `id` | `?string` | Optional | Unique ID of the decoder | getId(): ?string | setId(?string id): void |
| `lang` | `?string` | Optional | Language ISO code of the decoder | getLang(): ?string | setLang(?string lang): void |

## Example (as JSON)

```json
{
  "title": null,
  "description": null,
  "id": null,
  "lang": null
}
```

