
# Data 1

## Structure

`Data1`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `decoders` | [`?(SpeechDecoder[])`](../../doc/models/speech-decoder.md) | Optional | - | getDecoders(): ?array | setDecoders(?array decoders): void |

## Example (as JSON)

```json
{
  "decoders": null
}
```

